jQuery.sap.declare("sapExamples.Component");
jQuery.sap.require("sap.ui.core.UIComponent");
jQuery.sap.require("sap.ui.core.routing.History");
jQuery.sap.require("sap.m.routing.RouteMatchedHandler");
sap.ui.core.UIComponent.extend("sapExamples.Component", {
    metadata : {
        "name" : "sapExamples",
        "version" : "1.1.0-SNAPSHOT",
        "library" : "sapExamples",
        "includes" : ["css/styles.css"],
        "dependencies" : {
            "libs" : [ "sap.m", "sap.ui.layout" ],
            "components" : []
        },
    "config" : {
      resourceBundle : "i18n/messageBundle.properties",
      serviceConfig : {
        name: "",
        serviceUrl : "../../../../../proxy/sap/opu/odata/sap/Z_FIORI_SODISPATCH_NEW_SRV/?saml2=disabled",
      }
    },
        routing : {
            config : {
                "viewType" : "XML",
                "viewPath" : "sapExamples.view",
                "targetControl" : "fioriContent", 
                "targetAggregation" : "pages", 
                "clearTarget" : false
            },
      routes : [
                {
                    pattern : "",
                    name : "S",
                    view : "S"
                },
                {
                    pattern : "tiles",
                    name : "tiles",
                    view : "S1"
                },
                {
                    pattern : "table",
                    name : "table",
                    view : "S2"
                },
                {
                    pattern : "form",
                    name : "form",
                    view : "S3"
                },
                {
                    pattern : "form1",
                    name : "form1",
                    view : "S31"
                },
                {
                    pattern : "form2",
                    name : "form2",
                    view : "S32"
                },
                {
                    pattern : "form3",
                    name : "form3",
                    view : "S33"
                },
                {
                    pattern : "graphchart",
                    name : "graphchart",
                    view : "charts"
                },
                {
                    pattern : "formatter",
                    name : "formatter",
                    view : "S4"
                },
                {
                    pattern : "search",
                    name : "search",
                    view : "S5"
                },
                {
                    pattern : "searchex",
                    name : "searchex",
                    view : "S51"
                },
                {
                    pattern : "searchex2",
                    name : "searchex2",
                    view : "S52"
                },
                {
                    pattern : "message",
                    name : "message",
                    view : "S6"
                },
                {
                    pattern : "input",
                    name : "input",
                    view : "S7"
                },
                {
                    pattern : "input1",
                    name : "input1",
                    view : "S71"
                },
                {
                    pattern : "input2",
                    name : "input2",
                    view : "S72"
                },
                {
                    pattern : "binding",
                    name : "binding",
                    view : "S8"
                },
                {
                    pattern : "bind1",
                    name : "bind1",
                    view : "S81"
                },
                {
                    pattern : "bind2",
                    name : "bind2",
                    view : "S82"
                },
                {
                    pattern : "bind3",
                    name : "bind3",
                    view : "S83"
                },
                
                {
                    pattern : "tblslctdg",
                    name : "tblslctdg",
                    view : "S21"
                },
                {
                    pattern : "tablerow",
                    name : "tablerow",
                    view : "S22"
                },
                {
                    pattern : "tablerowdelete",
                    name : "tablerowdelete",
                    view : "S23"
                },
                {
                    pattern : "tablerowdelete2",
                    name : "tablerowdelete2",
                    view : "S24"
                },
                {
                    pattern : "tablerowdelete3",
                    name : "tablerowdelete3",
                    view : "S25"
                },
                {
                    pattern : "tableadddelete",
                    name : "tableadddelete",
                    view : "S26"
                },
                {
                    pattern : "F4insidetable",
                    name : "F4insidetable",
                    view : "S27"
                },
                {
                    pattern : "rowexchange",
                    name : "rowexchange",
                    view : "S28"
                },
                {
                    pattern : "mergcells",
                    name : "mergcells",
                    view : "S29"
                },
                {
                    pattern : "general",
                    name : "general",
                    view : "S2A"
                },
                {
                    pattern : "tbcal",
                    name : "tbcal",
                    view : "S2B"
                },
                {
                pattern : "print",
                name : "print",
                view : "print"
                },
                {
                    pattern : "link",
                    name : "link",
                    view : "S9"
                },
                {
                    pattern : "other",
                    name : "other",
                    view : "SA"
                },
                {
                    pattern : "icon",
                    name : "icon",
                    view : "SC"
                },
                {
                    pattern : "select",
                    name : "select",
                    view : "SD"
                },
                {
                    pattern : "locknum",
                    name : "locknum",
                    view : "SE"
                },
                {
                    pattern : "calculations",
                    name : "calculations",
                    view : "SF"
                },
                {
                    pattern : "graphics",
                    name : "graphics",
                    view : "SG"
                },
                {
                    pattern : "graphics1",
                    name : "graphics1",
                    view : "SG1"
                },
                {
                    pattern : "graphics2",
                    name : "graphics2",
                    view : "SG2"
                },
                {
                    pattern : "sign",
                    name : "sign",
                    view : "Sign"
                },
                {
                    pattern : "fileupl",
                    name : "fileupl",
                    view : "fileupload"
                },
                {
                    pattern : "i18n",
                    name : "i18n",
                    view : "I18n"
                },
                {
                    pattern : "video",
                    name : "video",
                    view : "Video"
                },
                {
                    pattern : "panel",
                    name : "panel",
                    view : "panelWithJson"
                },
                {
                    pattern : "frame",
                    name : "frame",
                    view : "Iframe"
                },
                {
                    pattern : "controls",
                    name : "controls",
                    view : "Cnt"
                },
                {
                    pattern : "url",
                    name : "url",
                    view : "Cnt2"
                },
                {
                    pattern : "button",
                    name : "button",
                    view : "Btn"
                },
                
                
                
                
       
//      {
//          name : "S4",
//          view : "S4",
//          pattern : "S4/{code1}/{path}"
//        }

      ]
        }
    },
    createContent : function() {
        var oViewData = {
            component : this
        };

        return sap.ui.view({
            viewName : "sapExamples.view.Main",
            type : sap.ui.core.mvc.ViewType.XML,
            viewData : oViewData
        });
    },

    init : function() {
        sap.ui.core.UIComponent.prototype.init.apply(this, arguments);
        var sRootPath = jQuery.sap.getModulePath("sapExamples");

        var oServiceConfig = this.getMetadata().getConfig().serviceConfig;
        var sServiceUrl = oServiceConfig.serviceUrl;
        var mConfig = this.getMetadata().getConfig();
        this._routeMatchedHandler = new sap.m.routing.RouteMatchedHandler(this.getRouter(), this._bRouterCloseDialogs);
        this._initODataModel(sServiceUrl);
        var i18nModel = new sap.ui.model.resource.ResourceModel({
            bundleUrl : [ sRootPath, mConfig.resourceBundle ].join("/")
        });
        this.setModel(i18nModel, "i18n");
        this.getRouter().initialize();
    },
    exit : function() {
        this._routeMatchedHandler.destroy();
    },
    setRouterSetCloseDialogs : function(bCloseDialogs) {
        this._bRouterCloseDialogs = bCloseDialogs;
        if (this._routeMatchedHandler) {
            this._routeMatchedHandler.setCloseDialogs(bCloseDialogs);
        }
    },

    _initODataModel : function(sServiceUrl) {
/*        jQuery.sap.require("PI_Disp.util.messages");
*/        var oConfig = {
              json : true,
            defaultBindingMode :"TwoWay",
            defaultCountMode: "None",
            useBatch : false,
            
        };
        var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
       //oModel.attachRequestFailed(null, PI_Disp.util.messages.showErrorMessage);
        oModel.bCountSupported=false;
       
        
        this.setModel(oModel);
    }
});