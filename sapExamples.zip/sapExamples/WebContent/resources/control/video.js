jQuery.sap.declare("control.video");
sap.ui.core.Control.extend("control.video", {
  
    metadata : {
        properties : {
            /* other (configuration) properties */
            width             : {type : "sap.ui.core.CSSSize"},
            height            : {type : "sap.ui.core.CSSSize"},
            autoplay          : {type : "boolean", defaultValue : true},
            src1                :{type : "string"},
            controls   :         {type : "boolean", defaultValue : true},
          //  visible   :         {type : "boolean", defaultValue : true}
        },
    },
    
    renderer : function(oRm, oControl) {
        oRm.writeClasses();
        oRm.writeStyles();
        oRm.write("<div");
        oRm.writeControlData(oControl);
        //oRm.writeAttribute("visible",oControl.getVisible());
        oRm.write(">");
        oRm.write('<video');
        oRm.addStyle("width", oControl.getWidth());
        oRm.addStyle("height", oControl.getHeight());
        
        oRm.writeStyles();
        oRm.writeAttribute("autoplay",oControl.getAutoplay());
        oRm.writeAttribute("controls",oControl.getControls());
     
        oRm.write(">");
        oRm.write("<source");
        
    
       
      oRm.writeAttribute("src",oControl.getSrc1());
      oRm.write("/></video>");
       // oRm.write("<source src='http://www.w3schools.com/html/movie.mp4'>");
        oRm.write("</div>");
    }

});