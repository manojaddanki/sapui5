jQuery.sap.declare("control.video");
sap.ui.core.Control.extend("control.iframe", {
  
    metadata : {
        properties : {
            /* other (configuration) properties */
            width             : {type : "sap.ui.core.CSSSize"},
            height            : {type : "sap.ui.core.CSSSize"},
            src                :{type : "string"},
            name   : {type : "string"},
            style   : {type : "string"}
        },
    },
    
    renderer : function(oRm, oControl) {
        oRm.writeClasses();
        oRm.writeStyles();
        oRm.write("<div");
        oRm.writeControlData(oControl);
        //oRm.writeAttribute("visible",oControl.getVisible());
        oRm.write(">");
        oRm.write('<iframe');
        oRm.addStyle("width", oControl.getWidth());
        oRm.addStyle("height", oControl.getHeight());
        oRm.writeAttribute("style", oControl.getStyle());
        
        oRm.writeStyles();
       
     
      
     //   oRm.write("<source");
        
    
       
      oRm.writeAttribute("src",oControl.getSrc());
      oRm.writeAttribute("name",oControl.getName());
      oRm.write("</iframe>");
       // oRm.write("<source src='http://www.w3schools.com/html/movie.mp4'>");
        oRm.write("</div>");
    }

});