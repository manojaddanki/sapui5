sap.ui.controller("sapExamples.view.SF", {
	onInit: function() {
	},
	
	onBack:function(){
		var router=sap.ui.core.UIComponent.getRouterFor(this);
		router.navTo("main",{});
	}, 

	handleCalculations:function(){debugger;
		var P=this.byId("P");
		var N=this.byId("N");
		var R=this.byId("R");
		var I=this.byId("I");
		if(I.getValue()===""){
			var i=(parseInt(P.getValue())*parseInt(N.getValue())*parseInt(R.getValue()))/100;
		    I.setValue(i);
		    I.setEnabled(false);
		}
		else if(P.getValue()===""){
			var p=(parseInt(I.getValue())*100)/(parseInt(N.getValue())*parseInt(R.getValue()));
		    P.setValue(p);
		    P.setEnabled(false);
		}
		else if(N.getValue()===""){
			var n=(parseInt(I.getValue())*100)/(parseInt(P.getValue())*parseInt(R.getValue()));
		    N.setValue(n);
		    N.setEnabled(false);
		}
		else{
			var r=(parseInt(I.getValue())*100)/(parseInt(P.getValue())*parseInt(N.getValue()));
		    R.setValue(r);
		    R.setEnabled(false);
		}	
	},
	
	handleEnabled:function(){
		var P=this.byId("P");
		var N=this.byId("N");
		var R=this.byId("R");
		var I=this.byId("I");
		if(P.getValue()!==""&&N.getValue()!==""&&R.getValue()!==""&&I.getValue()===""){
			P.setEnabled(false);
			N.setEnabled(false);
			R.setEnabled(false);
		}
		else if(P.getValue()===""&&N.getValue()!==""&&R.getValue()!==""&&I.getValue()!==""){
			I.setEnabled(false);
			N.setEnabled(false);
			R.setEnabled(false);
		}
		else if(P.getValue()!==""&&N.getValue()===""&&R.getValue()!==""&&I.getValue()!==""){
			P.setEnabled(false);
			I.setEnabled(false);
			R.setEnabled(false);
		}
		else if(P.getValue()!==""&&N.getValue()!==""&&R.getValue()==""&&I.getValue()!==""){
			P.setEnabled(false);
			N.setEnabled(false);
			I.setEnabled(false);
		}
	},
	
	handleReset:function(){
		var that=this;
		that.byId("P").setValue("").setEnabled(true);
		that.byId("N").setValue("").setEnabled(true);
		that.byId("R").setValue("").setEnabled(true);
		that.byId("I").setValue("").setEnabled(true);
	}
	
});