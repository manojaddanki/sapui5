sap.ui.controller("sapExamples.view.Cnt2", {

	onInit:function(){
		
	},
	onBack:function(){
		this.getRouter().navTo("controls",{});
	},
	getRouter : function ()	{
		return sap.ui.core.UIComponent.getRouterFor(this);
	},

});