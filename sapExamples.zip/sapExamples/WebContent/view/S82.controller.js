sap.ui.controller("sapExamples.view.S82", {
	onInit: function() {
		// Create a new JSON model object
		 var oModel = new sap.ui.model.json.JSONModel({
		 greetingText : "Hi, my name is Manoj"
		 });
		 // Assign the model object to the SAPUI5 core
		 sap.ui.getCore().setModel(oModel);

		 new sap.m.Text({ text : "{/greetingText}" }).
		 addStyleClass("sapUiSmallMargin").
		 placeAt("content")
		
	},
	onBack:function()
	{
		this.getRouter().navTo("bind",{});
	},
	getRouter : function () 
	{
		return sap.ui.core.UIComponent.getRouterFor(this);
	},
});