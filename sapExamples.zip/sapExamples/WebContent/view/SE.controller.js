sap.ui.controller("sapExamples.view.SE", {

	onInit: function() {
		
	},
	
	handleStateChange:function(evt){debugger;
	var that=this;
	var state=evt.getSource().getState();
		 var Value=that.byId("iptId").getValue();
		 var that=this;
		 for(var i=0;state;i++){
		     state=evt.getSource().getState();
			 that.byId("btn1").setText(that.randomNumber(0,9));
			 that.byId("btn2").setText(that.randomNumber(0,9));
			 that.byId("btn3").setText(that.randomNumber(0,9));
			 setInterval(function() {
			      // Do something every 5 seconds
			}, 5000);
			 if(Value===that.byId("btn1").getText()+that.byId("btn2").getText()+that.byId("btn3").getText()){
				 that.byId("switchId").setState(false);
				 break;
			 }
			 continue;
		 } 
	},
	
	
	randomNumber:function(minimum, maximum){
	    return Math.round(Math.random()*(maximum - minimum) + minimum);
	},
	
	onBack:function(){
		var router=sap.ui.core.UIComponent.getRouterFor(this);
	    router.navTo("main",{});
		}, 

});