sap.ui.controller("sapExamples.view.S83", {

onInit: function() {
	var oModel = new sap.ui.model.json.JSONModel({
		 //greetingText : "Hi, my name is Harry Hawk"
		 firstName : "Manoj",
		 lastName : "Addanki"
		 });
	sap.ui.getCore().setModel(oModel);

	new sap.m.Text({ text : "Hi, my name is {/firstName} {/lastName}" })

},
	onBack:function()
	{
		this.getRouter().navTo("bind",{});
	},
	getRouter : function () 
	{
		return sap.ui.core.UIComponent.getRouterFor(this);
	},

});