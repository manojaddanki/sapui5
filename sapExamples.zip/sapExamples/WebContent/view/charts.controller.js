sap.ui.controller("sapExamples.view.charts", {

	onInit: function() {
	var that=this;	
	var oData=[
		            {Company: "Honda",Country: "India",Measures: "150",Population: "10000000",Product: "Car",Profit: "41.25",Region: "Asia",Revenue: "310.87",Year: "2002" },
	                {Company: "Samsung",Country: "China",Measures: "50",Population: "35589000",Product: "Mobiles",Profit: "10.25",Region: "Asia",Revenue: "210.87",Year: "2003"},
	                {Company: "Toshiba",Country: "France",Measures: "90",Population: "569000",Product: "TV",Profit: "81.25",Region: "Asia",Revenue: "487.12",Year: "2010"},
	                {Company: "Honda",Country: "Germany",Measures: "40",Population: "4789000",Product: "Car",Profit: "56.25",Region: "Europe",Revenue: "210.87",Year: "2004"},
	                {Company: "Samsung",Country: "Switzerland",Measures: "80",Population: "56789000",Product: "Mobiles",Profit: "125.56",Region: "Europe",Revenue: "510.55",Year: "2005"},
	                {Company: "Toshiba",Country: "Russia",Measures: "20",Population: "55789000",Product: "TV",Profit: "25.23",Region: "Europe",Revenue: "41.87",Year: "2006"},
	                {Company: "Honda",Country: "SouthAfrica",Measures: "80",Population: "4789000",Product: "Car",Profit: "14.25",Region: "Africa",Revenue: "510.07",Year: "2001"},
	                {Company: "Samsung",Country: "Kenya",Measures: "70",Population: "5589000",Product: "Mobiles",Profit: "51.25",Region: "Africa",Revenue: "87.12",Year: "2008"},
	                {Company: "Toshiba",Country: "Egypt",Measures: "20",Population: "122000",Product: "TV",Profit: "68.25",Region: "Africa",Revenue: "57.12",Year: "2009"}
	                ]
        that.bindLineChart(oData);
		that.bindPieChart(oData);
		that.bindDonutChart(oData);
		that.bindBarChart(oData);
		that.bindColumnChart(oData);
		that.bindBubbleChart(oData);
		that.bindCombinationChart(oData);
		that.bindScatterChart(oData);
		that.bindTimebubbleChart(oData);
		that.bindStackedVbarChart(oData);
		that.bindStackedVbarpChart(oData);
		that.bindDualbarChart(oData);
		that.bindDualLineChart(oData);
		that.bindDualcombinationChart(oData);
		that.bindDualstackedcolumnChart(oData);
		that.bindDualstackedcolumnpChart(oData);
		that.bindDualcolumnChart(oData);
		that.bindAreaChart(oData);
		that.bindAreapChart(oData);
		that.bindHorizontalAreaChart(oData);
		that.bindHorizontalAreapChart(oData);
		},
	
	//Define Function for Draw Line Chart
	bindLineChart: function(oData) {
	     var lineChartData=oData;
	     var lineChartModel = new sap.ui.model.json.JSONModel(lineChartData);
	     var dataset = new sap.viz.ui5.data.FlattenedDataset({
	 			dimensions : [ {
	 				axis : 1,
	 				name : 'Country',
	 				value : "{Country}"
	 			}],
	 			measures : [ {
	 				name : 'Revenue',
	 				value : '{Revenue}'
	 			}],
	 			data : {
					path : "/"
			}
	          });
	     var line = new sap.viz.ui5.Line({
	                width : "80%",
	                height : "400px",
	                plotArea : {
	                },
	                title : {
	                       visible : true,
	                       text : 'Line Chart'
	                },
	                xAxis : {
	                       title : {
	                              visible : true,
	                      }
	                },
	                yAxis : {
	                    title : {
	                           visible : true,
	                   }
	             },
	                dataset : dataset
	          });
	          line.setModel(lineChartModel);
	          this.byId("linecharts").addContent(line); 
	   },
	   
	   //Define Function for Draw PIE Chart
	   bindPieChart:function(oData)
	   {
		   var piechartdata=oData;
		   var pieChartModel = new sap.ui.model.json.JSONModel(piechartdata);
   	  		var dataset = new sap.viz.ui5.data.FlattenedDataset({
	 			dimensions : [ {
	 				axis : 1,
	 				name : 'Country',
	 				value : "{Country}"
	 			} ],
	 			measures : [ {
	 				name : 'Revenue',
	 				value : '{Revenue}'
	 			}, 
	 			],
	 			data : {
	 				path : "/"
	                }
	          });
	         var pie = new sap.viz.ui5.Pie({
	                width : "80%",
	                height : "400px",
	                plotArea : {
	                },
	                title : {
	                       visible : true,
	                       text : 'Pie Chart'
	                },
	                xAxis : {
	                       title : {
	                              visible : true,
	                      }
	                },
	                yAxis : {
	                    title : {
	                           visible : true,
	                   }
	             },
	                dataset : dataset
	          });
	          pie.setModel(pieChartModel);
	          this.byId("piecharts").addContent(pie); 
	   },
	   
	   //Define Function for Draw Donut Chart
	   bindDonutChart:function(oData)
	   {
		   var pieChartData=oData;
		   var pieChartModel = new sap.ui.model.json.JSONModel(pieChartData);
	       var dataset = new sap.viz.ui5.data.FlattenedDataset({
				dimensions : [ {
					axis : 1,
					name : 'Country',
					value : "{Country}"
				} ],
				measures : [ {
					name : 'Revenue',
					value : '{Revenue}'
				}, 
				],
				data : {
					path : "/" 
	               }
	         });
	         var donut = new sap.viz.ui5.Donut({
	               width : "80%",
	               height : "400px",
	               plotArea : {
	               },
	               title : {
	                      visible : true,
	                      text : 'Donut Chart'
	               },
	               xAxis : {
	                      title : {
	                             visible : true,
	                     }
	               },
	               yAxis : {
	                   title : {
	                          visible : true,
	                  }
	            },
	               dataset : dataset
	         });
	         donut.setModel(pieChartModel);
	         this.byId("donutcharts").addContent(donut); 
	   },
	   
	 //Define Function for Draw Bar Chart
	   bindBarChart:function(oData)
	   {
		   var barChartData=oData
		   var barCharModel = new sap.ui.model.json.JSONModel(barChartData);
		 		var dataset = new sap.viz.ui5.data.FlattenedDataset({
	            dimensions : [ {
	              axis : 1,
	              name : 'Country',
	              value : "{Country}"
	            } ],
	            measures : [ {
	              name : 'Revenue',
	              value : '{Revenue}'
	            }, {
	              name : 'Profit',
	              value : '{Profit}'
	            } ],

				data : {
					path : "/"
	               }
	         });
	         var bar = new sap.viz.ui5.Bar({
	               width : "80%",
	               height : "400px",
	               plotArea : {
	               },
	               title : {
	                      visible : true,
	                      text : 'Bar Chart'
	               },
	               xAxis : {
	                      title : {
	                             visible : true,
	                     }
	               },
	               yAxis : {
	                   title : {
	                          visible : true,
	                  }
	            },
	               dataset : dataset
	         });
	         bar.setModel(barCharModel);
	         this.byId("barcharts").addContent(bar); 
	   },
	   
	   //Define Function for Draw Column Chart
	   bindColumnChart : function(oData){
	    var colChartData=oData;
	    var colChartDataModel = new sap.ui.model.json.JSONModel(colChartData);
	  	var dataset = new sap.viz.ui5.data.FlattenedDataset({
	            dimensions : [ {
	              axis : 1,
	              name : 'Country',
	              value : "{Country}"
	            } ],
	            measures : [ {
	              name : 'Revenue',
	              value : '{Revenue}'
	            }, {
	              name : 'Profit',
	              value : '{Profit}'
	            } ],
				data : {
					path : "/"
	               }
	         });
	         var bar = new sap.viz.ui5.Column({
	               width : "80%",
	               height : "400px",
	               plotArea : {
	               },
	               title : {
	                      visible : true,
	                      text : 'Column Chart'
	               },
	               xAxis : {
	                      title : {
	                             visible : true,
	                     }
	               },
	               yAxis : {
	                   title : {
	                          visible : true,
	                  }
	            },
	               dataset : dataset
	         });
	         bar.setModel(colChartDataModel);
	        this.byId("columncharts").addContent(bar); 
	   },
	   
	   //Define Function for Draw Bubles Chart Diagram
	   bindBubbleChart:function(oData)
       {
		   var bubleData=oData;
		   var bubleModel = new sap.ui.model.json.JSONModel(bubleData);
	   		var dataset = new sap.viz.ui5.data.FlattenedDataset({
	  			 dimensions : [ {
	                 axis : 1,
	                 name : 'Country',
	                 value : "{Country}"
	               } ],
	               measures : [ {
	                 group : 1,
	                 name : 'Revenue',
	                 value : '{Revenue}'
	               }, {
	                 group : 2,
	                 name : 'Profit',
	                 value : '{Profit}'
	               }, {
	                 group : 3,
	                 name : 'Population',
	                 value : '{Population}'
	               } ],
	  			data : {
	 				path : "/"
	                }
	          });
	          var bubble = new sap.viz.ui5.Bubble({
	                width : "80%",
	                height : "400px",
	                plotArea : {
	                },
	                title : {
	                       visible : true,
	                       text : 'Bubble Chart'
	                },
	                xAxis : {
	                       title : {
	                              visible : true,
	                      }
	                },
	                yAxis : {
	                    title : {
	                           visible : true,
	                   }
	             },
	                dataset : dataset
	          });
	          bubble.setModel(bubleModel);
	          this.byId("bubblecharts").addContent(bubble); 
       },
	   

       //Define Function for Draw the Combination Chart
       bindCombinationChart : function(oData){
      	   var cmbData=oData;
      	   var cmbModel = new sap.ui.model.json.JSONModel(cmbData);
           var dataset = new sap.viz.ui5.data.FlattenedDataset({
       			 dimensions : [ {
                      axis : 1,
                      name : 'Country',
                      value : "{Country}"
                    } ],
                    measures : [ {
                      name : 'Revenue',
                      value : '{Revenue}'
                    }, {
                      name : 'Profit',
                      value : '{Profit}'
                    }
                    ],
       			data : {
      				path : "/"
                     }
               });
       	  var combination = new sap.viz.ui5.Combination({
             width : "80%",
             height : "400px",
             plotArea : {
             //'colorPalette' : d3.scale.category20().range()
             },
             title : {
               visible : true,
               text : 'Combination Chart'
             },
             bar : {
             },
             line : {
             },
             dataset : dataset
           });
       	combination.setModel(cmbModel);
        this.byId("combinationcharts").addContent(combination); 
         },
         
         //Define Function for Draw the Scatter Chart
         bindScatterChart : function(oData){
         var sctData=oData; 
         var sctModel = new sap.ui.model.json.JSONModel(sctData);
          var dataset = new sap.viz.ui5.data.FlattenedDataset({
        			 dimensions : [ {
                       axis : 1,
                       name : 'Country',
                       value : "{Country}"
                     } ],

                     measures : [ {
                       group : 1,
                       name : 'Revenue',
                       value : '{Revenue}'
                     }, {
                       group : 2,
                       name : 'Population',
                       value : '{Population}'
                     }
                     ],
        			data : {
       				path : "/"
                      }
                });
                var scatter = new sap.viz.ui5.Scatter({
                      width : "80%",
                      height : "400px",
                      plotArea : {
                      },
                      title : {
                             visible : true,
                             text : 'Scatter Chart'
                      },
                      xAxis : {
                             title : {
                                    visible : true,
                            }
                      },
                      yAxis : {
                          title : {
                                 visible : true,
                         }
                   },
                      dataset : dataset
                });
                scatter.setModel(sctModel);
                 this.byId("scattercharts").addContent(scatter); 
          },
	   
          //Define Function for Draw the Time bubble Chart
          bindTimebubbleChart : function(oData){
              var timebbldata=oData;
        	  var timebblModel = new sap.ui.model.json.JSONModel(timebbldata);
              var dataset = new sap.viz.ui5.data.FlattenedDataset({
          			 dimensions : [ {
                         axis : 1,
                         name : 'Country',
                         value : "{Country}"
                       } ],
                       measures : [ {
                         group : 1,
                         name : 'Revenue',
                         value : '{Revenue}'
                       }, {
                         group : 2,
                         name : 'Population',
                         value : '{Population}'
                       },
                       {
                      	 group : 3,
                           name : 'Profit',
                           value : '{Profit}'
                         }
                       ],
          			data : {
         				path : "/"
                        }
                  });
                  var timebubble = new sap.viz.ui5.TimeBubble({
                        width : "80%",
                        height : "400px",
                        plotArea : {
                        },
                        title : {
                               visible : true,
                               text : 'TimeBubble Chart'
                        },
                        xAxis : {
                               title : {
                                      visible : true,
                              }
                        },
                        yAxis : {
                            title : {
                                   visible : true,
                           }
                     },
                        dataset : dataset
                  });
                  timebubble.setModel(timebblModel);
                  this.byId("timebubblecharts").addContent(timebubble); 
            },
            
            
            //Define Function for Draw the stacked vyber chart
            bindStackedVbarChart : function(oData){
         	   var stackedBarData=oData;
            	var stackedBarModel = new sap.ui.model.json.JSONModel(stackedBarData);
               var dataset = new sap.viz.ui5.data.FlattenedDataset({
          			  dimensions : [
             	                      {axis : 1, name: "Region", value: "{Region}"},
             	                      {axis : 2, name: "Company", value: "{Company}"},
             	                  ],
             	                  measures : [
             	                      {group: 1, name : "Revenue", value : "{Revenue}"},
             	                      {group: 2, name : "Measures", value : "{Measures}"}
             	                  ],
                   /*    measures : [ 
                       {
                           name : 'Profit',
                           value : '{Profit}'
                         }
                       ],*/

          			data : {
         				path : "/"
                        }
                  });
          	var	stackbar = new sap.viz.ui5.StackedColumn({
                        width : "80%",
                        height : "400px",
                        plotArea : {
                        },
                        title : {
                               visible : true,
                               text : 'StackedColumn Chart'
                        },
                        xAxis : {
                     	   title:{visible:true} ,
                        //    label:{hideSubLevels:true},
                        },
                        yAxis : {
                     	   title:{visible:true},
                            label:{visible:false},
                     },
                        dataset : dataset
                  });
                  stackbar.setModel(stackedBarModel);
                  this.byId("stackvbarcharts").addContent(stackbar); 
            },
            
            //Define Function for Draw a stackVbarPie Chart
            bindStackedVbarpChart : function(oData){
               var stkBarVbrChartData=oData 	
         	   var stkBarVbrChartModel = new sap.ui.model.json.JSONModel(stkBarVbrChartData);
               var dataset = new sap.viz.ui5.data.FlattenedDataset({
          			 dimensions : [
          	                      {axis : 1, name: "Region", value: "{Region}"},
          	                      {axis : 2, name: "Company", value: "{Company}"},
          	                  ],
          	                  measures : [
          	                      {group: 1, name : "Revenue", value : "{Revenue}"},
          	                      {group: 2, name : "Measures", value : "{Measures}"}
          	                  ],
                       measures : [ 
                       {
                           name : 'Profit',
                           value : '{Profit}'
                         }
                       ],
          			data : {
         				path : "/"
                        }
             });
          	var	stackbarp = new sap.viz.ui5.StackedColumn100({
                         width : "80%",
                        height : "400px",
                        plotArea : {
                        },
                        title : {
                               visible : true,
                               text : 'StackedColumn(%)'
                        },
                        xAxis : {
                     	   title:{visible:true} ,
                            label:{hideSubLevels:true},
                        },
                        yAxis : {
                     	   title:{visible:true},
                            label:{visible:false},
                     },
                        dataset : dataset
                  });
          	stackbarp.setModel(stkBarVbrChartModel);
            this.byId("stackvbarpcharts").addContent(stackbarp); 
            },
            
            //Define Function for Draw the Dual Bar Chart
            bindDualbarChart : function(oData){
               var dualBarChartData=oData;
         	   var dualBarChartModel = new sap.ui.model.json.JSONModel(dualBarChartData);
            	var dataset = new sap.viz.ui5.data.FlattenedDataset({
          		   dimensions : [
          	                      {axis : 1, name: "Region", value: "{Region}"},
          	                      {axis : 2, name: "Company", value: "{Company}"},
          	                  ],
          	                  measures : [
          	                      {group: 1, name : "Revenue", value : "{Revenue}"},
          	                      {group: 2, name : "Measures", value : "{Measures}"}
          	                  ],
          			data : {
         				path : "/"
                        }
                  });
          	var	dualbar = new sap.viz.ui5.DualBar({
                        width : "80%",
                        height : "400px",
                        plotArea : {
                        },
                        title : {
                               visible : true,
                               text : 'DualBar Chart'
                        },
                        xAxis : {
                     	   title:{visible:true} ,
                            label:{hideSubLevels:true},
                        },
                        yAxis : {
                     	   title:{visible:true},
                            label:{visible:false},
                     },
                        dataset : dataset
                  });
          	dualbar.setModel(dualBarChartModel);
                  this.byId("dualbarcharts").addContent(dualbar); 
            },
           
            //Define Function for Draw the Dual Line Chart
            bindDualLineChart : function(oData){
         	    var dualLineChartData=oData;
            	var dualLineChartModel = new sap.ui.model.json.JSONModel(dualLineChartData);
               	var dataset = new sap.viz.ui5.data.FlattenedDataset({
           		   dimensions : [
           	                      {axis : 1, name: "Region", value: "{Region}"},
           	                      {axis : 2, name: "Company", value: "{Company}"},
           	                  ],
           	                  measures : [
           	                      {group: 1, name : "Revenue", value : "{Revenue}"},
           	                      {group: 2, name : "Measures", value : "{Measures}"}
           	                  ],
          			data : {
         				path : "/"
                        }
                  });
          	var	dualline = new sap.viz.ui5.DualLine({
                        width : "80%",
                        height : "400px",
                        plotArea : {
                        },
                        title : {
                               visible : true,
                               text : 'Dual Line'
                        },
                        xAxis : {
                     	   title:{visible:true} ,
                            label:{hideSubLevels:true},
                        },
                        yAxis : {
                     	   title:{visible:true},
                            label:{visible:false},
                     },
                        dataset : dataset
                  });
          	dualline.setModel(dualLineChartModel);
                  this.byId("duallinepcharts").addContent(dualline); 
            },
            
            
            //Define Function for draw the Dual Combination Chart
            bindDualcombinationChart : function(oData){
                var dualcombinationdata=oData;
            	var dualCombinationChartsModel = new sap.ui.model.json.JSONModel(dualcombinationdata);
             	var dataset = new sap.viz.ui5.data.FlattenedDataset({
                      		   dimensions : [
                      	                      {axis : 1, name: "Region", value: "{Region}"},
                      	                      {axis : 2, name: "Company", value: "{Company}"},
                      	                  ],
                      	                  measures : [
                      	                      {group: 1, name : "Revenue", value : "{Revenue}"},
                      	                      {group: 2, name : "Measures", value : "{Measures}"}
                      	                  ],
                     			data : {
                    				path : "/"
                                   }
                             });
                     	var	dualcombination = new sap.viz.ui5.DualCombination({
                                   width : "80%",
                                   height : "400px",
                                   plotArea : {
                                   },
                                   title : {
                                          visible : true,
                                          text : 'Dual Combination'
                                   },
                                   xAxis : {
                                	   title:{visible:true} ,
                                       label:{hideSubLevels:true},
                                   },
                                   yAxis : {
                                	   title:{visible:true},
                                       label:{visible:false},
                                },
                                   dataset : dataset
                             });
                     	dualcombination.setModel(dualCombinationChartsModel);
                             this.byId("dualcombinationcharts").addContent(dualcombination); 
                       },
                       
                       //Define Function for draw the Dual Stacked Column Chart
                       bindDualstackedcolumnChart : function(oData){
                    	   var dualStackedcolumnChartData=oData;
                    	   var dualStackedcolumnChartModel = new sap.ui.model.json.JSONModel(dualStackedcolumnChartData);
                      		var dataset = new sap.viz.ui5.data.FlattenedDataset({
                      		   dimensions : [
                      	                      {axis : 1, name: "Region", value: "{Region}"},
                      	                      {axis : 2, name: "Company", value: "{Company}"},
                      	                  ],
                      	                  measures : [
                      	                      {group: 1, name : "Revenue", value : "{Revenue}"},
                      	                      {group: 2, name : "Measures", value : "{Measures}"}
                      	                  ],
                     			data : {
                    				path : "/"
                                   }
                             });
                     	var	dualstackedcolumn = new sap.viz.ui5.DualStackedColumn({
                                   width : "80%",
                                   height : "400px",
                                   plotArea : {
                                   },
                                   title : {
                                          visible : true,
                                          text : 'DualStackedColumn Chart'
                                   },
                                   xAxis : {
                                	   title:{visible:true} ,
                                       label:{hideSubLevels:true},
                                   },
                                   yAxis : {
                                	   title:{visible:true},
                                       label:{visible:false},
                                },
                                   dataset : dataset
                             });
                     	dualstackedcolumn.setModel(dualStackedcolumnChartModel);
                            this.byId("dualstackcolumn").addContent(dualstackedcolumn); 
                       },
                       
                       //Define Function for Draw the stacked Column percentage Chart
                       bindDualstackedcolumnpChart : function(oData){
                    	   var dualstackedcolumnpChartData=oData
                    	   var dualstackedcolumnpChartModel = new sap.ui.model.json.JSONModel(dualstackedcolumnpChartData);
                           var dataset = new sap.viz.ui5.data.FlattenedDataset({
                      		   dimensions : [
                      	                      {axis : 1, name: "Region", value: "{Region}"},
                      	                      {axis : 2, name: "Company", value: "{Company}"},
                      	                  ],
                      	                  measures : [
                      	                      {group: 1, name : "Revenue", value : "{Revenue}"},
                      	                      {group: 2, name : "Measures", value : "{Measures}"}
                      	                  ],
                     			data : {
                    				path : "/"
                                   }
                             });
                     	var	dualstackedcolumnp = new sap.viz.ui5.DualStackedColumn100({
                                   width : "80%",
                                   height : "400px",
                                   plotArea : {
                                   },
                                   title : {
                                          visible : true,
                                          text : 'DualStackedColumn(%) Chart'
                                   },
                                   xAxis : {
                                	   title:{visible:true} ,
                                       label:{hideSubLevels:true},
                                   },
                                   yAxis : {
                                	   title:{visible:true},
                                       label:{visible:false},
                                },
                                   dataset : dataset
                             });
                     	dualstackedcolumnp.setModel(dualstackedcolumnpChartModel);
                             this.byId("dualstackcolumnp").addContent(dualstackedcolumnp); 
                       },
                       
                       //Define Function for Draw the Dual Column Chart
                       bindDualcolumnChart : function(oData){
                    	   var dualcolumndata=oData;
                    	   var dualcolumnModel = new sap.ui.model.json.JSONModel(dualcolumndata);
                           	var dataset = new sap.viz.ui5.data.FlattenedDataset({
                      		   dimensions : [
                      	                      {axis : 1, name: "Region", value: "{Region}"},
                      	                      {axis : 2, name: "Company", value: "{Company}"},
                      	                  ],
                      	                  measures : [
                      	                      {group: 1, name : "Revenue", value : "{Revenue}"},
                      	                      {group: 2, name : "Measures", value : "{Measures}"}
                      	                  ],
                     			data : {
                    				path : "/"
                                   }
                             });
                     	var	dualcolumn = new sap.viz.ui5.DualColumn({
                                   width : "80%",
                                   height : "400px",
                                   plotArea : {
                                   },
                                   title : {
                                          visible : true,
                                          text : 'DualColumn Chart'
                                   },
                                   xAxis : {
                                	   title:{visible:true} ,
                                       label:{hideSubLevels:true},
                                   },
                                   yAxis : {
                                	   title:{visible:true},
                                       label:{visible:false},
                                },
                                   dataset : dataset
                             });
                     	dualcolumn.setModel(dualcolumnModel);
                             this.byId("dualcolumn").addContent(dualcolumn); 
                       },
                       
                       //Define Function for Draw the Area Chart
                       bindAreaChart : function(oData){
                    	   var  areaChartData=oData;
                    	   var areaChartDataModel = new sap.ui.model.json.JSONModel(areaChartData);
                           	var dataset = new sap.viz.ui5.data.FlattenedDataset({
                      		   dimensions : [
                      	                      {axis : 1, name: "Region", value: "{Region}"},
                      	                      {axis : 2, name: "Company", value: "{Company}"},
                      	                  ],
                      	                  measures : [
                      	                      {group: 1, name : "Revenue", value : "{Revenue}"},
                      	                      {group: 2, name : "Measures", value : "{Measures}"}
                      	                  ],
                     			data : {
                    				path : "/"
                                   }
                             });
                     	var	area = new sap.viz.ui5.Area({
                                   width : "80%",
                                   height : "400px",
                                   plotArea : {
                                   },
                                   title : {
                                          visible : true,
                                          text : 'Area Chart'
                                   },
                                   xAxis : {
                                	   title:{visible:true} ,
                                       label:{hideSubLevels:true},
                                   },
                                   yAxis : {
                                	   title:{visible:true},
                                       label:{visible:false},
                                },
                                   dataset : dataset
                             });
                     	area.setModel(areaChartDataModel);
                            this.byId("area").addContent(area); 
                       },
            
                       //Define Funciton for Draw the Area Percentage Chart
                       bindAreapChart : function(oData){
                    	   var areapdata=oData;
                    	   var areapModel = new sap.ui.model.json.JSONModel(areapdata);
                           var dataset = new sap.viz.ui5.data.FlattenedDataset({
                      		   dimensions : [
                      	                      {axis : 1, name: "Region", value: "{Region}"},
                      	                      {axis : 2, name: "Company", value: "{Company}"},
                      	                  ],
                      	                  measures : [
                      	                      {group: 1, name : "Revenue", value : "{Revenue}"},
                      	                      {group: 2, name : "Measures", value : "{Measures}"}
                      	                  ],
                     			data : {
                    				path : "/"
                                   }
                             });
                     	var	areap = new sap.viz.ui5.Area100({
                                   width : "80%",
                                   height : "400px",
                                   plotArea : {
                                   },
                                   title : {
                                          visible : true,
                                          text : 'Area(%) Chart'
                                   },
                                   xAxis : {
                                	   title:{visible:true} ,
                                       label:{hideSubLevels:true},
                                   },
                                   yAxis : {
                                	   title:{visible:true},
                                       label:{visible:false},
                                },
                                   dataset : dataset
                             });
                     	areap.setModel(areapModel);
                            this.byId("areap").addContent(areap); 
                       },
                       
                       //Define Function for Draw the Horizontal Area Chart
                       bindHorizontalAreaChart : function(oData){
                               	   var horizontalareaData=oData;
                               	   var horizontalareaModel = new sap.ui.model.json.JSONModel(horizontalareaData);
                              		var dataset = new sap.viz.ui5.data.FlattenedDataset({
                                 		   dimensions : [
                                 	                      {axis : 1, name: "Region", value: "{Region}"},
                                 	                      {axis : 2, name: "Company", value: "{Company}"},
                                 	                  ],
                                 	                  measures : [
                                 	                      {group: 1, name : "Revenue", value : "{Revenue}"},
                                 	                      {group: 2, name : "Measures", value : "{Measures}"}
                                 	                  ],
                                			data : {
                               				path : "/"
                                              }
                                        });
                                	var	horizontalarea1 = new sap.viz.ui5.HorizontalArea({
                                              width : "80%",
                                              height : "400px",
                                              plotArea : {
                                              },
                                              title : {
                                                     visible : true,
                                                     text : 'Horizontal Chart'
                                              },
                                              xAxis : {
                                           	   title:{visible:true} ,
                                                  label:{hideSubLevels:true},
                                              },
                                              yAxis : {
                                           	   title:{visible:true},
                                                  label:{visible:false},
                                           },
                                              dataset : dataset
                                        });
                                	horizontalarea1.setModel(horizontalareaModel);
                                        this.byId("horizontalarea").addContent(horizontalarea1); 
                                  },
                                  
                                  //Define Function for Draw the Horizontal Area Chart
                                  bindHorizontalAreapChart : function(oData){
                               	   var horizontalareapData=oData;
                               	   var horizontalareapModel = new sap.ui.model.json.JSONModel(horizontalareapData);
                                   var dataset = new sap.viz.ui5.data.FlattenedDataset({
                                 		   dimensions : [
                                 	                      {axis : 1, name: "Region", value: "{Region}"},
                                 	                      {axis : 2, name: "Company", value: "{Company}"},
                                 	                  ],
                                 	                  measures : [
                                 	                      {group: 1, name : "Revenue", value : "{Revenue}"},
                                 	                      {group: 2, name : "Measures", value : "{Measures}"}
                                 	                  ],
                                			data : {
                               				path : "/"
                                              }
                                        });
                                	var	horizontalareap1 = new sap.viz.ui5.HorizontalArea100({
                                              width : "80%",
                                              height : "400px",
                                              plotArea : {
                                              },
                                              title : {
                                                     visible : true,
                                                     text : 'Horizontal(%) Chart'
                                              },
                                              xAxis : {
                                           	   title:{visible:true} ,
                                                  label:{hideSubLevels:true},
                                              },
                                              yAxis : {
                                           	   title:{visible:true},
                                                  label:{visible:false},
                                           },
                                              dataset : dataset
                                        });
                                	horizontalareap1.setModel(horizontalareapModel);
                                        this.byId("horizontalareap").addContent(horizontalareap1); 
                                  },
            
                                  onBack:function(){
                                		var router=sap.ui.core.UIComponent.getRouterFor(this);
                                	    router.navTo("main",{});
                                		},
                                		
                                		getRouter : function () 
                                		{
                                			return sap.ui.core.UIComponent.getRouterFor(this);
                                		},
                                  
});