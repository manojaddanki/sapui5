sap.ui.controller("sapExamples.view.S8", {
	onInit: function() {
	},
	
	handleBind1:function()
	{
		this.getRouter().navTo("bind1",{});
	},
	handleBind2:function()
	{
		this.getRouter().navTo("bind2",{});
	},
	
	handleBind3:function()
	{
		this.getRouter().navTo("bind3",{});
	},
	onBack:function()
	{
		var router=sap.ui.core.UIComponent.getRouterFor(this);
	    router.navTo("main",{});
	},
	
	getRouter : function () 
	{
		return sap.ui.core.UIComponent.getRouterFor(this);
	},

});