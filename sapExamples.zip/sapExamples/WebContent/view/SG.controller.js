sap.ui.controller("sapExamples.view.SG", {
	onInit: function() {
	},
   
	handleTile1:function(){
		 this.getRouter().navTo("graphics1",{});
	},
	handleTile2:function(){
		 this.getRouter().navTo("graphics2",{});
	},
	getRouter : function ()	{
		return sap.ui.core.UIComponent.getRouterFor(this);
	},
	onBack:function(){
		var router=sap.ui.core.UIComponent.getRouterFor(this);
		router.navTo("main",{});
	}, 
});