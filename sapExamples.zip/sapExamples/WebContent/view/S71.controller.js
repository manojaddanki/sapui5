sap.ui.controller("sapExamples.view.S71", {


	onInit: function() {
		var Article= [
		            
                     {ArticleNo: 40000008,ArticleDescripiton:"AppleIphone'5's"},
		             {ArticleNo: 40000021,ArticleDescripiton:"LenovoA6000Plus"},
		             {ArticleNo: 40000025,ArticleDescripiton:"AppleIphone'6's"},
		             {ArticleNo: 40000058,ArticleDescripiton:"Nokia 1101"}
		         ];
		 this.oModel = new sap.ui.model.json.JSONModel(Article);
	     this.getView().setModel(this.oModel);
	},

	 //Define Value Help Function for SLloc.
	handleValueHelpMaterial : function() {
    this._valueHelpDialog2 = new sap.m.SelectDialog({
      title : "Select Material",
      noDataText : "No Entries Found",
      items : {
          path : "/",
        template : new sap.m.StandardListItem({
          title : "{ArticleNo}",
          description : "{ArticleDescripiton}",
        })
      },
      search : [ this._handleValueHelp2Search, this ],
      confirm : [ this._handleValueHelp2Close, this ],
      cancel : [ this._handleValueHelp2Close, this ]
    });
    this._valueHelpDialog2.setModel(this.oModel);
    this._valueHelpDialog2.open();
    },
  _handleValueHelp2Close : function(evt) {
    var oSelectedItem = evt.getParameter("selectedItem");
    if (oSelectedItem) {
      var i1 = this.getView().byId("materialId");
      i1.setValue(oSelectedItem.getTitle()+" - "+oSelectedItem.getDescription());
      this.Sloc = oSelectedItem.getTitle();
    }
  },
  _handleValueHelp2Search : function(evt) {
    var sValue = evt.getParameter("value").toLowerCase();
    var keys = evt.getSource().getBinding("items").aKeys;
    var smodel =  evt.getSource().getModel();
    for (var i = 0; i < this._valueHelpDialog2.getItems().length; i++){
      var val = smodel.getProperty("/" + keys[i]).ArticleNo.toLowerCase();
      var val1 = smodel.getProperty("/" + keys[i]).ArticleDescripiton.toLowerCase();
      if (val.indexOf(sValue) > -1 || val1.indexOf(sValue) > -1){
        this._valueHelpDialog2.getItems()[i].setVisible(true);
      } else {
        this._valueHelpDialog2.getItems()[i].setVisible(false);
      }
    }
  },
	
	onBack:function()
	{
		this.getRouter().navTo("input",{});
	},

getRouter : function () 
	{
		return sap.ui.core.UIComponent.getRouterFor(this);
	},
});