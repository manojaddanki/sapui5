sap.ui.controller("sapExamples.view.S1", {
	onInit: function() {
	},
   
	handleForm:function(){
		this.getRouter().navTo("form",{});
	},
	
	
	
	handletable:function(){
		this.getRouter().navTo("table",{});
	},
	
	handlePrint:function(){
		this.getRouter().navTo("print",{});	
	},
	
	handleChatrs:function()	{
		this.getRouter().navTo("graphchart",{});
	},
	
	handleFormat:function()	{
		this.getRouter().navTo("formatter",{});
	},
	
	handleSearch:function()	{
		this.getRouter().navTo("search",{});
	},
	handleMessage:function(){
		this.getRouter().navTo("message",{});
	},
	handleInput:function()	{
		this.getRouter().navTo("input",{});
	},
	handleBinding:function()	{
         this.getRouter().navTo("binding",{});
	},
	handleLink:function()	{
		this.getRouter().navTo("link",{});
	},
	handleOther:function()	{
		this.getRouter().navTo("other",{});
	},
	handleIcon:function()	{
		this.getRouter().navTo("icon",{});
	},
	handleSelect:function()	{
		this.getRouter().navTo("select",{});
	},
	handleLockNumber:function()	{
		this.getRouter().navTo("locknum",{});
	},
	handleCalculations:function(){
		this.getRouter().navTo("calculations",{});
	},
	handleGraphics:function(){
	  this.getRouter().navTo("graphics",{});
	},
	handlesignature:function(){
	  this.getRouter().navTo("sign",{});
	},
	handleFileUpload:function(){
		 this.getRouter().navTo("fileupl",{});
	},
	handleInternilization:function(){
		 this.getRouter().navTo("i18n",{});
	},
	handleVideo:function(){
		 this.getRouter().navTo("video",{});
	},
	handlePanel:function(){
		 this.getRouter().navTo("panel",{});
	},
	handleFrame:function(){
		this.getRouter().navTo("frame",{});
	},
	handleControls:function(){
		this.getRouter().navTo("controls",{});
	},
	handleButtons:function(){
		this.getRouter().navTo("button",{});
	},
	
	getRouter : function ()	{
		return sap.ui.core.UIComponent.getRouterFor(this);
	},
	onBack:function(){
		var router=sap.ui.core.UIComponent.getRouterFor(this);
	    router.navTo("main",{});
	}

});