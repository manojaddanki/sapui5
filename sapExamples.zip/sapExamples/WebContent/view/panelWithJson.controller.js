sap.ui.controller("sapExamples.view.panelWithJson", {
	

	onBack:function(){
		var router=sap.ui.core.UIComponent.getRouterFor(this);
	    router.navTo("main",{});
	},
	
	onInit : function() {
		var homePage = this.getView().byId("homePage");
		var that=this;
		that.oPanelItems = new sap.ui.model.json.JSONModel(
				"model/TECHOPSSet.json");

		that.getView().byId("homelistID").setModel(that.oPanelItems);
		that.getView().byId("techopsListID").setModel(that.oPanelItems);
	},

	handleExpanation : function(evt) {
	    var dat=evt.oSource.sId;
	    var index=dat.substr(dat.lastIndexOf("-")+1);
	    var that=this;
		that.oList=that.getView().byId("homelistID");
		var oModel = that.oPanelItems;
        var oData = oModel.getData();
        var path=evt.getSource().getBindingContext().sPath;
        var selectedIndex=path.substring(path.lastIndexOf("/")+1,path.length);
         	for(var i=parseInt(selectedIndex);i<that.oList.getItems().length-1;i++)  {
      	  var temp = oData.TECHOPSSet[i+1];
      	 oData.TECHOPSSet[i+1] =  oData.TECHOPSSet[i];
      	 oData.TECHOPSSet[i] = temp;
            }	
        that.oPanelItems.setData(oData);
        that.getView().byId("idpaneljson1--homePanelID-idpaneljson1--homelistID-"+selectedIndex+"").setExpanded(false);
        that.getView().byId("idpaneljson1--homePanelID-idpaneljson1--homelistID-"+i+"").setExpanded(true);	
  },
	
});