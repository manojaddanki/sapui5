jQuery.sap.require("sap.m.MessageBox");
var MsgAppVar={};
sap.ui.controller("sapExamples.view.S6", {
	onInit: function() {
		MsgAppVar.msgind="All";
		MsgAppVar.mlength="680";
	var MsgPvr={"postingMsgs":[		                           
	                {"message": "Warning Message","severity": "WARNING"},
	                {"message": "Warning Message2","severity": "WARNING"},
	                {"message": "Success Message","severity": "SUCCESS"},
	                {"message": "Information Message","severity": "INFORMATION"},
	                {"message": "Success Message2","severity": "SUCCESS"},
	                {"message": "Information Message2","severity": "INFORMATION"},
	                {"message": "Error Message","severity": "ERROR"},
	                {"message": "Error Message2","severity": "ERROR"}]}
   var oModel = new sap.ui.model.json.JSONModel(MsgPvr);
    sap.ui.getCore().setModel(oModel);
    var oModel = new sap.ui.model.json.JSONModel([ 
	                                              { value: 50, name: "Joe" }, 
	                                              { value: 50, name: "Mary" }, 
	                                              { value: 50, name: "John" }, 
	                                              { value: 50, name: "Kai" }, 
	                                            ]);
	var that=this;
	var oTable = this.getView().byId("rowSelect");
	oTable.bindItems("/",new sap.m.ColumnListItem({
		
		cells : [
					new sap.m.Input({
					value:"{value}",
						}),
						 new sap.m.CheckBox({
		                     select:[that.handleCheckBox2,that]
		                  })
				]
	}));

	 oTable.setModel(oModel);
	
	
},


handleMessagePopover:function()
{
	 var xml = '<core:FragmentDefinition xmlns="sap.m" xmlns:l="sap.ui.layout" xmlns:f="sap.ui.layout.form" xmlns:core="sap.ui.core">'+
     '<Dialog showHeader="false" contentWidth="680px" contentHeight="250px"><subHeader><Bar><contentLeft>'+
     '<SegmentedButton selectedButton="allid"><Button text="All" press="AllMessage" width="25px" id="allid">'+
     '</Button><Button icon="sap-icon://error" width="25px" id="errorid" press="errormessage" />'+
     '<Button icon="sap-icon://warning" width="25px" id="warningid" press="warningmessage" />'+
     '<Button icon="sap-icon://accept" width="25px" id="successid" press="successmessage" />'+
     '<Button icon="sap-icon://hint" width="25px" id="infoid" press="informatiommessage" />'+
     '</SegmentedButton></contentLeft></Bar></subHeader><content><List id="messageslistid" /></content>'+
     '<beginButton><Button text="Close" press="messageDialogClose"></Button></beginButton></Dialog></core:FragmentDefinition>';
      this.dialog2 = new sap.ui.xmlfragment({fragmentContent: xml}, this);
      this.listId=sap.ui.getCore().byId("messageslistid");
      this.messageListBinding();
      this.dialog2.open();
	//sap.m.MessageToast.show("Message Popover");
},
//message filter binding All
AllMessage: function(){
	MsgAppVar.msgind="All";
	this.messageListBinding();
},
//message filter binding Info
informatiommessage: function(){
	MsgAppVar.msgind="INFO";
	this.messageListBinding();
},

//message filter binding ERROR
errormessage:function(){
	MsgAppVar.msgind="ERROR";
	this.messageListBinding();
},

//message filter binding Warning
warningmessage:function(){
	MsgAppVar.msgind="WARNING";
	this.messageListBinding();
	},
//message filter binding Success		
successmessage:function(){
	MsgAppVar.msgind="SUCCESS";
	this.messageListBinding();
	},

//message filter dialog colse		
messageDialogClose: function(){
	this.dialog2.close();
	this.dialog2.destroy();
	
},


//message List BInding
messageListBinding: function(){
	
    	 this.listId.bindAggregation("items",{
			 path : "/postingMsgs",
             filters: [ new sap.ui.model.Filter("severity", sap.ui.model.FilterOperator.Contains, MsgAppVar.msgind=="All"?"":MsgAppVar.msgind) ],
             template : new sap.m.ObjectListItem({
            	 //icon:"{parts:[{path:'severity'}],formatter:'sapmessagepopover.MsgAppIcon.iconValidation'}",
            	 //editable : "{path:'SIndicator',formatter : 'PhysicalInventory.util.Formatter.EIndicator'}",
            	 icon:"{path:'severity',formatter:'sapmessagepopover.MsgAppIcon.iconValidation'}",
            	 title:"{message}",
             })
           });
    	 
this.dialog2.setContentWidth(MsgAppVar.mlength.toString() + "px");
this.listId.attachEventOnce("updateFinished",function() {
	var lst=this.listId.getItems();
	if(lst.length>0 && MsgAppVar.msgind=="All"){
		var domref,mdl,dta;
		for(var i=0;i<lst.length;i++){
			domref=$(document.getElementById(lst[i].sId).children[0].children[0].children[0].children[0].children[0]);
			mdl=lst[i].getBindingContext();
			dta=mdl.getModel().getProperty(mdl.sPath);
			if(dta.severity.toUpperCase()==="INFO"){
				domref.addClass("sapMObjStatusMarker1");
			}else if(dta.severity.toUpperCase()==="WARNING"){
				domref.addClass("sapMOHNumberStateWarning1");
			}else if(dta.severity.toUpperCase()==="SUCCESS"){
				domref.addClass("sapMOHNumberStateSuccess1");
			}else if(dta.severity.toUpperCase()==="ERROR"){
				domref.addClass("sapMOHNumberStateError1");
			}
		}
	}
}, this);
},

// icon validation
iconValidation: function(val){
	
	if(MsgAppVar.msgind=="All"){
		if(val.toUpperCase()==="INFO"){
		return "sap-icon://hint";
		}else if(val.toUpperCase()==="WARNING"){
			return "sap-icon://warning";
		}else if(val.toUpperCase()==="SUCCESS"){
			return "sap-icon://accept";
		}else if(val.toUpperCase()==="ERROR"){
			return "sap-icon://error";
		}
	}
	return "";
},



handleConfirmationMessageBoxPress:function()
{
	var msg="are you interest";
	sap.m.MessageBox.show(msg,{title:"Confirmation",icon:sap.m.MessageBox.Icon.QUESTION});	
},
handleAlertMessageBoxPress:function()
{
	var msg="Alert";
    sap.m.MessageBox.show(msg,{title:"Alert"});
},
handleErrorMessageBoxPress:function()
{
	var msg="Error";
    sap.m.MessageBox.show(msg,{title:"Error",icon:sap.m.MessageBox.Icon.ERROR});
},
handleInfoMessageBoxPress:function()
{
	var msg="Information";
	sap.m.MessageBox.show(msg,{title:"information",icon:sap.m.MessageBox.Icon.INFORMATION});
},
handleWarningMessageBoxPress:function()
{
	var msg="warning";
	sap.m.MessageBox.show(msg,{title:"warning",icon:sap.m.MessageBox.Icon.WARNING});
},
handleSuccessMessageBoxPress:function()
{
	var msg="success";
	sap.m.MessageBox.show(msg,{title:"success",icon:sap.m.MessageBox.Icon.SUCCESS});

},
handleMessageToastPress:function()
{
	sap.m.MessageToast.show("Message Toast");
},

getRouter : function () 
{
	return sap.ui.core.UIComponent.getRouterFor(this);
},

                              onBack:function()
                          	{
                            	  var router=sap.ui.core.UIComponent.getRouterFor(this);
                            	    router.navTo("main",{});
                          	},
                          	
                          	
                          	
                            handleCheckBox2:function(evt){
                                var table2=this.getView().byId("rowSelect");
                                  var src=evt.oSource;
                                  var val=src.getSelected();
                                  var path=evt.oSource.getBindingContext().sPath;
                                  var ix=path.substring(path.lastIndexOf("/")+1,path.length);
                                  var Qnty=table2.getItems()[ix].getCells()[0].getValue();
                                  if(val&&Qnty>0){
                                 	 var msg= "Quantity "+Qnty+" will be deleted"
                                 	sap.m.MessageBox.show(msg,{title: "Confirmation",
                                 		    icon: sap.m.MessageBox.Icon.QUESTION,
                                 		    actions: [sap.m.MessageBox.Action.CANCEL,sap.m.MessageBox.Action.OK],
                                 		    onClose : function(oAction){
                                 		    if(oAction=="OK"){
                                 		    	 var val=table2.getItems()[ix].getCells()[1].getSelected();
                                                  if(val)
                                                  {
                                                	  table2.getItems()[ix].getCells()[0].setValue("0");
                                                	  table2.getItems()[ix].getCells()[0].setEnabled(false);                                                      }
                                                  }
                                                  else
                                                  {
                                                 	 src.setSelected(false);
                                                  }	 
                                 		    }});
                                 } 
                                 else
                                 {
                               	  table2.getItems()[ix].getCells()[0].setEnabled(true); 
                                 }
                                	  }
                                  /* else if(val&&table2.getModel().oData.Articles2[ix].Indicator!=="S"){
                                    table2.getItems()[ix].getCells()[2].setEnabled(false);
                                  }  else {
                                    table2.getItems()[ix].getCells()[2].setEnabled(true); } 
                                }*/,
                          	
                          	
});