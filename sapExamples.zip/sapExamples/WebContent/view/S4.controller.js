sap.ui.controller("sapExamples.view.S4", {
	onInit: function() {
		sap.ui.getCore().setModel(new sap.ui.model.json.JSONModel({
	        numbers: [{value: 1000}, {value: 20000}, {value: 300000}, {value: 4000000}]
	      }));
		 var oExoticDecimalTypeForUS = new sap.ui.model.type.Float({
		        groupingEnabled: true,
		        groupingSeparator: "-",
		        minFractionDigits: 2
		      }); 
		var model=sap.ui.getCore().getModel();
		 this.getView().setModel(model);
		 var oTable=this.getView().byId("rowSelect");
		 oTable.bindItems("/numbers",new sap.m.ColumnListItem({
				cells : [
				         new sap.m.Text({
								text:{
								 path: "value",
		                           // type: new sap.ui.model.type.Float({ minFractionDigits: 2, maxFractionDigits: 2 })}
								  type:	oExoticDecimalTypeForUS}
								}),
				         ]
		}))
	},
	
	
   
	getRouter : function () 
	{
		return sap.ui.core.UIComponent.getRouterFor(this);
	},

 
	
	onBack:function()
        	{
               	  var router=sap.ui.core.UIComponent.getRouterFor(this);
           	    router.navTo("main",{});
           	},

	
	
});