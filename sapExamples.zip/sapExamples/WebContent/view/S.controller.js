sap.ui.controller("sapExamples.view.S", {
	onInit: function() {
	},

	onLoginTap:function(){
		  var uid = this.getView().byId("uid").getValue();
		  var pasw = this.getView().byId("pasw").getValue();
		  /*sap.m.MessageToast.show("User Id: "+uid+" Password: "+pasw);*/
	     if(uid==="Manoj"&&pasw==="1201225"){
	    	 this.getRouter().navTo("tiles",{}); 
	     }	
	     else{
	    	 sap.m.MessageToast.show("Crenditials are Invalid");
	     }
	},
	
	getRouter : function ()	{
		return sap.ui.core.UIComponent.getRouterFor(this);
	},
	

});