jQuery.sap.require("sap.ui.core.mvc.Controller");
jQuery.sap.require("sap.ca.ui.model.format.DateFormat");
jQuery.sap.require("sap.m.MessageBox");
sap.ui.core.mvc.Controller.extend("sapExamples.view.print", {

	onInit : function() {
		var oModel = new sap.ui.model.json.JSONModel([ 
		                                              { SalesDocNum: "50", CustomerName: "Joe" ,DeliveryNum:"1225"}, 
		                                              { SalesDocNum: "50", CustomerName: "Mary",DeliveryNum:"1208" }, 
		                                              { SalesDocNum: "50", CustomerName: "John",DeliveryNum:"1258" }, 
		                                              { SalesDocNum: "50", CustomerName: "Kai", DeliveryNum:"1242"}, 
		                                            ]);
		
	    this.getView().setModel(oModel);
		var oTable = this.getView().byId("tblDetails");
		oTable.bindItems("/", new sap.m.ColumnListItem({
				cells : [ new sap.m.Text({
					text : "{CustomerName}"
				}), new sap.m.Text({
					text : "{SalesDocNum}"
				}), new sap.m.Text({
					text : "{DeliveryNum}"
				}), ]
			}));
		
		},
	handlePrint : function() {
	    
		var oTable = this.getView().byId("tblDetails");     
		var selectedItems = oTable.getSelectedItems();
		if(selectedItems.length!=0)
		{
			sap.m.MessageToast.show("Select One Item From Table");
		}
			var dd = {
				content : [ {
					table : {
						headerRows : 1,
						width : [ '*', 'auto', 'auto' ],
						body : [ ['Customer Name','Order No.', 'Delivery No.']]
					}
				}]
			};
			function convertImgToBase64(url, callback, outputFormat){
				var img = new Image();
				img.crossOrigin = 'Anonymous';
				img.onload = function(){
				    var canvas = document.createElement('CANVAS');
				    var ctx = canvas.getContext('2d');
					canvas.height = this.height;
					canvas.width = this.width;
				  	ctx.drawImage(this,0,0);
				  	var dataURL = canvas.toDataURL(outputFormat || 'image/png');
				  	callback(dataURL);
				  	canvas = null; 
				};
				img.src = url;
			}
			for (var i = 0; i < selectedItems.length; i++) {
				dd.content[0].table.body.push([
											selectedItems[i].mAggregations.cells[0].mProperties.text,
											selectedItems[i].mAggregations.cells[1].mProperties.text,
											selectedItems[i].mAggregations.cells[2].mProperties.text ]);
			}
			pdfMake.createPdf(dd).open();
	},
	navHomeBack : function() {
		  var router=sap.ui.core.UIComponent.getRouterFor(this);
		    router.navTo("main",{});
	},
	onExit : function() {
		if (this.oPopup !== undefined) {
			this.oPopup.destroy();
		}
	},
});