jQuery.sap.require("sap.m.MessageBox");
sap.ui.controller("sapExamples.view.S72", {


	onInit: function() {
	},
	handleValidate:function()
	{
		var ui,un,upass,ph,add;
		 ui=this.handleUserId();
		 if(ui==true)
		{
			  upass=this.handleUserPassword();
		}
		 if(upass==true)
			{
			 un=this.handleUserName();
			}
	    if(un==true)
		{	
		   ph=this.handlePhone();
		}
		 if(ph==true)
		{	
		//add=this.ValidateEmail();
		}
		/* if(add==true)
		{
		this.handleAdress();
		}*/
		else
		{
			return false;
		}	
		},

		handleUserId:function()
		{
			var uid=this.getView().byId("userid").getValue();
			 var my=5;
			 var mx=12;
			var uid_len = uid.length;  
			if (uid_len == 0 || uid_len <= my || uid_len >= mx)  
			{  
			sap.m.MessageToast.show("User Id should not be empty / length be between "+my+" to "+mx);  
			return false;  
			}  
			return true;
		},
		
		handleUserPassword:function()
		{
			
			var upw=this.getView().byId("password").getValue();
			var my=7
			var mx=12
			var uid_len = upw.length;  
			if (uid_len == 0 || uid_len <= my || uid_len >= mx)  
			{  
			sap.m.MessageToast.show("Password should not be empty / length be between "+my+" to "+mx);  
			return false;  
			}  
			return true;
		},
		
	 handleUserName:function()  
	{   
	     var uname=this.getView().byId("username").getValue();
		 var letters = /^[A-Za-z]+$/;  
	if(uname.match(letters))  
	{  
	return true;  
	}  
	else  
	{  
    sap.m.MessageToast.show('Username must have alphabet characters only');   
	return false;  
	}  
	},  
	
	handlePhone:function()
	{
	    
		var no =this.getView().byId("phone").getValue();
	    if(no ===""){
	        sap.m.MessageToast.show("Please write your Phone Number");
	        return false;
	    }
	    else if( no.length != 10){
	    	sap.m.MessageToast.show("enter valid number");
	        return false;
	    }
	    return true;
	},
	
	 ValidateEmail:function(uemail)  
	{  
    uemail=this.getView().byId("email").getValue();		 
	var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;  
	if(uemail.match(mailformat))  
	{  
	return true;  
	}  
	else  
	{  
	sap.m.MessageToast.show("You have entered an invalid email address!");  
	return false;  
	}  
	}, 
	
	handleAdress:function()
	{
		debugger;
		var letters = /^[0-9a-zA-Z]+$/;  
		var uadd=this.getView().byId("addrs").getValue();
		if(uadd.match(letters))  
		{  
		return true;  
		}  
		else  
		{  
			sap.m.MessageToast.show('User address must have alphanumeric characters only');  
		return false;  
		}	
	},
	
	
	onBack:function()
	{
		this.getRouter().navTo("input",{});
	},

getRouter : function () 
	{
		return sap.ui.core.UIComponent.getRouterFor(this);
	},

});