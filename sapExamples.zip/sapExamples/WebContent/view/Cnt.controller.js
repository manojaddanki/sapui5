sap.ui.controller("sapExamples.view.Cnt", {
    onInit:function(){
    	
    },
    handleUrl:function(){
    	this.getRouter().navTo("url",{});
    },
	
    getRouter : function ()	{
		return sap.ui.core.UIComponent.getRouterFor(this);
	},
	onBack:function(){
		var router=sap.ui.core.UIComponent.getRouterFor(this);
	    router.navTo("main",{});
	}
});