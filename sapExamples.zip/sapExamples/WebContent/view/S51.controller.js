sap.ui.controller("sapExamples.view.S51", {

	onInit: function() {
		 var data = [{
             PoNumber: "1000",
             name: "Item 01"
         },
         {
             PoNumber: "1100",
             name: "Item 02"
         }, {
             PoNumber: "2000",
             name: "Item 03"
         }, {
             PoNumber: "2001",
             name: "Item 04"
         }, {
             PoNumber: "2002",
             name: "Item 05"
         }];
         //data = [];
         var oModel = new sap.ui.model.json.JSONModel();
         oModel.setData(data);
        this.getView().setModel(oModel);
	},

	
	searchCustomer:function(oEvent)
	{
		var tpmla = oEvent.getParameter("newValue");
        var filters = new Array();
        var oFilter = new sap.ui.model.Filter("PoNumber", sap.ui.model.FilterOperator.Contains, tpmla);
        filters.push(oFilter);

        //get list created in view
        this.oList = this.getView().byId("polist");
        this.oList.getBinding("items").filter(filters);
	},
	
	onBack:function()
	{
		this.getRouter().navTo("search",{});
	},

getRouter : function () 
	{
		return sap.ui.core.UIComponent.getRouterFor(this);
	},
});