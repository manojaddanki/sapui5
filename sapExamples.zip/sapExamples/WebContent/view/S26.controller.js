sap.ui.controller("sapExamples.view.S26", {
	
	onInit: function() {
		this.mdData = {
	               Employees:[
	                         {firstName:"Pal", lastName:"saran",age:"25",address:"Salem", id: "1"},
	                         {firstName:"Mahesh", lastName:"babu", age:"28",address:"Hosur",id: "2"},
	                ]
	   };
	    this.oModel = new sap.ui.model.json.JSONModel();
	    this.oModel.setData(this.mdData);
	   sap.ui.getCore().setModel(this.oModel);
	   this.bindTable();
	},
	

	onBack:function()
	{
		this.getRouter().navTo("table",{});
	},

getRouter : function () 
	{
		return sap.ui.core.UIComponent.getRouterFor(this);
	},
	
	addData:function()
	{
		var that=this;
		var fname = that.getView().byId('name').getValue();
		var lname = that.getView().byId('name2').getValue();
		var age = that.getView().byId('age').getValue();
		var address = that.getView().byId('address').getValue();
		that.mdData.Employees.push({"firstName":fname,"lastName":lname,"age":age,"address":address,"id":1});
		that.oModel.setData(that.mdData);
		alert("Data added successfully");
	    that.bindTable();
	},
	deleteData:function()
	{
		var that=this
		that.mdData.Employees.splice(0,1);
		that.oModel.setData(that.mdData);
		alert("Data deleted successfully");
	    that.bindTable();
	},
	 bindTable:function()
	{
		var oTable=this.getView().byId("rowSelect"); 
		oTable.bindItems("/Employees",new sap.m.ColumnListItem({
				cells : [
							new sap.m.Text({
							text:"{id}",
							 }),
							 new sap.m.Text({
									text:"{firstName}",
									 }),
									 new sap.m.Text({
											text:"{lastName}",
											 }),
											 new sap.m.Text({
													text:"{age}",
													 }),
													 new sap.m.Text({
															text:"{address}",
															 }),
							 ]
			}));
			 oTable.setModel(this.oModel)
	}
});