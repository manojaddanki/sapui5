sap.ui.controller("sapExamples.view.SG2", {
	onInit: function() {
	},

	
		onBack:function(){
			this.getRouter().navTo("graphics",{});
		},
	
	getRouter : function ()	{
		return sap.ui.core.UIComponent.getRouterFor(this);
	},
});