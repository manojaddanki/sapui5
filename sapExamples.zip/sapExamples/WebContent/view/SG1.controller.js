sap.ui.controller("sapExamples.view.SG1", {

	onInit: function() {
	},

	onBack:function(){
		this.getRouter().navTo("graphics",{});
	},

	press:function(){
		sap.m.MessageToast.show("The radial micro chart is pressed.");
	},
	
	getRouter : function ()	{
		return sap.ui.core.UIComponent.getRouterFor(this);
	},
});