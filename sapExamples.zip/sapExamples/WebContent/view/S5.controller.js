sap.ui.controller("sapExamples.view.S5", {

	onInit:function()
	{
		
	},
	
	handleSearch:function()
	{
		this.getRouter().navTo("searchex",{});
	},
	handleSearch2:function()
	{
		this.getRouter().navTo("searchex2",{});
	},
    
onBack:function()
	{
	  var router=sap.ui.core.UIComponent.getRouterFor(this);
	    router.navTo("main",{});
	},
      
	getRouter : function () 
	{
		return sap.ui.core.UIComponent.getRouterFor(this);
	}

 
	
});