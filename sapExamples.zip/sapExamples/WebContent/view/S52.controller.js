sap.ui.controller("sapExamples.view.S52", {
	onInit: function() {
		var model = new sap.ui.model.json.JSONModel({
			  Customers : [
			    {name: 'April'},
			    {name: 'Bob'},
			    {name: 'Cathy'}
			  ]
			});
 this.getView().setModel(model);
	},

	onBack:function()
	{
		this.getRouter().navTo("search",{});
	},

getRouter : function () 
	{
		return sap.ui.core.UIComponent.getRouterFor(this);
	},
});