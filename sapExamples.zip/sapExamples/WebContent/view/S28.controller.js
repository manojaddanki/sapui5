sap.ui.controller("sapExamples.view.S28", {
	onInit: function() {
		 this.oTable=this.getView().byId("rowSelect"); 
		   sap.ui.getCore().setModel(new sap.ui.model.json.JSONModel({
		        numbers: [{column1: 1000,column2: 100}, {column1: 2000,column2: 200}, {column1: 3000,column2: 300}, {column1: 4000,column2: 400}]
		      }));
		   this.bindTable();
	},
	
	
	onBack:function()
	{
		this.getRouter().navTo("table",{});
	},
	
	 bindTable:function()
		{
			var oModel = sap.ui.getCore().getModel();
			this.oTable.bindItems("/numbers",new sap.m.ColumnListItem({
					cells : [
								new sap.m.Text({
								text:"{column1}",
								 }),
								 new sap.m.Text({
										text:"{column2}",
										 }),
								 ]
				}));
			this.oTable.setModel(oModel)
		},
		
		pressUp:function()
		{
			var oModel = sap.ui.getCore().getModel();
	          var oData = oModel.getData();
	          var path=this.oTable.getSelectedItem().oBindingContexts.undefined.sPath;
	          var selectedIndex=path.substring(path.lastIndexOf("/")+1,path.length);
	         // var selectedIndex =this.oTable.getSelectedIndex();
	          if(selectedIndex>=1)
	          {
	             var temp = oData.numbers[selectedIndex-1];
	            oData.numbers[selectedIndex-1] = oData.numbers[selectedIndex];
	            oData.numbers[selectedIndex] = temp;
	             //this.oTable.setSelectedIndex(selectedIndex-1);
	           this.oTable.indexOfItem(this.oTable.getSelectedItem())
	           }
	          oModel.setData(oData);
	          this.bindTable();
		},
		pressDown:function()
		{
			
			var oModel = sap.ui.getCore().getModel();
	          var oData = oModel.getData();
	          var path=this.oTable.getSelectedItem().oBindingContexts.undefined.sPath;
	          var selectedIndex=path.substring(path.lastIndexOf("/")+1,path.length);
	          var ln=oData.numbers.length-1
	          if(selectedIndex<ln)
	          {
	             var temp = oData.numbers[parseInt(selectedIndex)+1];
	            oData.numbers[parseInt(selectedIndex)+1] = oData.numbers[parseInt(selectedIndex)];
	            oData.numbers[parseInt(selectedIndex)] = temp;
	         //  this.oTable.setSelectedIndex(selectedIndex+1);
	            
	          }
	          oModel.setData(oData);
	          this.bindTable();
		},
		pressTop:function()
		{
			
			var oModel = sap.ui.getCore().getModel(); 
	          var oData = oModel.getData();
	          var path=this.oTable.getSelectedItem().oBindingContexts.undefined.sPath;
	          var selectedIndex=path.substring(path.lastIndexOf("/")+1,path.length);
	       
	        for(i=selectedIndex;i>0;i--)
	        {
	        	var temp = oData.numbers[i-1];
	            oData.numbers[i-1] = oData.numbers[i];
	            oData.numbers[i] = temp;
	        }	
	          oModel.setData(oData);
	          this.bindTable();
		},
		pressBottom:function()
		{
			  debugger;
			var oModel = sap.ui.getCore().getModel();
	          var oData = oModel.getData();
	          var path=this.oTable.getSelectedItem().oBindingContexts.undefined.sPath;
	          var selectedIndex=path.substring(path.lastIndexOf("/")+1,path.length);
	          for(i=parseInt(selectedIndex);i<this.oTable.getItems().length-1;i++)
		        {
	        	  var temp = oData.numbers[i+1];
		            oData.numbers[i+1] = oData.numbers[i];
		            oData.numbers[i] = temp;
	              }	
		         oModel.setData(oData);
	          this.bindTable();
		},

getRouter : function () 
	{
		return sap.ui.core.UIComponent.getRouterFor(this);
	},

});