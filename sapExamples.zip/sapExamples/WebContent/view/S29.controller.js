sap.ui.controller("sapExamples.view.S29", {
	onInit: function() {
		this.oTable=this.getView().byId("rowSelect");
		   // Sales Areas
		    var oAreas = {
		        "North West": ["Manchester", "Liverpool", "Lancaster"],
		        "South East": ["London", "Brighton"],
		        "North East": ["Middlesbrough", "Newcastle", "Hull"]
		    };
		    
		    // Generate some sales figures into a flat array of region/town/amount objects
		    var oSalesFigures = [];
		    oSalesFigures = oSalesFigures.concat.apply(oSalesFigures, Object.keys(oAreas).map(function(region) {
		        return oAreas[region].map(function(town) { 
		            return { "region": region, "town": town, "amount": (Math.random()*1000000+1).toFixed(2) };
		        });
		    }));

		     this.oModel = new sap.ui.model.json.JSONModel({ "sales": oSalesFigures });
		    sap.ui.getCore().setModel(this.oModel);
		    this.bindTable();
	},
	
	pressSort:function()
	{
		
		var oData = this.oModel.getData();
        oData.sales.sort(function(a, b) {
            if (a.region === b.region) return 0;
            return a.region > b.region ? 1 : -1;
        });
        this.oModel.setData(oData);
        this.bindTable();
	},
	pressMixUp:function()
	{
		
		var oData = this.oModel.getData();
        oData.sales.sort(function() { return Math.random()-0.5; });
        this.oModel.setData(oData);
        this.bindTable();
	},
	
	bindTable:function()
	{
		
		var oModel = sap.ui.getCore().getModel();
		this.oTable.bindItems("/sales",new sap.m.ColumnListItem({
				cells : [
							new sap.m.Text({
								text:"{region}",
							 }),
							 new sap.m.Text({
									text:"{town}",
									 }),
									 new sap.m.Text({
										text:{
										 path: "amount",
				                            type: new sap.ui.model.type.Float({ minFractionDigits: 2, maxFractionDigits: 2 })}
											 }),
						]
			}));
		
		this.oTable.setModel(oModel)
	},
   
	onBack:function()
	{
		this.getRouter().navTo("table",{});
	},

getRouter : function () 
	{
		return sap.ui.core.UIComponent.getRouterFor(this);
	},

});