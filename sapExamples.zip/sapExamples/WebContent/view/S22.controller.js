sap.ui.controller("sapExamples.view.S22", {
	onInit: function() {
		var oModel = new sap.ui.model.json.JSONModel({
		      ItemSet : [
			    {
		          "ID": 1,
		          "Fruit": "Apple",
		          "Enabled": "X"     
		        },
		        {
		          "ID": 2,
		          "Fruit": "Banana",
		          "Enabled": ""     
		        },
		        {
		          "ID": 3,
		          "Fruit": "Blueberry",
		          "Enabled": "X"     
		        }
		      ]
		    });
		  
		 var oTable = this.getView().byId("rowSelect");
			oTable.bindItems("/ItemSet",new sap.m.ColumnListItem({
				
				cells : [
							new sap.m.Text({
							text : "{ID}",
								}),
							new sap.m.Text({
								text : "{Fruit}"
								})
						]
			}));

			 oTable.setModel(oModel);
	},
	
	onBack:function()
	{
		this.getRouter().navTo("table",{});
	},
	
	handelArray:function()
	{
var oTable = this.getView().byId('rowSelect');
var aItems = oTable.getItems();
var aArray = [];
for(i=0,len=aItems.length;i<len;i++){
  aArray.push(aItems[i].getAggregation("cells")[1].getProperty("text"));
}
sap.m.MessageToast.show(aArray);
	},
	
	getRouter : function () 
	{
		return sap.ui.core.UIComponent.getRouterFor(this);
	}

});