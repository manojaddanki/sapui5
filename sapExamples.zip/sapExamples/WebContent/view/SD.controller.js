jQuery.sap.require("sap.m.MessageBox");
sap.ui.controller("sapExamples.view.SD", {
	onInit: function() {
		 var oModel = new sap.ui.model.json.JSONModel();
	        oModel.setData({
	            "staff": [
	                {
	                    "city" : ""
	                },
	                {
	                    "city" : "berlin",
	                    "genders" : [
	                        { 
	                            "gender" : "male", 
	                            "people" : [
	                                {"firstName": "Lasse", "lastName": "Larsson"},  
	                                {"firstName": "Gerrit", "lastName": "Gartner"}
	                            ]
	                        },
	                        { 
	                            "gender" : "female", 
	                            "people" : [
	                                {"firstName": "Paris", "lastName": "Hilton"},  
	                                {"firstName": "Kate", "lastName": "Upton"}
	                            ]
	                        },
	                    ]
	                },
	                {
	                    "city" : "paris",
	                    "genders" : [
	                        { 
	                            "gender" : "male", 
	                            "people" : [
	                                {"firstName": "Lasse", "lastName": "Larsson"},  
	                                {"firstName": "Gerrit", "lastName": "Gartner"}
	                            ]
	                        },
	                        { 
	                            "gender" : "female", 
	                            "people" : [
	                                {"firstName": "Lasse", "lastName": "Larsson"},  
	                                {"firstName": "Gerrit", "lastName": "Gartner"}
	                            ]
	                        },
	                    ]
	                },
	                {
	                    "city" : "oslo",
	                    "genders" : [
	                        { 
	                            "gender" : "male", 
	                            "people" : [
	                                {"firstName": "Lasse", "lastName": "Larsson"},  
	                                {"firstName": "Gerrit", "lastName": "Gartner"}
	                            ]
	                        },
	                        { 
	                            "gender" : "female", 
	                            "people" : [
	                                {"firstName": "Lasse", "lastName": "Larsson"},  
	                                {"firstName": "Gerrit", "lastName": "Gartner"}
	                            ]
	                        },
	                    ]
	                },
	            ]
	        });
	        this.getView().setModel(oModel);
	        var pune = [
			            	{lastName: "Dhoni", firstname: "Mahendrasingh", gender: "male"},
			            	{lastName: "Smith", firstname: "Steve", gender: "male"},
			            	{lastName: "Ashwin", firstname: "RaviChandra", gender: "male"},
			            	{lastName: "Rahane", firstname: "Anjikaya", gender: "male"},
			            	{lastName: "duplesis", firstname: "fat", gender: "male"},
			            ];
	        this.Model1 = new sap.ui.model.json.JSONModel(pune);
	        
	},
	
	 handleStaffSelect : function(oEvent) {
	        var oGender = this.byId("selGender");
	        var oTemplate = new sap.ui.core.ListItem({ key : "{gender}", text : "{gender}"})
	        oGender.bindItems(oEvent.getParameter("selectedItem").getBindingContext().getPath() + "/genders", oTemplate);
	    },

	    handleGenderSelect : function(oEvent) {
	        var oGender = this.byId("selPerson");
	        var oTemplate = new sap.ui.core.ListItem({ key : "{lastName}", text : "{lastName}"})
	        oGender.bindItems(oEvent.getParameter("selectedItem").getBindingContext().getPath() + "/people", oTemplate);
	    },
	    
	    
	    
	    //Define Value Help Function For Segment
	    handleValueHelpSelect:function(oEvent)
        {
        	//sap.ui.getCore().byId("sgmSearchId").setValue("");	
        if (!this.inpDialog) {
            this.inpDialog = new sap.ui.xmlfragment(
                "sapExamples.view.Segment", this);
          }
        var sgmSrchId=sap.ui.getCore().byId("sgmSearchId");
    	if(sgmSrchId.getValue()!="")
    	{
    		sgmSrchId.setValue("");
    	}
          //var oTable=sap.ui.getCore().byId("segmentTable");
          var oTable=sap.ui.getCore().byId("sgmTable");
          
            var that=this;
          oTable.unbindAggregation("items");
          oTable.setModel(this.Model1);
            oTable.bindItems("/", new sap.m.ColumnListItem({
              cells : [
                  new sap.m.Text({
                text : "{lastName}",
              }),new sap.m.Text({
                text : "{firstname}",
              })
                 ]
            }));
            that.inpDialog.open();
             },
             
            //Closing Segment Fragment
             handleSegmentClose:function()
             {
               this.inpDialog.close(); 
             },
             
            //Perform Segment Operation
             handleSegmentPerform:function(oEvent)
             {
               //var selected=sap.ui.getCore().byId("segmentTable").getSelectedItem();
              var selected=sap.ui.getCore().byId("sgmTable").getSelectedItem();

                 if (selected === ""||selected === null) {
                       sap.m.MessageToast.show("Select atleast one item");
                        return;
                     }  
               //var segmentTabel=sap.ui.getCore().byId("segmentTable");
               var segmentTabel=sap.ui.getCore().byId("sgmTable");
                 var itemsln=segmentTabel.getSelectedItems().length;
                 this.getView().byId("slctId").setTokens("");
               for(var v=0;v<itemsln;v++){
                  var sg=segmentTabel.getSelectedItems()[v].mAggregations
                    var token =sg.cells[0].mProperties.text;
                      var token2 =sg.cells[1].mProperties.text;
                      this.getView().byId("slctId").addToken(new sap.m.Token({text:token+"-"+token2}));
               }
           	 
               this.inpDialog.close();
             },
    
             //Define Search Function For Segment Category 
            segmSearch: function(oEvent)
           {
               var sValue=oEvent.oSource.getValue().toLowerCase();
             // var itemsln=sap.ui.getCore().byId("segmentTable").getItems();
              var itemsln=sap.ui.getCore().byId("sgmTable").getItems();
           //   var itemsln = oEvent.oSource.oParent.oParent.oParent.mAggregations.content[0].mAggregations.content[0].oModels.undefined.oData.results;
              for (var i = 0; i < itemsln.length; i++) {
                var sgsch=itemsln[i].mAggregations.cells
              var val = sgsch[0].mProperties.text;
                var val1 =sgsch[1].mProperties.text.toLowerCase();
               if (val.indexOf(sValue) > -1 ||val1.indexOf(sValue) > -1 ) {
                   itemsln[i].setVisible(true);
               } else {
                   itemsln[i].setVisible(false);
               }
        }
           },  
           
           handleMessage:function()
           {
        	   var that=this;
        	   var  Segment=that.getView().byId("slctId").getTokens();
        	   if (Segment.length === 0) {
                   var Segement1 ="";
                  } else if (Segment.length === 1) {
                      var seg=Segment[0].mProperties.text; 
                    Segement1= "\nName: '" + seg.substring(0,seg.indexOf('-'))+ "'  ";
                  } else if (Segment.length > 1) {
                      for (var i = 0; i < Segment.length; i++) {
                        var seg1=Segment[i].mProperties.text;
                         if (i === 0) {
                      	 Segement1= "\nName: '" + seg1.substring(0,seg1.indexOf('-'))+ "'";
                          } else {
                            Segement1+= "\nName: '" + seg1.substring(0,seg1.indexOf('-'))+ "'";
                          }
                      }
                      Segement1;
                }
        	   sap.m.MessageToast.show(Segement1);
        	   //sap.m.MessageBox.show(Segement1);
           },
           
	    onBack:function(){
			var router=sap.ui.core.UIComponent.getRouterFor(this);
		    router.navTo("main",{});
			},

			getRouter : function () 
			{
				return sap.ui.core.UIComponent.getRouterFor(this);
			},
			
			onExit:function()
			{
				if(this.inpDialog!==undefined) {
          		  this.inpDialog.destroy();
                 }
			}

});