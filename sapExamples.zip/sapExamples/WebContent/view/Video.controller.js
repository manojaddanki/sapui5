sap.ui.controller("sapExamples.view.Video", {
	onInit: function() {
	},

	onBack:function(){
		var router=sap.ui.core.UIComponent.getRouterFor(this);
	    router.navTo("main",{});
		}, 
	
});