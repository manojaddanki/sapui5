sap.ui.controller("sapExamples.view.Btn", {

	onInit: function() {
	},

	onBack:function(){
		var router=sap.ui.core.UIComponent.getRouterFor(this);
	    router.navTo("main",{});
		}, 

		handlButton:function(){
		sap.m.MessageToast.show("Accepted");	
		},
		
		
		onDefaultAction: function() {
			sap.m.MessageToast.show("Default action triggered");
		},
		onDefaultActionAccept: function() {
			sap.m.MessageToast.show("Accepted");
		},
		onMenuAction: function(oEvent) {
			var oItem = oEvent.getParameter("item"),
				sItemPath = "";
			while (oItem instanceof sap.m.MenuItem) {
				sItemPath = oItem.getText() + " > " + sItemPath;
				oItem = oItem.getParent();
			}

			sItemPath = sItemPath.substr(0, sItemPath.lastIndexOf(" > "));

			sap.m.MessageToast.show("Action triggered on item: " + sItemPath);
		}
});