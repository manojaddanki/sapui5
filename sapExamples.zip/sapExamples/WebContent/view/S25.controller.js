sap.ui.controller("sapExamples.view.S25", {
	onInit: function() {
		var demoData = 
	       {
	         "ProductCollection": [
				{
					"ProductId": "1239102",
					"Name": "Power Projector 4713",
					"Category": "Projector",
					"SupplierName": "Titanium",
					"Description": "A very powerful projector with special features for Internet usability, USB",
					"WeightMeasure": 1467,
					"WeightUnit": "g",
					"Price": "856.49",
					"CurrencyCode": "EUR",
					"Status": "Available",
					"Quantity": "3",
					"UoM": "PC",
					"Width": "51",
					"Depth": "42",
					"Height": "18",
					"DimUnit": "cm",
					"ProductPicUrl": "https://openui5.hana.ondemand.com/test-resources/sap/ui/demokit/explored/img/large_HT-6100.jpg"
				},
				{
					"ProductId": "OP-38800002",
					"Name": "High End Laptop 2b",
					"Category": "Laptop",
					"SupplierName": "Titanium",
					"Description": "Notebook Professional 17 with 2,3GHz - 17 inches XGA - 2048MB DDR2 SDRAM - 40GB Hard Disc - DVD-Writer (DVD-R/+R/-RW/-RAM)",
					"WeightMeasure": 1190,
					"WeightUnit": "g",
					"Price": "939",
					"CurrencyCode": "EUR",
					"Status": "Out of Stock",
					"Quantity": "18",
					"UoM": "PC",
					"Width": "64",
					"Depth": "34",
					"Height": "4",
					"DimUnit": "cm",
					"ProductPicUrl": "test-resources/sap/ui/demokit/explored/img/HT-1010.jpg"
				},
	           {
				"ProductId": "K47322.1",
				"Name": "Hurricane GX",
				"Category": "Graphics Card",
				"SupplierName": "Red Point Stores",
				"Description": "Hurricane GX: DDR2 RoHS 512MB Supporting 1024MB Clock rate: 550 MHz Memory Clock: 933 MHz, Bus Type: PCI-Express, Memory Type: DDR2 Memory Bus: 64-bit Highlighted Features: DVI Out, TV-In, TV-Out, HDTV",
				"WeightMeasure": 588,
				"WeightUnit": "g",
				"Price": 219,
				"CurrencyCode": "EUR",
				"Status": "Out of Stock",
				"Quantity": 25,
				"UoM": "PC",
				"Width": 34,
				"Depth": 14,
				"Height": 2,
				"DimUnit": "cm",
				"ProductPicUrl": "test-resources/sap/ui/demokit/explored/img/HT-1072.jpg"
			},
			{
				"ProductId": "22134T",
				"Name": "Webcam",
				"Category": "Accessory",
				"SupplierName": "Technocom",
				"Description": "Web camera, color, High-Speed USB",
				"WeightMeasure": 700,
				"WeightUnit": "g",
				"Price": 59,
				"CurrencyCode": "EUR",
				"Status": "Available",
				"Quantity": 22,
				"UoM": "PC",
				"Width": 18,
				"Depth": 19,
				"Height": 21,
				"DimUnit": "cm",
				"ProductPicUrl": "test-resources/sap/ui/demokit/explored/img/HT-1112.jpg"
			},
	          ]
	       };
	       var oModel = new sap.ui.model.json.JSONModel();
	       oModel.setData( demoData );
//	       this.getView().setModel(oModel);
	       var oTable=this.getView().byId("rowSelect");
	       this.getView().setModel( oModel ) ;		              
	       oTable.bindItems("/ProductCollection",new sap.m.ColumnListItem({
				cells : [
							new sap.m.ObjectIdentifier({
							title:'{Name}',
							text:'{ProductId}'
							 }),
							new sap.m.Input({
								type:"Text",
								editable:true,
								value:'{Quantity}',
								description:"{UoM}",
							    fieldWidth:'30%'
							}),
							new sap.m.ObjectNumber({
								number:'{WeightMeasure}',
				     			unit:'{WeightUnit}'
							}),
							new sap.m.ObjectNumber({
								number:'{Price}',
				     			unit:'{CurrencyCode}'
							}),
					]
			}));
			 oTable.setModel(oModel);
	},
	
	deleteItemPressed:function(evt)
	{
        
		var oModel = this.getView().getModel();
		var data = oModel.getData();
		var oTable = this.byId("rowSelect");

		var sItems = oTable.getSelectedItems();
		
		if (sItems.length == 0) {
			sap.m.MessageToast.show("Please Select a row to Delete");
			return;
		} else {
					
      for ( var i = sItems.length - 1; i >= 0; i--) {
					path = sItems[i].getBindingContext().getPath();
					var idx = parseInt(path.substring(path.lastIndexOf('/') + 1));								
					//data.lineitems.splice(idx, 1);							
					oTable.removeItem(idx);		
      }
			oModel.setData(data);
			}
			oTable.removeSelections();
	},
	
	
	
	onBack:function()
	{
		this.getRouter().navTo("table",{});
	},

getRouter : function () 
	{
		return sap.ui.core.UIComponent.getRouterFor(this);
	},

});