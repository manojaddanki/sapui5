sap.ui.controller("sapExamples.view.S3", {
	onInit: function() {

	},
   
	handleOverallForm:function()
	{
		this.getRouter().navTo("form1",{});		
	},
	handleOverallForm2:function()
	{
		this.getRouter().navTo("form2",{});
	},
	
	handleForm3:function(){
		this.getRouter().navTo("form3",{});
	},
	
	onBack:function()
	{
		var router=sap.ui.core.UIComponent.getRouterFor(this);
	    router.navTo("main",{});
	},

getRouter : function () 
	{
		return sap.ui.core.UIComponent.getRouterFor(this);
	},
	
});