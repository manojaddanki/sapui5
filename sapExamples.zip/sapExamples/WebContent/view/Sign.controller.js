sap.ui.controller("sapExamples.view.Sign", {
onInit: function() {
	},

	 onClear: function() {
         
         sap.ui.getCore().getControl("sPad").clear();
         sap.ui.getCore().getControl("sImg").setSrc();
        },
         onSave: function() {
         
         var sImg = sap.ui.getCore().getControl("sPad").save();
         sap.ui.getCore().getControl("sImg").setSrc(sImg);
         
        },
	
	onBack:function(){
		var router=sap.ui.core.UIComponent.getRouterFor(this);
	    router.navTo("main",{});
		}, 
});