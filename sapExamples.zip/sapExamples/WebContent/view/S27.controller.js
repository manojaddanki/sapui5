sap.ui.controller("sapExamples.view.S27", {
	onInit: function() {
		var data = [{ReleaseDate : "" , Description : "SAP1"},
	                   {ReleaseDate : "" , Description : "SAP2"},
	                   {ReleaseDate : "" , Description : "SAP3"}];
		var Article= [
			            
	                     {ArticleNo: 40000008,ArticleDescripiton:"AppleIphone'5's"},
			             {ArticleNo: 40000021,ArticleDescripiton:"LenovoA6000Plus"},
			             {ArticleNo: 40000025,ArticleDescripiton:"AppleIphone'6's"},
			             {ArticleNo: 40000058,ArticleDescripiton:"Nokia 1101"}
			         ];
			 this.oModel = new sap.ui.model.json.JSONModel(Article);
		var that=this;
			 var  oSCNJSon = new sap.ui.model.json.JSONModel(data);  
			 that.getView().setModel(oSCNJSon);
			 that.oTable=this.getView().byId("rowSelect");
			 that.oTable.bindItems("/",new sap.m.ColumnListItem({
					cells : [
								new sap.m.Text({
								text:'{Description}'
								 }),
							    new sap.m.Input({
							    	id:'materialId',
							    	showValueHelp:true,
							    	valueHelpRequest:function()
							    	{that.handleInput();}
							    	})
						]
				}));
	},

	handleInput:function()
    {
		var that=this;
		that._valueHelpDialog2 = new sap.m.SelectDialog({
        title : "Select Material",
        noDataText : "No Entries Found",
        items : {
            path : "/",
          template : new sap.m.StandardListItem({
            title : "{ArticleNo}",
            description : "{ArticleDescripiton}",
          })
        },
        search : [ that._handleValueHelp2Search, that ],
        confirm : [ that._handleValueHelp2Close, that ],
        cancel : [ that._handleValueHelp2Close, that ]
      });
		that._valueHelpDialog2.setModel(this.oModel);
		that._valueHelpDialog2.open();
  },
	
  _handleValueHelp2Close : function(evt) {
	    var oSelectedItem = evt.getParameter("selectedItem");
	    if (oSelectedItem) {
	      var i1 = this.getView().byId("materialId");
	      i1.setValue(oSelectedItem.getTitle()+" - "+oSelectedItem.getDescription());
	      this.Sloc = oSelectedItem.getTitle();
	    }
	  },
	  
	  _handleValueHelp2Search : function(evt) {
	    var sValue = evt.getParameter("value").toLowerCase();
	    var keys = evt.getSource().getBinding("items").aKeys;
	    var smodel =  evt.getSource().getModel();
	    for (var i = 0; i < this._valueHelpDialog2.getItems().length; i++){
	      var val = smodel.getProperty("/" + keys[i]).ArticleNo.toLowerCase();
	      var val1 = smodel.getProperty("/" + keys[i]).ArticleDescripiton.toLowerCase();
	      if (val.indexOf(sValue) > -1 || val1.indexOf(sValue) > -1){
	        this._valueHelpDialog2.getItems()[i].setVisible(true);
	      } else {
	        this._valueHelpDialog2.getItems()[i].setVisible(false);
	      }
	    }
	  },
  
	onBack:function()
	{
		this.getRouter().navTo("table",{});
	},

getRouter : function () 
	{
		return sap.ui.core.UIComponent.getRouterFor(this);
	}

});