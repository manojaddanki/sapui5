sap.ui.controller("sapExamples.view.Iframe", {
	onInit: function() {
	},

	
	onBack:function(){
		var router=sap.ui.core.UIComponent.getRouterFor(this);
	    router.navTo("main",{});
	}
});