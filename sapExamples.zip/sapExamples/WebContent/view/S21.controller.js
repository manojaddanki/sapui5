sap.ui.controller("sapExamples.view.S21", {
	onInit: function() {
		 var oModel = new sap.ui.model.json.JSONModel([ 
				                                              { value: 50, name: "Joe" }, 
				                                              { value: 50, name: "Mary" }, 
				                                              { value: 50, name: "John" }, 
				                                              { value: 50, name: "Kai" }, 
				                                            ]);
				
				var oTable = this.getView().byId("rowSelect");
				oTable.bindItems("/",new sap.m.ColumnListItem({
					
					cells : [
								new sap.m.Text({
								text : "{value}",
									}),
								new sap.m.Text({
									text : "{name}"
									})
							]
				}));
			
				 oTable.setModel(oModel);
	},
	onBack:function()
	{
		this.getRouter().navTo("table",{});
	},
	
	
	handelCheck:function()
	{
		var oTable = this.getView().byId("rowSelect");
		var contexts = oTable.getSelectedContexts();
		var items = contexts.map(function(c){return c.getObject();});
		sap.m.MessageToast.show(JSON.stringify(items));
	},

	getRouter : function () 
	{
		return sap.ui.core.UIComponent.getRouterFor(this);
	},
});