sap.ui.controller("sapExamples.view.S9", {
	onInit: function() {
	},

	onBack:function(){
		var router=sap.ui.core.UIComponent.getRouterFor(this);
	    router.navTo("main",{});
		}, 
		
		getRouter : function () 
		{
			return sap.ui.core.UIComponent.getRouterFor(this);
		}

});