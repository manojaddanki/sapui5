sap.ui.controller("sapExamples.view.S2A", {
	onInit: function() {
		var aData = [
		    			{lastName: "Dente", color: "error", name: "Al", checked: true, linkText: "www.sap.com", href: "http://www.sap.com", rating: 4},
		    			{lastName: "Friese", color: "warning", name: "Andy", checked: true, linkText: "www.spiegel.de", href: "http://www.spiegel.de", rating: 2},
		    			{lastName: "Mann", color: "normal", name: "Anita", checked: false, linkText: "www.kicker.de", href: "http://www.kicker.de", rating: 3}
		    		];
		    		
		    		// create a JSONModel, fill in the data and bind the Table to this model
		    		var oModel = new sap.ui.model.json.JSONModel(aData);
		    		this.getView().setModel(oModel);
		            var oTable=this.getView().byId("rowSelect");
		            oTable.bindItems("/",new sap.m.ColumnListItem({
						cells : [
									new sap.m.Text({
									text:'{lastName}'
									 }),
									 new sap.m.Text({
											text:'{name}'
											 }),
									new sap.m.CheckBox({selected:'{checked}'}),
									new sap.m.Link({text:'{linkText}', href:'{href}' }),
									new sap.m.RatingIndicator({value:'{rating}'})
							]
					}));
	this.StackOverflow();
	},
	
	//Stack Over Flow Scenarios
	//scenario 1 for icon tab bar dynamic
	StackOverflow:function(){
		var model = new sap.ui.model.json.JSONModel();
		model.setData(
		{
		    filter: [
		        { icon: "sap-icon://hint", text: 'hint'},
		        { icon: "sap-icon://comment", text: 'comment'},
		        { icon: "sap-icon://attachment", text: 'attachment'},
		        { icon: "sap-icon://history", text: 'history'},
		    ]
		});

		var iconTabBar = new sap.m.IconTabBar("iconTabBar", {
		    expandable: true,
		    expanded :true,
		});

		iconTabBar.setModel(model, "itbModel"); 
		iconTabBar.bindAggregation("items", "itbModel>/filter", new sap.m.IconTabFilter({icon: "{itbModel>icon}", text:"{itbModel>text}"}));
		
		
	},
	
	onBack:function()
	{
		this.getRouter().navTo("table",{});
	},

getRouter : function () 
	{
		return sap.ui.core.UIComponent.getRouterFor(this);
	},


});