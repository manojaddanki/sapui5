sap.ui.controller("sapExamples.view.SC", {
	onInit: function() {
		var dataObject = [
		  				{Product: "Power Projector 4713", Weight: "1467"},
		  				{Product: "Gladiator MX", Weight: "321"},
		  				{Product: "Hurricane GX", Weight: "588"},
		  				{Product: "Webcam", Weight: "700"},
		  				{Product: "Monitor Locking Cable", Weight: "40"},
		  				{Product: "Laptop Case", Weight: "1289"}];
		  	var model = new sap.ui.model.json.JSONModel();
		  	/*	model.setData({
		  			modelData: {
		  			productsData : []
		  			}
		  			});*/
		  		sap.ui.getCore().setModel(model);
		  		/*sap.ui.getCore().getModel().setProperty("/modelData/productsData", dataObject);*/
	},
	
	onBack:function(){
		var router=sap.ui.core.UIComponent.getRouterFor(this);
	    router.navTo("main",{});
		},

		getRouter : function () 
		{
			return sap.ui.core.UIComponent.getRouterFor(this);
		},
});