sap.ui.controller("sapExamples.view.S2", {

	onInit: function() {
	},

	onBack:function(){
	var router=sap.ui.core.UIComponent.getRouterFor(this);
    router.navTo("main",{});
	}, 
	
	handleTableslctDialog:function()
	{
		this.getRouter().navTo("tblslctdg",{});
	},
	
	handleTable2:function()
	{
		this.getRouter().navTo("tablerow",{});
	},
	handleTable3:function()
	{
		this.getRouter().navTo("tablerowdelete",{});
	},
	handleTable4:function()
	{
		this.getRouter().navTo("tablerowdelete2",{});
	},
	handleTable5:function()
	{
		this.getRouter().navTo("tablerowdelete3",{});
	},
	handleTable6:function()
	{
		this.getRouter().navTo("tableadddelete",{});
	},
	handleTable7:function()
	{
		this.getRouter().navTo("F4insidetable",{});
	},
	handleTable8:function()
	{
		this.getRouter().navTo("rowexchange",{});
	},
	handleTable9:function()
	{
		this.getRouter().navTo("mergcells",{});
	},
	handleTable10:function()
	{
		this.getRouter().navTo("general",{});
	},
	handleTable11:function()
	{
		debugger;
		this.getRouter().navTo("tbcal",{});
	},
	getRouter : function () 
	{
		return sap.ui.core.UIComponent.getRouterFor(this);
	},
});