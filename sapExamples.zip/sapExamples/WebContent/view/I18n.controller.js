sap.ui.controller("sapExamples.view.I18n", {
	onInit: function() {
	},

	check_language:function()
	  {
		var sLocale;
		 var key=this.getView().byId("select_id").getSelectedKey();
		  if(key==="hindi_1")
			  {
			  
			   sLocale ="hi_IN";
			   surl="i18n/messageBundle.properties";
		        }
		  else if(key==="English_1")
			  {
			  
			   //var sLocale = sap.ui.getCore().getConfiguration().getLanguage();
			   sLocale="en_US";
			  surl="i18n/messageBundle.properties";
			  }
		  else if(key==="Gujarati_1")
			  {
			   sLocale="gu_In";
			  surl="i18n/messageBundle.properties";
			  }
		  else if(key==="marathi_1")
		  {
		   sLocale="mr_In";
		  surl="i18n/messageBundle.properties";
		  }
		  var oBundle = jQuery.sap.resources({url : surl, locale: sLocale});
		  
		  this.getView().byId("page").setTitle(oBundle.getText("Title"));
		  this.getView().byId("l1").setText(oBundle.getText("name"));
		  this.getView().byId("l2").setText(oBundle.getText("mobile"));
		  this.getView().byId("l3").setText(oBundle.getText("email"));
		  this.getView().byId("b").setText(oBundle.getText("submit"));
		 },
	
	onBack:function(){
		var router=sap.ui.core.UIComponent.getRouterFor(this);
	    router.navTo("main",{});
		}, 
});