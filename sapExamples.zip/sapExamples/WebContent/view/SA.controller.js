sap.ui.controller("sapExamples.view.SA", {
	onInit: function() {
		this.model = new sap.ui.model.json.JSONModel({
			  list1: [
			    {key: 'chrome', label: 'Chrome'},
			    {key: 'firefox', label: 'Firefox'},
			    {key: 'safari', label: 'Safari'}
			  ],  
			  list2: [
			    {key: 'ie', label: 'Internet Explorer'}
			  ],
			});
	this.getView().setModel(this.model);
	this.StackOverflow();
	/*this.StackOverflow2();*/
	},
	
	submitButton:function()
	{
		var rb=this.getView().byId("rb");
		var idx = rb.getSelectedIndex();
		sap.m.MessageToast.show("Selected Index is:-->  "+idx);
	},
	
	
	listChange:function(e)
	{
		
		var cxt = e.getParameter('listItem').getBindingContext();
        var path = cxt.getPath();
        path = path.substring(path.lastIndexOf('/') +1);
        var idx = parseInt(path);
        this.moveItem(this.model,'/list1', '/list2', idx);
	},
	
	listChange2:function(e)
	{
		
		var cxt = e.getParameter('listItem').getBindingContext();
	        var path = cxt.getPath();
	        path = path.substring(path.lastIndexOf('/') +1);
	        var idx = parseInt(path);
	       this.moveItem(this.model, '/list2', '/list1', idx);
	},
	moveItem:function(m, fromList, toList, idx)
	{
		
		var list = m.getProperty(fromList);
		  var rm = list.splice(idx, 1);
		  m.setProperty(fromList, list);
		  m.setProperty(toList, m.getProperty(toList).concat(rm));
		  m.refresh();
	},
	
	
	//Stack Over Flow Scenarios
	//scenario 1 for icon tab bar dynamic
	StackOverflow:function(){
		var model = new sap.ui.model.json.JSONModel();
		model.setData(
		{
		    filter: [
		        { icon: "sap-icon://hint", text: 'hint'},
		        { icon: "sap-icon://comment", text: 'comment'},
		        { icon: "sap-icon://attachment", text: 'attachment'},
		        { icon: "sap-icon://history", text: 'history'},
		    ]
		});

		var iconTabBar = new sap.m.IconTabBar("iconTabBar", {
		    expandable: true,
		    expanded :true,
		});

		iconTabBar.setModel(model, "itbModel"); 
		iconTabBar.bindAggregation("items", "itbModel>/filter", new sap.m.IconTabFilter({icon: "{itbModel>icon}", text:"{itbModel>text}"}));
		this.byId("addContentId").addContent(iconTabBar);
		
	},
	
	//scenario 2 for icon tab bar dynamic
	StackOverflow2:function(){debugger;
		var oModel = new sap.ui.model.json.JSONModel({
            "idocs1" : [ {
                    "Docnum" : "00063463",
                    "Mestyp" : "MATMAS",
                    "Status" : "53",
                    "Sndprn" : "EXTSYS1",
                    "Direct" : "Inbound",
                    "Message" : "Material 00002342 Created",
                    "messages" : [ {
                        "message" : "Material 00002342 Created"
                    } ],
                    "segments" : [ {
                        "segment" : "E1MARAM",
                        "fields" : [ {
                            "fieldName" : "MATNR"
                        } ]

                    } ]
                } ]
            });
            sap.ui.getCore().setModel(oModel);
            var tgtPath = "/idocs1/0/segments";
            var oTree = new sap.ui.commons.Tree("tree");
            oTree.bindAggregation("nodes", tgtPath, function(
                    sId, oContext) {
                var treePath = oContext.getPath();
                var bindTextName = '';
                if (treePath.indexOf("fields") !== -1) {
                    bindTextName = "fieldName";
                } else {
                    bindTextName = "segment";
                }
                alert("here = " + oContext + " ---- "
                        + bindTextName);
                return new sap.ui.commons.TreeNode()
                        .bindProperty("text", bindTextName);
            });
            var myButton = new sap.ui.commons.Button("btn");
            this.byId("addContentId").addContent(myButton);
            this.byId("addContentId").addContent(oTree);
            myButton.setText("Hello World!");
            myButton.placeAt("idViewRoot--idViewDetail--toolBar-content");
            oTree.placeAt("idViewRoot--idViewDetail--toolBar-content");
         /*   this.byId("addContentId").addContent(myButton);
            this.byId("addContentId").addContent(oTree);*/
	},
	
	onBack:function(){
		var router=sap.ui.core.UIComponent.getRouterFor(this);
	    router.navTo("main",{});
		},

		getRouter : function () 
		{
			return sap.ui.core.UIComponent.getRouterFor(this);
		},
});