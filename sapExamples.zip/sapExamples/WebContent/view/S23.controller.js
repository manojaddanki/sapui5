var oController;
sap.ui.controller("sapExamples.view.S23", {
	onInit: function() {
		oController=this;
		var aData = [
		            	{lastName: "Dente", name: "Al", gender: "male"},
		            	{lastName: "Friese", name: "Andy", gender: "male"},
		            	{lastName: "Mann", name: "Anita", gender: "female"}
		            ];
		   var oModel = new sap.ui.model.json.JSONModel(aData);
		   this.oTable = this.getView().byId("rowSelect");
		   var that=this;
		   that.oTable.bindItems("/",new sap.m.ColumnListItem({
				cells : [
							new sap.m.Button({
								icon: 'sap-icon://delete',
								press: that.handelDelete,
								}),
								new sap.m.Text({
							text : "{lastName}",
								}),
							new sap.m.Text({
								text : "{gender}"
								})
						]
			}));
		   that.oTable.setModel(oModel);
	},

	handelDelete:function(oEvent)
	{
		var index=oEvent.oSource.oParent;
		var table=oController.getView().byId("rowSelect");
		table.removeItem(index);
	},
	
	onBack:function()
	{
		this.getRouter().navTo("table",{});
	},

getRouter : function () 
	{
		return sap.ui.core.UIComponent.getRouterFor(this);
	},
});