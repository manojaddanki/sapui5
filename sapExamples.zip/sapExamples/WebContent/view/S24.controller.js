sap.ui.controller("sapExamples.view.S24", {
	
		onInit: function() {
	    
			var oModel = new sap.ui.model.json.JSONModel();
		    var users = [];
		    for (var i = 0; i < 100; i++) {
		      users.push({lastName: 'lastName' + i,  firstName: 'firstName' + i});
		    }
		    oModel.setData(users);
		    var oTable = this.getView().byId("rowSelect");
		    oTable.bindItems("/",new sap.m.ColumnListItem({
				cells : [
							new sap.m.Text({
							text : "{lastName}",
								}),
							new sap.m.Text({
								text : "{firstName}"
								})
						]
			}));
			 oTable.setModel(oModel);
		},
		
		DeleteRow:function(e)
		{
			
			var that=this;
			 var oTable=this.getView().byId("rowSelect");
			 var path = e.getParameter('listItem').getBindingContext().sPath;
	         var obj = oTable.getModel().getProperty(path);
	         console.log(obj); // here is the object ot be deleted
	         oTable.getModel().getData().splice(parseInt(path.substring(1)), 1);
	         oTable.removeItem(e.getParameter('listItem'));
	         // Simulate Adding New User after 1 second
	         setTimeout(function() {
	            that.addNewUser(oTable, obj); //adding the deleted user back.
	         }, 1000);
	      },
		addNewUser:function (tbl, obj)
		{
			
			var that=this;
			tbl.getModel().getData().push(obj);
		      that.bindModel(tbl);
		      setTimeout(function() {
		         that.scrollToItem(tbl);
		      }, 500);
		},
		bindModel:function(tbl)
		{
			
			tbl.bindItems("/", new sap.m.ColumnListItem({
		        cells : [ new sap.m.Text({
		          text : "{lastName}"
		        }), new sap.m.Text({
		          text : "{firstName}"
		        })]
		      }));
		},
		scrollToItem:function(tbl)
		{
			
			   var idx = tbl.getModel().getData().length -1;
			      var domTr = tbl.$().find(( "table tr:nth-child(" + idx + ")"));
			      domTr.focus();
		},
		
		onBack:function()
		{
			this.getRouter().navTo("table",{});
		},

	getRouter : function () 
		{
			return sap.ui.core.UIComponent.getRouterFor(this);
		},

		
	

});