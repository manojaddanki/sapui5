sap.ui.controller("sapExamples.view.S2B", {
	onInit: function() {
	},
	
	handleQuantity:function()
	{
		var sbTtl=this.getView().byId("total");
		var shpTtl=this.getView().byId("shtotal");
		var cmpTtl=this.getView().byId("Cmpltotal");
		var qnty=parseInt(this.getView().byId("qntyId").getValue());
	    
		if(qnty==0)
	    {
	    	sbTtl.setText("Rs."+0);
	    	shpTtl.setText("Shipping:Rs."+0);
	    	cmpTtl.setText("Total:Rs."+0);
	    }	
	    else
	    {
	    	var tv=qnty*1500;
	    	sbTtl.setText("Rs."+tv);
	        var tw=qnty*50
	        shpTtl.setText("Shipping:Rs."+tw);
	        var totalAmout=tv+tw;
	        cmpTtl.setText("Total:Rs."+totalAmout);
	    }	
	},

	onBack:function()
	{
		this.getRouter().navTo("table",{});
	},

getRouter : function () 
	{
		return sap.ui.core.UIComponent.getRouterFor(this);
	},


});