/*!
 * UI development toolkit for HTML5 (OpenUI5)
 * (c) Copyright 2009-2016 SAP SE or an SAP affiliate company.
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */
sap.ui.define([], function() {
    'use strict';
    var G = {};
    G.render = function(r, c) {
        var t = c._getTooltipText();
        var a = c._getAriaText();
        var h = c.getHeaderImage();
        var H = c.hasListeners('press');
        r.write('<div');
        r.writeControlData(c);
        if (t) {
            r.writeAttributeEscaped('title', t);
        }
        r.addClass('sapMGT');
        r.addClass(c.getFrameType());
        if (H) {
            r.writeAttribute('role', 'button');
        } else {
            r.writeAttribute('role', 'presentation');
        }
        r.writeAttributeEscaped('aria-label', a);
        if (c.getState() !== sapExamples.util.LoadState.Disabled) {
            r.addClass('sapMPointer');
            r.writeAttribute('tabindex', '0');
        }
        if (c.getBackgroundImage()) {
            r.write(" style='background-image:url(");
            r.writeEscaped(c.getBackgroundImage());
            r.write(");'");
            r.addClass('sapMGTBackgroundImage');
        }
        if (c.getMode() === sapExamples.util.GenericTileMode.HeaderMode) {
            r.addClass('sapMGTHeaderMode');
        }
        r.writeClasses();
        r.write('>');
        if (c.getState() !== sapExamples.util.LoadState.Loaded) {
            this._renderStateOverlay(r, c, t);
        } else {
            this._renderHoverOverlay(r, c);
        }
        this._renderFocusDiv(r, c);
        r.write('<div');
        r.addClass('sapMGTHdrContent');
        r.addClass(c.getFrameType());
        if (t) {
            r.writeAttributeEscaped('title', t);
        }
        r.writeClasses();
        r.write('>');
        if (h) {
            r.renderControl(c._oImage);
        }
        this._renderHeader(r, c);
        if (c.getSubheader()) {
            this._renderSubheader(r, c);
        }
        r.write('</div>');
        r.write('<div');
        r.addClass('sapMGTContent');
        r.writeClasses();
        r.writeAttribute('id', c.getId() + '-content');
        r.write('>');
        var T = c.getTileContent();
        var l = T.length;
        for (var i = 0; i < l; i++) {
            if (c.getMode() === sapExamples.util.GenericTileMode.HeaderMode) {
                T[i].removeAllAggregation('content', true);
            }
            c._checkFooter(T[i], c);
            r.renderControl(T[i]);
        }
        r.write('</div>');
        r.write('</div>');
    }
    ;
    G._renderFocusDiv = function(r, c) {
        r.write('<div');
        r.addClass('sapMGTFocusDiv');
        r.writeClasses();
        r.writeAttribute('id', c.getId() + '-focus');
        r.write('>');
        r.write('</div>');
    }
    ;
    G._renderStateOverlay = function(r, c, t) {
        var s = c.getState();
        r.write('<div');
        r.addClass('sapMGTOverlay');
        r.writeClasses();
        r.writeAttribute('id', c.getId() + '-overlay');
        if (t) {
            r.writeAttributeEscaped('title', t);
        }
        r.write('>');
        switch (s) {
        case sapExamples.util.LoadState.Loading:
            c._oBusy.setBusy(s == sapExamples.util.LoadState.Loading);
            r.renderControl(c._oBusy);
            break;
        case sapExamples.util.LoadState.Failed:
            r.write('<div');
            r.writeAttribute('id', c.getId() + '-failed-ftr');
            r.addClass('sapMGenericTileFtrFld');
            r.writeClasses();
            r.write('>');
            r.write('<div');
            r.writeAttribute('id', c.getId() + '-failed-icon');
            r.addClass('sapMGenericTileFtrFldIcn');
            r.writeClasses();
            r.write('>');
            r.renderControl(c._oWarningIcon);
            r.write('</div>');
            r.write('<div');
            r.writeAttribute('id', c.getId() + '-failed-text');
            r.addClass('sapMGenericTileFtrFldTxt');
            r.writeClasses();
            r.write('>');
            r.renderControl(c.getAggregation('_failedMessageText'));
            r.write('</div>');
            r.write('</div>');
            break;
        default:
        }
        r.write('</div>');
    }
    ;
    G._renderHoverOverlay = function(r, c) {
        r.write('<div');
        if (c.getBackgroundImage()) {
            r.addClass('sapMGTWithImageHoverOverlay');
        } else {
            r.addClass('sapMGTWithoutImageHoverOverlay');
        }
        r.writeClasses();
        r.writeAttribute('id', c.getId() + '-hover-overlay');
        r.write('>');
        r.write('</div>');
    }
    ;
    G._renderHeader = function(r, c) {
        r.write('<div');
        r.addClass('sapMGTHdrTxt');
        r.writeClasses();
        r.writeAttribute('id', c.getId() + '-hdr-text');
        r.write('>');
        r.renderControl(c._oTitle);
        r.write('</div>');
    }
    ;
    G._renderSubheader = function(r, c) {
        r.write('<div');
        r.addClass('sapMGTSubHdrTxt');
        r.writeClasses();
        r.writeAttribute('id', c.getId() + '-subHdr-text');
        r.write('>');
        r.writeEscaped(c.getSubheader());
        r.write('</div>');
    }
    ;
    return G;
}, true);
