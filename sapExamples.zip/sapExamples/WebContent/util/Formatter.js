jQuery.sap.declare("sapExamples.util.Formatter");
jQuery.sap.require("sap.m.MessageBox");

sapExamples.util.Formatter = 
{
	orderService : "Z_FIORI_ES_SO_CREATE_SRV",
	serviceUrl : "/sap/opu/odata/sap/@Service/?saml2=disabled",
	proxy : "../../../../../../sapExamples/proxy",
	codeOnServer : function(){
		var regExp = /^(localhost|[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3})$/;//Regular Expression to check host name
		var hostname = window.location.hostname;
		return (!regExp.test(hostname));
	},
	getServiceUrl : function(service){
		return ((this.codeOnServer()) ? (this.serviceUrl) : (this.proxy + this.serviceUrl)).replace("@Service", service);
	},
	successIcon : sap.m.MessageBox.Icon.SUCCESS,
	errorIcon : sap.m.MessageBox.Icon.ERROR,
	showMessageToast : function(message)
	{
		sap.m.MessageToast.show(message);
	},
	showMessageBox : function(message, title, icon, closeFunt)
	{
		sap.m.MessageBox.show(message,{
			title: title,
			icon: icon,
			onClose: closeFunt
		});  
	},	
	Date : function(dtvalue) {
		var oDateFormat = sap.ui.core.format.DateFormat.getInstance({
			pattern : "dd MMM yyyy"
		});
		return oDateFormat.format(new Date(dtvalue));
	}
};