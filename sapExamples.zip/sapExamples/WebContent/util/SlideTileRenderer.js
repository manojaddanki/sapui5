/*!
 * UI development toolkit for HTML5 (OpenUI5)
 * (c) Copyright 2009-2016 SAP SE or an SAP affiliate company.
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */
sap.ui.define([], function() {
    'use strict';
    var S = {};
    S.render = function(r, c) {
        var t = c.getTooltip_AsString(), l;
        r.write('<div');
        r.writeControlData(c);
        r.addClass('sapMST');
        if (!this._bAnimationPause) {
            r.addClass('sapMSTPauseIcon');
        }
        r.writeClasses();
        if (t) {
            r.writeAttributeEscaped('title', t);
        }
        r.writeAttribute('tabindex', '0');
        r.writeAttribute('role', 'presentation');
        r.write('>');
        this._renderPausePlayIcon(r, c);
        l = c.getTiles().length;
        if (l > 1) {
            this._renderTilesIndicator(r, c);
        }
        for (var i = 0; i < l; i++) {
            r.write('<div');
            r.writeAttribute('id', c.getId() + '-wrapper-' + i);
            r.addClass('sapMSTWrapper');
            r.writeClasses();
            r.write('>');
            r.renderControl(c.getTiles()[i]);
            r.write('</div>');
        }
        r.write('<div');
        r.addClass('sapMSTFocusDiv');
        r.writeClasses();
        r.writeAttribute('id', c.getId() + '-focus');
        r.write('>');
        r.write('</div>');
        r.write('</div>');
    }
    ;
    S._renderTilesIndicator = function(r, c) {
        var p = c.getTiles().length;
        r.write('<div');
        r.writeAttribute('id', c.getId() + '-tilesIndicator');
        r.addClass('sapMSTBulleted');
        r.writeClasses();
        r.write('>');
        for (var i = 0; i < p; i++) {
            r.write('<span');
            r.writeAttribute('id', c.getId() + '-tileIndicator-' + i);
            r.write('>');
            r.write('</span>');
        }
        r.write('</div>');
    }
    ;
    S._renderPausePlayIcon = function(r, c) {
        if (c.getTiles().length > 1) {
            r.write('<div');
            r.addClass('sapMSTIconClickTapArea');
            r.writeClasses();
            r.write('>');
            r.write('</div>');
            r.write('<div');
            r.addClass('sapMSTIconDisplayArea');
            r.writeClasses();
            r.write('>');
            r.write('</div>');
            r.write('<div');
            r.addClass('sapMSTIconNestedArea');
            r.writeClasses();
            r.write('>');
            r.renderControl(c.getAggregation('_pausePlayIcon'));
            r.write('</div>');
        }
    }
    ;
    return S;
}, true);
