/*!
 * UI development toolkit for HTML5 (OpenUI5)
 * (c) Copyright 2009-2016 SAP SE or an SAP affiliate company.
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */
sap.ui.define(['jquery.sap.global', 'sap/m/library', 'sap/ui/core/Control', 'sap/m/Text'], function(q, l, C, T) {
    'use strict';
    var N = C.extend('sapExamples.util.NewsContent', {
        metadata: {
            library: 'sap.m',
            properties: {
                'size': {
                    type: 'sapExamples.util.Size',
                    group: 'Misc',
                    defaultValue: sapExamples.util.Size.Auto
                },
                'contentText': {
                    type: 'string',
                    group: 'Misc',
                    defaultValue: null
                },
                'subheader': {
                    type: 'string',
                    group: 'Misc',
                    defaultValue: null
                }
            },
            aggregations: {
                'contentTextAgr': {
                    type: 'sap.m.Text',
                    multiple: false,
                    visibility: 'hidden'
                }
            },
            events: {
                'press': {}
            }
        }
    });
    N.prototype.init = function() {
        this._oContentText = new sap.m.Text(this.getId() + '-content-text',{
            maxLines: 2
        });
        this._oContentText.cacheLineHeight = false;
        this.setAggregation('contentTextAgr', this._oContentText, true);
        this.setTooltip('{AltText}');
    }
    ;
    N.prototype.getAltText = function() {
        var a = '';
        var i = true;
        if (this.getAggregation('contentTextAgr').getText()) {
            a += this.getAggregation('contentTextAgr').getText();
            i = false;
        }
        if (this.getSubheader()) {
            if (i) {
                a += '' + this.getSubheader();
            } else {
                a += '\n' + this.getSubheader();
            }
        }
        return a;
    }
    ;
    N.prototype.getTooltip_AsString = function() {
        var t = this.getTooltip();
        var s = this.getAltText();
        if (typeof t === 'string' || t instanceof String) {
            s = t.split('{AltText}').join(s).split('((AltText))').join(s);
            return s;
        }
        if (t) {
            return t;
        } else {
            return '';
        }
    }
    ;
    N.prototype.setContentText = function(t) {
        this._oContentText.setText(t);
        return this;
    }
    ;
    N.prototype.ontap = function(e) {
        if (sap.ui.Device.browser.internet_explorer) {
            this.$().focus();
        }
        this.firePress();
    }
    ;
    N.prototype.onkeydown = function(e) {
        if (e.which === q.sap.KeyCodes.ENTER || e.which === q.sap.KeyCodes.SPACE) {
            this.firePress();
            e.preventDefault();
        }
    }
    ;
    N.prototype.attachEvent = function(e, d, f, a) {
        sap.ui.core.Control.prototype.attachEvent.call(this, e, d, f, a);
        if (this.hasListeners('press')) {
            this.$().attr('tabindex', 0).addClass('sapMPointer');
        }
        return this;
    }
    ;
    N.prototype.detachEvent = function(e, f, a) {
        sap.ui.core.Control.prototype.detachEvent.call(this, e, f, a);
        if (!this.hasListeners('press')) {
            this.$().removeAttr('tabindex').removeClass('sapMPointer');
        }
        return this;
    }
    ;
    return N;
}, true);
