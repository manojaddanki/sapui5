jQuery.sap.declare("Transportation.util.Formatter");
Transportation.util.Formatter = {
		proxy : ".." + window.location.pathname + "proxy",
		serviceUrl : "/sap/opu/odata/sap/@ServiceUrl/",
		ExeService : "Z_FIORI_TRANSPORT_SHIPMENT_SRV",
		codeOnServer : function(){
			var regExp = /^localhost$/;//Regular Expression to check host name
			var hostname = window.location.hostname;
			return (!regExp.test(hostname));
		},
		getProxy : function(){
			return (this.codeOnServer() ? "" : (".." + window.location.pathname + "proxy"));
		},
		getServiceUrl : function(service){
			return ((this.codeOnServer()) ? (this.serviceUrl) : (this.getProxy() + this.serviceUrl + "?saml2=disabled")).replace("@ServiceUrl", service);
		},
		getStatusIcon : function(status){
			switch(status){
			case '1': return 'sap-icon://message-error';
			case '2': return 'sap-icon://message-warning';
			case '3': return 'sap-icon://accept';
			}
		},
		getStatusTooltip : function(status){
			switch(status){
			case '1': return 'Error';
			case '2': return 'Warning';
			case '3': return 'Success';
			}
		},		
		getStatusColor : function(status){
			switch(status){
			case '1': return '#bb0000';
			case '2': return '#e78c07';
			case '3': return '#2b7d2b';			
			}
		},
		getObjectStatus : function(status){
			switch(status){
			case '1': return 'Error';
			case '2': return 'None';
			case '3': return 'Success';
			}
		},
		getShipTypeIcon : function(shipType){
			switch(shipType){			
			case 'RD': return 'sap-icon://shipping-status';
			case 'CA': return 'sap-icon://flight';
			case 'CR': return 'sap-icon://taxi';
			case 'HD': return 'sap-icon://physical-activity';
			case 'RB': return 'sap-icon://supplier';
			}
		},
		getShipTypeIconColor : function(shipType){
			switch(shipType){
			case 'RD': return '#0925ff';
			case 'CA': return '#b909ff';
			case 'CR': return '#f30606';
			case 'HD': return '#f36a06';
			case 'RB': return '#f1aa05';
			default : return '#007833';
			}
		},		
		showLoader : function() { // for opening dialog
			if (!this.loader) {
				var xml = "<BusyDialog xmlns='sap.m' />";
				this.loader = new sap.ui.xmlfragment({
					fragmentContent : xml
				}, this);
			}
			this.loader.open();
		},
		hideLoader : function() { // for closing dialog
			this.loader.close();
		},
		getDate : function(oDate){
			var date = ((oDate.getDate() < 10) ? "0" + oDate.getDate() : oDate.getDate()).toString();
			var month = (((oDate.getMonth() + 1) < 10) ? "0" + (oDate.getMonth() + 1) : (oDate.getMonth() + 1)).toString();
			return oDate.getFullYear() + month + date;
		},
		getDate1 : function(oDate){
			if(oDate !== null && oDate !== undefined){
				var date = ((oDate.getDate() < 10) ? "0" + oDate.getDate() : oDate.getDate()).toString();
				var month = (((oDate.getMonth() + 1) < 10) ? "0" + (oDate.getMonth() + 1) : (oDate.getMonth() + 1)).toString();
				return oDate.getFullYear() + "-" + month + "-" + date + "T00:00:00";
			}
			else{
				return null;
			}
		},
		getDateFormatted : function(value){
			if (!value)
				return null;
			var oDateFormat = sap.ui.core.format.DateFormat.getInstance({
				pattern : "dd MMM yyyy"
			});
			return oDateFormat.format(value);
		},
		getShipTypeVisibility : function(groupHeader){
			return (groupHeader === "///") ? false : true;
		},
		getColumnVisible : function(groupHeader){			
			return (groupHeader !== "///") ? false : true;
		},
		getTripAssigned : function(tripNum){
			return (tripNum === "") ? false : true;
		},
		getGrouped : function(groupId){
			return (groupId === "") ? true : false;
		},
		getCreateTripVisibility : function(ShipmntNum,ShpmntStart){
			return (ShipmntNum !== "" && ShpmntStart !== "");
		},
		getInfo : function(status){
			switch(status){
			case "1": return "Error";
			case "2": return "Warning";
			case "3": return "Success";
			}
		},
		getInfoState : function(status){
			switch(status){
			case "1": return "Error";
			case "2": return "Warning";
			case "3": return "Success";
			}
		},
		getVehicleNum : function(vehNo){
			return (vehNo === "") ? " " : vehNo;
		},
		getVendorName : function(vendorName, vendorNo){
			if(vendorName === "" && vendorNo === ""){
				return "";
			}
			else if(vendorNo === ""){
				return vendorName;
			}
			else if(vendorName == ""){
				return vendorNo;
			}
			else{
				return vendorName + " (" + vendorNo + ")";
			}
		},
		validateDateRange : function(fromDate, toDate){
			var fDate = fromDate.getDate();
			var fMonth = fromDate.getMonth();
			var fYear = fromDate.getYear();

			var tDate = toDate.getDate();
			var tMonth = toDate.getMonth();
			var tYear = toDate.getYear();

			var diffDate = tDate - fDate;
			var diffMonth = tMonth - fMonth;
			var diffYear = tYear - fYear;

			var totalDays = diffDate + diffMonth * 30 + diffYear * 365;

			if(totalDays > 14){
				return false; 
			}
			return true;
		},
		getDateDisplayFormat : function(){
			return "dd MMM yyyy";
		},
		
		  DateFormat : function(dtvalue) {
		        var oDateFormat = sap.ui.core.format.DateFormat.getInstance({
		          pattern : "dd MMM yyyy"
		        });
		        return oDateFormat.format(new Date(dtvalue));
		      },
		      
		getPackageUnit : function(pkgUnit){
			return (pkgUnit === "" || pkgUnit === undefined) ? "PAC" : pkgUnit;
		},
		getWeightUnit : function(weightUnit){
			return (weightUnit === "" || weightUnit === undefined) ? "KG" : weightUnit;
		},
		getVolumeUnit : function(volumeUnit){
			return (volumeUnit === "" || volumeUnit === undefined) ? "FT3" : volumeUnit;
		},
		getStageSeq : function(stageSeq){
			if(stageSeq !== ""){
				return parseInt(stageSeq).toString();
			}
		},
		getListType : function(status){
			return "Active";
			//return (status === "2" || status === "3") ? "Active" : "Inactive";
		},
		getMode : function(){
			return "OBD";
		},
		getValidCNShipTypes : function(){
			return [ "RD"];
		},
		getValidCNShipTypes2 : function(){
			return [ "F" ];
		},
		getValidSameSTPShipTypes : function(){
			return [ "CA", "CR", "HD" ];
		},
		getValidCreateTripShipTypes : function(){
			return [ "CA", "CR" ];
		},
		getValidStartKMShipTypes : function(){
			return [ "RD", "RB" ];
		},
		LRNOvisible:function(value){
			if(value!==""){
				return true;
			}
			else{return false;}
		},
		RouteEditable:function(val,val2){
			if(val!==""||val2!==""){
				return false;
			}else{
				return true;
			}
		}
};