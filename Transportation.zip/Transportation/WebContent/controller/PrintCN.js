sap.ui.define([ 'sap/ui/core/mvc/Controller', 'Transportation/util/Formatter','sap/m/MessageToast',
                'sap/m/ColumnListItem', 'sap/m/Label', 'sap/m/Text', 'sap/m/ScreenSize', 'sap/ui/core/Icon', 'sap/m/Input', 'sap/custom/Utilities'],
                function(Controller, Formatter, MessageToast,
                	ColumnListItem, Label, Text, ScreenSize, Icon, Input, Utilities) {
		
	"use strict";
		
	return Controller.extend("Transportation.controller.PrintCN",{
		lCNo : function(oEvent){
			this.transMode = undefined;
			this.tripNo = undefined;
			var inpNo = oEvent.getSource();
			var regex = /^[0-9]+$/;
			this.fnValidate(inpNo, regex, "", Transportation.that.oi18nModel.getProperty("valNums"));
		},
		lCDepSeal1 : function(oEvent){
			var inpNo = oEvent.getSource();			
			var regex = /^[A-Za-z0-9]+$/;
			this.fnValidate(inpNo, regex, "DepSeal1", Transportation.that.oi18nModel.getProperty("msgDepSeal"));
		},
		lCDepSeal2 : function(oEvent){
			var inpNo = oEvent.getSource();			
			var regex = /^[A-Za-z0-9]+$/;
			this.fnValidate(inpNo, regex, "DepSeal2", Transportation.that.oi18nModel.getProperty("msgDepSeal"));
		},
		fnValidate : function(inpNo, regex, property, msg){
			var inpNoVal = inpNo.getValue();
			if(regex.test(inpNoVal)){
				if(inpNo.getParent() instanceof ColumnListItem){
					var oContext = inpNo.getParent().getBindingContext().getObject();
					for(var prop in oContext){
						if(prop === property){							
							oContext[prop] = inpNoVal;
							break;
						}
					}
				}
				inpNo.setValueState("None");
				inpNo.setValueStateText();
			}
			else{
				inpNo.setValue();
				inpNo.setValueState("Error");
				inpNo.setValueStateText(msg);
				MessageToast.show(msg);
			}
		},
		bindCNList : function(){
			var selItem = Transportation.that.lstPrint.getSelectedItem();
			var selItemIndex = Transportation.that.lstPrint.indexOfItem(selItem);
			var sPath = "";
			if(selItemIndex === 0){
				sPath = "/CNListSet@DateFilter";
				Transportation.that.lstCNTrip.getColumns()[0].getHeader().setVisible(true);
				Transportation.that.lstCNTrip.getColumns()[2].setDemandPopin(true);
				Transportation.that.lstCNTrip.getColumns()[2].setMinScreenWidth(ScreenSize.Tablet);
			}
			else{
				sPath = "/TripListSet@DateFilter and TripNum eq ''";
				Transportation.that.lstCNTrip.getColumns()[0].getHeader().setVisible(false);
				Transportation.that.lstCNTrip.getColumns()[2].setDemandPopin(false);
				Transportation.that.lstCNTrip.getColumns()[2].setMinScreenWidth(ScreenSize.Phone);
			}
			var fromDate, toDate;
			if(Transportation.that.dRSCNDate !== undefined && Transportation.that.dRSCNDate.getDateValue() !== null && Transportation.that.dRSCNDate.getSecondDateValue() !== null){
				fromDate = Formatter.getDate1(Transportation.that.dRSCNDate.getDateValue());
				toDate = Formatter.getDate1(Transportation.that.dRSCNDate.getSecondDateValue());				
			}
			else{
				var currDate = new Date();
				fromDate = Formatter.getDate1(currDate);
				toDate = Formatter.getDate1(currDate);
			}
			sPath = sPath.replace("@DateFilter", "?$filter=FromDate eq datetime'" + fromDate + "' and ToDate eq datetime'" + toDate + "'");
			
			var fnFactory = function(sId, oContext){
				if(oContext.getProperty("TransportMode")){
					return new Icon({
						src : Formatter.getShipTypeIcon(oContext.getProperty("TransportMode")),
						color : Formatter.getShipTypeIconColor(oContext.getProperty("TransportMode")),
						tooltip : oContext.TransportMode
					});
				}
				else{
					return new Label({
		         		text : "{CNNum}",
		         		design : "Bold"
		         	});
				}
			};		
			
			Transportation.that.lstCNTrip.bindAggregation("items", {
				path : sPath,
				factory : function(sId, oContext){
					return new ColumnListItem({
						tooltip : "{path: 'CreationDate', formatter: 'Transportation.util.Formatter.getDateFormatted'}",
						cells : [
						         	fnFactory(sId, oContext),
						         	new Text({
						         		text : "{TripNum}"
						         	}),
						         	new Text({
						         		text : "{VehicleNum}"
						         	})				         	
						        ]
					}); 
				}
			});
		},
		cCNDateRange : function(oEvent){
			var fromDate = Transportation.that.dRSCNDate.getDateValue();
			var toDate = Transportation.that.dRSCNDate.getSecondDateValue();
			var currDate = new Date();
			this.isDateValid = true;
			var errorMsg = "";
			if(fromDate === null && toDate === null){
				Transportation.that.dRSCNDate.setValueState("None");
			}
			else if(fromDate > currDate || toDate > currDate){
				this.isDateValid = false;
				errorMsg = Transportation.that.oi18nModel.getProperty("msgDateSelection");
			}
			else{
				var isValid = Formatter.validateDateRange(fromDate, toDate);
				if(!isValid){
					this.isDateValid = false;
					errorMsg = Transportation.that.oi18nModel.getProperty("msgDateRange");					
				}
			}
			if(this.isDateValid){
				Transportation.that.dRSCNDate.setValueState("None");
				Transportation.that.dRSCNDate.setValueStateText();
				Transportation.that.btnCNSearch.setEnabled(true);
			}
			else{
				MessageToast.show(errorMsg);
				Transportation.that.dRSCNDate.setValueState("Error");
				Transportation.that.dRSCNDate.setValueStateText(errorMsg);
				Transportation.that.btnCNSearch.setEnabled(false);
			}
		},		
		sCPrinting : function(oEvent){
			Transportation.that.nCPrintCN.to(Transportation.that.pgCNTrip);
			var list = oEvent.getSource();
			var selItem = oEvent.getParameter("listItem");
			var selItemIndex = list.indexOfItem(selItem);
			if(selItemIndex === 0){
				Transportation.that.inpCNNo.setVisible(true);
			}
			else{
				Transportation.that.inpCNNo.setVisible(false);
			}
			Transportation.that.inpTripNo.setValue();
			Transportation.that.inpTripNo.setValueState("None");
			Transportation.that.inpTripNo.setValueStateText();
			Transportation.that.inpCNNo.setValue();
			Transportation.that.inpCNNo.setValueState("None");
			Transportation.that.inpCNNo.setValueStateText();
			Transportation.that.btnCNPrint.setVisible(true);
		},
		lcCNTripNo : function(oEvent){
			var searchVal = oEvent.getSource().getValue().toLowerCase();
			var items = Transportation.that.lstCNTrip.getItems();
			var itemsLen = items.length;
			for(var i = 0; i < itemsLen; i++){
				var context = items[i].getBindingContext();
				var cNNo = context.getProperty("CNNum");
				var tripNo = context.getProperty("TripNum");
				var vehNo = context.getProperty("VehicleNum");
				if((cNNo !== undefined && cNNo.indexOf(searchVal) > -1) || tripNo.indexOf(searchVal) > -1 || vehNo.indexOf(searchVal) > -1){
					items[i].setVisible(true);
				}
				else{
					items[i].setVisible(false);
				}
			}
		},
		sCCNTrip : function(oEvent){
			var selItem = oEvent.getParameter("listItem");
			var cNNo = selItem.getBindingContext().getProperty("CNNum");
			this.tripNo = selItem.getBindingContext().getProperty("TripNum");
			this.transMode = selItem.getBindingContext().getProperty("TransportMode");
			if(this.inpCNTrip !== undefined){
				this.inpCNTrip.setValueState("None");
				if(this.inpCNTrip.getId() === "inpTripNo"){					
					this.inpCNTrip.setValue(this.tripNo);
				}
				else{
					this.inpCNTrip.setValue(cNNo);
				}
			}
			Transportation.that.nCPrintCN.back();
			Transportation.that.btnCNPrint.setVisible(true);
		},		
		vHRCNTrip : function(oEvent){
			this.inpCNTrip = oEvent.getSource();
			Transportation.that.nCPrintCN.to(Transportation.that.pgList);
			Transportation.that.btnCNCancel.setVisible(true);
			Transportation.that.btnCNPrint.setVisible(false);
			Transportation.that.btnCNClear.setVisible(false);
			Transportation.that.btnCNSearch.setVisible(false);
			this.bindCNList();
		},
		nBPPGPrinting : function(){
			Transportation.that.lstPrint.removeSelections();
			Transportation.that.nCPrintCN.back();
			Transportation.that.btnCNCancel.setVisible(true);
			Transportation.that.btnCNPrint.setVisible(false);
			Transportation.that.btnCNClear.setVisible(false);
			Transportation.that.btnCNSearch.setVisible(false);
		},
		nBPPGCNTrip : function(){			
			Transportation.that.btnCNCancel.setVisible(true);
			Transportation.that.btnCNPrint.setVisible(true);
			Transportation.that.btnCNClear.setVisible(false);
			Transportation.that.btnCNSearch.setVisible(false);
			Transportation.that.nCPrintCN.back();
		},
		nBPPGList : function(){
			Transportation.that.nCPrintCN.back();
			Transportation.that.btnCNCancel.setVisible(true);
			Transportation.that.btnCNPrint.setVisible(false);
			Transportation.that.btnCNClear.setVisible(false);
			Transportation.that.btnCNSearch.setVisible(false);
		},
		pRefCNList : function(){
			this.bindCNList();
		},
		pFltrCNList : function(){
			Transportation.that.nCPrintCN.to(Transportation.that.pgListFilter);
			Transportation.that.btnCNCancel.setVisible(false);
			Transportation.that.btnCNPrint.setVisible(false);
			Transportation.that.btnCNClear.setVisible(true);
			Transportation.that.btnCNSearch.setVisible(true);
			var fromDate = Transportation.that.dRSCNDate.getDateValue();
			var toDate = Transportation.that.dRSCNDate.getSecondDateValue();
			if(fromDate !== null && toDate !== null){
				Transportation.that.btnCNClear.setEnabled(true);//Only enable when already some dates are selected
			}
			else{
				Transportation.that.btnCNClear.setEnabled(false);//Disable when dates are cleared
				Transportation.that.btnCNSearch.setEnabled(false);
			}
		},
		pCNClear : function(){
			Transportation.that.dRSCNDate.setDateValue();
			Transportation.that.dRSCNDate.setSecondDateValue();
			Transportation.that.dRSCNDate.setValueState("None");
			Transportation.that.btnCNCancel.setVisible(true);
			Transportation.that.btnCNPrint.setVisible(false);
			Transportation.that.btnCNClear.setVisible(false);			
			this.bindCNList();
			Transportation.that.nCPrintCN.back();
			Transportation.that.btnCNSearch.setVisible(false);
		},
		pCNSearch : function(){
			if(this.isDateValid !== undefined && this.isDateValid === true) {
				this.isDateValid = undefined;
				this.bindCNList();
			}		
			Transportation.that.btnCNCancel.setVisible(true);
			Transportation.that.btnCNPrint.setVisible(false);
			Transportation.that.btnCNClear.setVisible(false);
			Transportation.that.btnCNSearch.setVisible(false);
			Transportation.that.nCPrintCN.back();
		},
		pCNCancel : function(){
			Transportation.that.dlgCNPrint.close();
		},
		fnGetTransMode : function(tripNo){
			var that = this;
			var sPath = "/TripListSet?$@DateFilter TripNum eq '" + tripNo + "'";
			var fromDate, toDate;
			if(Transportation.that.dRSCNDate !== undefined && Transportation.that.dRSCNDate.getDateValue() !== null && Transportation.that.dRSCNDate.getSecondDateValue() !== null){
				fromDate = Formatter.getDate1(Transportation.that.dRSCNDate.getDateValue());
				toDate = Formatter.getDate1(Transportation.that.dRSCNDate.getSecondDateValue());				
			}
			else{
				var currDate = new Date();
				fromDate = Formatter.getDate1(currDate);
				toDate = Formatter.getDate1(currDate);
			}
			sPath = sPath.replace("@DateFilter", "filter=FromDate eq datetime'" + fromDate + "' and ToDate eq datetime'" + toDate + "' and ");
			Formatter.showLoader();
			Transportation.that.oModel.read(sPath, {
				async : true,
				success : function(oData, oResponse){
					Formatter.hideLoader();
					if(oData.results[0].TransportMode === "RD"){
						that.fnSealInfo(tripNo);
					}
					else{
						that.downloadPDF(tripNo);
					}
				},
				error : function(oError){
					Formatter.hideLoader();
					var msg = "";
					try{
						msg = JSON.parse(oError.response.body).error.message.value;
					}
					catch(err){
						msg = oError.response.body;
					}
					MessageToast.show(msg);
				}
			});
		},
		fnSealInfo : function(tripNo){
			if(!Transportation.that.dlgSealInf){
				Transportation.that.dlgSealInf = sap.ui.xmlfragment("Transportation.fragment.SealInfo", this);
			}
			var path = "/SealInfoSet?$filter=TripNum eq '" + tripNo + "'";
			sap.ui.getCore().byId("tblSealInfo1").bindItems(path, new ColumnListItem({
				cells : [
				         	new Text({
				         		text : "{LocationCode}"
				         	}),
				         	new Text({
				         		text : "{path:'StageSeq', formatter:'Transportation.util.Formatter.getStageSeq'}"
				         	}),
				         	new Input({
				         		value : "{DepSeal1}",
				         		maxLength : 15,
				         		placeholder : Transportation.that.oi18nModel.getProperty("phDepSeal1"),
				         		liveChange : [ this.lCDepSeal1, this ]
				         	}),
				         	new Input({
				         		value : "{DepSeal2}",
				         		maxLength : 15,
				         		placeholder : Transportation.that.oi18nModel.getProperty("phDepSeal2"),
				         		liveChange : [ this.lCDepSeal2, this ]
				         	})
				        ]
			}));
			Transportation.that.dlgSealInf.open();
		},
		pCNPrint : function(){
			var selItem = Transportation.that.lstPrint.getSelectedItem();
			var selItemIndex = Transportation.that.lstPrint.indexOfItem(selItem);
			var tripNo = Transportation.that.inpTripNo.getValue();
			var cNNo = Transportation.that.inpCNNo.getValue();
			if(tripNo === ""){
				Transportation.that.inpTripNo.setValueState("Error");
				Transportation.that.inpTripNo.setValueStateText("Enter Trip Number");
				MessageToast.show("Enter Trip Number");
			}
			else if(selItemIndex === 0){				
				this.downloadPDF(tripNo, cNNo);
			}
			else if(this.transMode !== undefined){
				if(this.transMode === "RD"){
					this.fnSealInfo(tripNo);
				}
				else{
					this.downloadPDF(tripNo);
				}
			}
			else{
				this.fnGetTransMode(tripNo);
			}
		},
		pSealSubmit : function(){
			var tripNo = Transportation.that.inpTripNo.getValue();
			var sealItems = sap.ui.getCore().byId("tblSealInfo1").getItems();
			var sealItemsLen = sealItems.length;			
			var aSealInfNav;
			aSealInfNav = [];
			for(var i = 0; i < sealItemsLen; i++){
				var oContext = sealItems[i].getBindingContext().getObject();
				var oSealInf = {
					LocationCode : oContext.LocationCode,
					StageSeq : oContext.StageSeq,
					DepSeal1 : oContext.DepSeal1,
					DepSeal2 : oContext.DepSeal2
				};
				aSealInfNav.push(oSealInf);
			}
			var path = "TripPrintSet";
			var data = {
				TripNum : tripNo,
				TRPRSELINFNAV : aSealInfNav
			};
			var fnCallBack = function(oData, oResponse){
				var res = JSON.parse(oResponse.body);
				if(typeof(res.d) === "undefined" || typeof(res.d.Content) === "undefined" || typeof(res.d.MimeType) === "undefined" || 
						res.d.Content === "" || res.d.MimeType === ""){
					MessageToast.show("PDF can't be generated");
				}
				else{
					Transportation.that.pdfFile = JSON.parse(oResponse.body).d.Content;
					Transportation.that.getRouter().navTo("S3");
				}
				/*var  ctnt=oResponse.data.Content;
				if (!window.btoa) {
					var tableStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
					var table = tableStr.split("");
					window.btoa = function (bin) {
						for (var i = 0, j = 0, len = bin.length / 3, base64 = []; i < len; ++i) {
							var a = bin.charCodeAt(j++), b = bin.charCodeAt(j++), c = bin.charCodeAt(j++);
							if ((a | b | c) > 255) throw new Error("String contains an invalid character");
							base64[base64.length] = table[a >> 2] + table[((a << 4) & 63) | (b >> 4)] +
							(isNaN(b) ? "=" : table[((b << 2) & 63) | (c >> 6)]) +
							(isNaN(b + c) ? "=" : table[c & 63]);
						}
						return base64.join("");
					};
				}*/ 
				//script block
				// try this way  to open you pdf file like this in javascript hope it will help you.
				/*function hexToBase64(str){
					return btoa(String.fromCharCode.apply(null,str.replace(/\r|\n/g, "").replace(/([\da-fA-F]{2}) ?/g, "0x$1 ").replace(/ +$/, "").split(" ")));
				}*/
				//var data=hexToBase64(ctnt);// here pass the big hex string
				// it will be open in the web browser like this
				//   document.location.href = 'data:application/pdf ; base64,' +data;
				//to open up in the new window**
				//window.open('data:application/pdf;base64,' + data);
				Transportation.that.dlgSealInf.close();
			};
			
			Transportation.that.postData(path, data, [ "/001" ], "S1", "TripPrint", true, fnCallBack);
		},
		pSealCancel : function(){
			Transportation.that.dlgSealInf.close();
		},		
		downloadPDF : function(tripNo, cNNo){			
			var sPath = "CNPrintPDFSet(TripNum='" + tripNo + "',CNNum='" + cNNo + "')/$value";
			if(cNNo === undefined){
				sPath = "PrintPDFSet(TripNum='" + tripNo + "')/$value";
			}
			Formatter.showLoader();
			Transportation.that.oModel.read(sPath, {
				async : true,
				success : function(oData, oResponse){
					Formatter.hideLoader();
					Utilities.redirectURL();
					window.open(oResponse.requestUri);
				},
				error : function(oError){
					Formatter.hideLoader();
					var msg = "";
					try{
						msg = JSON.parse(oError.response.body).error.message.value;
					}
					catch(err){
						msg = oError.response.body;
					}
					MessageToast.show(msg);
				}
			});
		}
	});
});