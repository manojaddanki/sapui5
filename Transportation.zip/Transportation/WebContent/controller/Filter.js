sap.ui.define([ 'sap/ui/core/mvc/Controller', 'Transportation/util/Formatter', 'sap/m/MessageToast'], 
		function(Controller, Formatter, MessageToast) {
		
	"use strict";
		
	return Controller.extend("Transportation.controller.Filter",{
		
		cDelvyDateRange : function(oEvent) {
			var fromDate = Transportation.that.dRSDeliveryDate.getDateValue();
			var toDate = Transportation.that.dRSDeliveryDate.getSecondDateValue();
			var currDate = new Date();
			this.isDateValid = true;
			var errorMsg = "";
			if (fromDate === null && toDate === null) {
				Transportation.that.dRSDeliveryDate.setValueState("None");
			} else if (fromDate > currDate || toDate > currDate) {
				this.isDateValid = false;
				errorMsg = "Select Date Range within Today";
			} else {
				var isValid = Formatter.validateDateRange(fromDate, toDate);
				if (!isValid) {
					this.isDateValid = false;
					errorMsg = "Select Dates within 15 Days Range";
				}
			}
			if (this.isDateValid) {
				Transportation.that.dRSDeliveryDate.setValueState("None");
				Transportation.that.dRSDeliveryDate.setValueStateText();
				Transportation.that.btnSearch.setEnabled(true);
			} else {
				MessageToast.show(errorMsg);
				Transportation.that.dRSDeliveryDate.setValueState("Error");
				Transportation.that.dRSDeliveryDate.setValueStateText(errorMsg);
				Transportation.that.btnSearch.setEnabled(false);
			}
		},
		sCShipType : function(oEvent) {
			Transportation.that.btnSearch.setEnabled(true);
		},
		pFilterClose : function() {
			Transportation.that.dlgFilter.close();
		},
		pFilterClear : function() {
			// Display default data without any filters
			Transportation.that.pRefresh();
			Transportation.that.dlgFilter.close();
		},
		pFilterSearch : function() {
			if (this.isDateValid) {
				this.isDateValid = undefined;
				Transportation.that.initTableModel();
			} else {
				Transportation.that.fnFilterCallBack();
			}
			var fromDate = Transportation.that.dRSDeliveryDate.getDateValue();
			var toDate = Transportation.that.dRSDeliveryDate.getSecondDateValue();
		//	var shipTypeItemsLen = Transportation.that.mCmbShipType.getSelectedItems().length;
			if(fromDate === null && toDate === null && shipTypeItemsLen === 0){
				Transportation.that.btnFilter.setType("Default");
			}
			else{
				Transportation.that.btnFilter.setType("Emphasized");
			}
			Transportation.that.dlgFilter.close();
		
		},
	});
});