sap.ui.define([ 'sap/ui/core/mvc/Controller', 'sap/ui/core/UIComponent', 'sap/ui/model/json/JSONModel',
                'sap/custom/MessageHandling', 'sap/m/MessageToast', 'sap/m/MessageBox', 'sap/m/GroupHeaderListItem',
                'sap/m/ColumnListItem', 'sap/m/Text', 'sap/m/Link', 'sap/ui/model/Sorter', 'sap/m/Button',
                'sap/m/StandardListItem', 'Transportation/util/Formatter', 'sap/m/Column', 'sap/ui/core/Icon',
                'sap/m/Label', 'sap/m/DisplayListItem', 'sap/m/ResponsivePopover', 'sap/m/List', 'sap/m/Input',
                'sap/m/FlexBox', 'Transportation/controller/Filter', 'Transportation/controller/PrintCN',
                'sap/m/ObjectStatus', 'sap/m/ScrollContainer', 'sap/m/DatePicker','sap/m/ObjectListItem',],
                function(Controller, UIComponent, JSONModel, 
                		MessageHandling, MessageToast, MessageBox, GroupHeaderListItem,
                		ColumnListItem, Text, Link, Sorter, Button,
                		StandardListItem, Formatter, Column, Icon, 
                		Label, DisplayListItem, ResponsivePopover, List, Input,
                		FlexBox, Filter, PrintCN, 
                		ObjectStatus, ScrollContainer, DatePicker,ObjectListItem) {
	"use strict";
	return Controller.extend("Transportation.controller.S2", {
		onInit : function() {
			//Transportation.that=this;
			Transportation.that2=this;
			this.oModel = this.getOwnerComponent().getModel();
			this.getView().setModel(this.oModel);
			this.tblTripDetails = this.byId("tblTripDetails");
			//	this.pnlSealInfo = this.byId("pnlSealInfo");
			//this.tblSealInfo = this.byId("tblSealInfo");
			this.inpSite = this.byId("inpLastLoc");
			this.oi18nModel = this.getOwnerComponent().getModel("i18n");
			this.getRouter().attachRoutePatternMatched(this.onRouteMatched, this);
		},
		onRouteMatched : function(oEvent){
			if(oEvent.getParameter("name") === "S2"){
				if(Transportation.that){
					Transportation.that.oAfterRender = {
							onAfterRendering : function(oEvent){
								var control = oEvent.srcControl;
								if(Transportation.that.tabIndex === undefined){
									Transportation.that.tabIndex = 0;
								}
								control.$().find("input").attr("tabIndex", Transportation.that.tabIndex++);
							}
					};
					this.onclearValue();
					this.byId("vehicletypeId").setEditable(true).setValue("");
					this.byId("shpmtroutId").setEditable(true).setValue("");
					this.byId("shipmentPageId").setTitle("Shipment Details:"+Transportation.that.EntireShipmentNo);
					this.ShipmentNo=Transportation.that.EntireShipmentNo;
					this.shipmentData=Transportation.that.shipmentData;
					this.ShippingType=Transportation.that.ShippingType;
					/*this.vrndata = new JSONModel(Transportation.that.oContextVehicle);
					this.byId("modeId").setText(this.vrndata.getData().TransportModeDesc);
					this.byId("vehicleId").setText(this.vrndata.getData().Vehiclenum);
					this.byId("transportId").setText(this.vrndata.getData().Transporter);
					this.byId("driveId").setText(this.vrndata.getData().LicenseNum);
					this.byId("vrnInfo").setHeaderText("Vrn Detailss: "+this.vrndata.getData().VRNNum);*/
					this.shipmentDeliveryData=[];
					this.vehicleId="";
					var that=this;
					var path = "/DeliveryDetailsSet?$filter=ShipmentNum eq '"+that.ShipmentNo+"' and DeliveryNum eq ''";
					for(var i=0;i<that.shipmentData.length;i++){
						if(that.shipmentData[i].ShipmntNum===that.ShipmentNo){
							that.shipmentDeliveryData.push(that.shipmentData[i]);
						}
					}
					var jsonModel = new JSONModel();
					that.oModel.read(path,null,null,false,function(oData,response){
						for(var i=0;i<oData.results.length;i++){
							oData.results[i].ShipToPartyName=that.shipmentDeliveryData[i].ShipToPartyName;
							oData.results[i].SystemId=that.shipmentDeliveryData[i].Server;
							oData.results[i].CustName=that.shipmentDeliveryData[i].CustName;
							oData.results[i].CustomerNum=that.shipmentDeliveryData[i].CustomerNum;
							oData.results[i].LRDate=new Date();
							that.site=that.shipmentDeliveryData[0].Plant;
							that.ArrangedBy=that.shipmentDeliveryData[0].ArrangedBy;
						}
						that.byId("shpmtroutId").setValue(oData.results[0].Route);
						that.byId("distanceId").setValue(oData.results[0].Distance);
						that.byId("distanceId").setEditable(that.ShippingType==="CR"||that.ShippingType==="CA");
						that.byId("transportId").setText(oData.results[0].ServiceAgent);
						if(that.shipmentDeliveryData[0].ArrangedBy==="N"&&that.shipmentDeliveryData[0].ShippingType==="RD"){
							that.byId("vehicletypeId").setEditable(true).setValue(oData.results[0].VehicleType);
							that.byId("shpmtroutId").setEditable(false);
						}
						if(that.shipmentDeliveryData[0].ArrangedBy==="F"&&that.shipmentDeliveryData[0].ShippingType==="RD"){
							that.byId("vehicletypeId").setEditable(false).setValue(oData.results[0].VehicleType);
							that.byId("shpmtroutId").setEditable(false);
						}
						/*if(that.shipmentDeliveryData[0].ShippingType==="RD"){
							that.byId("shpmtroutId").setEditable(false);
						}*/
						/*if(oData.results[0].VehicleType!==""){
							that.byId("vehicletypeId").setEditable(false).setValue(oData.results[0].VehicleType);
							that.vehicleId=oData.results[0].VehicleType;
						}*/
						that.vehicleId=oData.results[0].VehicleType;
						jsonModel.setData(oData.results);
						that.bindTable(jsonModel);
					},function(oError){
						jsonModel.setData([]);
						that.bindTable(jsonModel);
						sap.custom.MessageHandling.handleRequestFailure(oError);
					});
					
				}
				else{
					this.navBack();
					this.handleReset();
				}
			}
		},
		onclearValue: function(){
			this.getView().byId("vrnInfo").setValue("");
			this.getView().byId("modeId").setText("");
			this.getView().byId("vehicleId").setText("");
			this.getView().byId("transportId").setText("");
			this.getView().byId("driveId").setText("");
			this.getView().byId("transporterId").setValue("");
			this.getView().byId("vehicletypeId").setValue("");
			this.getView().byId("distanceId").setValue("");
			this.getView().byId("shpmtroutId").setValue("");
		},

		//Define Value Help Function for SLloc.
		handleValueHelpTransporter : function() {
			var that=this;
			var VehiNo  = this.getView().byId("transportId").getText();
			if(navigator.onLine){
				this._valueHelpDialog2 = new sap.m.SelectDialog({
					title : "Select Transporter",
					noDataText : "No Entries Found",
					items : {
						//	path : "/SlocSearchSet?$filter=Site eq ''",
						path : "/TransListSet?$filter=ArrangedBy eq '"+that.ArrangedBy+"' and ShippingType eq '"+that.ShippingType+"' and ShipmentNum eq '' and VendorNum eq '"+VehiNo+"' and Region eq ''",  
						template : new sap.m.StandardListItem({
							title : "{TransId}",
							description : "{TransDesc}",
						})
					},
					liveChange : [ this._handleValueHelpTransporterId2Search, this ],
					confirm : [ this._handleValueHelpTransporterId2Close, this ],
					cancel : [ this._handleValueHelpTransporterId2Close, this ]
				});
				this._valueHelpDialog2.setModel(this.oModel);
				this._valueHelpDialog2.open();
			}
			else{
				sap.m.MessageToast.show("You are in offline mode");
			}
		},
		_handleValueHelpTransporterId2Close : function(evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var i1 = this.getView().byId("transporterId");
				i1.setValue(oSelectedItem.getTitle()+" - "+oSelectedItem.getDescription());
				this.TransId = oSelectedItem.getTitle();
				///this.handleDisplay(); y added manoj 
			}
		},
		_handleValueHelpTransporterId2Search : function(evt) {
			var sValue = evt.getParameter("value").toLowerCase();
			var keys = evt.getSource().getBinding("items").aKeys;
			var smodel =  evt.getSource().getModel();
			for (var i = 0; i < this._valueHelpDialog2.getItems().length; i++){
				var val = smodel.getProperty("/" + keys[i]).Sloc.toLowerCase();
				var val1 = smodel.getProperty("/" + keys[i]).SlocDesc.toLowerCase();
				if (val.indexOf(sValue) > -1 || val1.indexOf(sValue) > -1){
					this._valueHelpDialog2.getItems()[i].setVisible(true);
				} else {
					this._valueHelpDialog2.getItems()[i].setVisible(false);
				}
			}
		},

		//handel VRN 
		handleValueHelpVRN:function(){
			var that=this;
			if(!that.dlgVehicles){
				that.dlgVehicles = sap.ui.xmlfragment("Transportation.fragment.Vehicles", that);
			}
			var objListItem = new ObjectListItem({
				title : "{path:'Vehiclenum', formatter:'Transportation.util.Formatter.getVehicleNum'}",
				type : "{path:'Status', formatter:'Transportation.util.Formatter.getListType'}",					
				number : "{VRNNum}",
				//numberUnit : "{FleetType}",
				numberState : "{path:'Status', formatter:'Transportation.util.Formatter.getInfoState'}",
				press : [ that.cnVehicles, that ]
			});
			var path = "/VRNHeaderSet?$filter=VRNNum eq '' and VRNInOutInd eq '' and Plant eq '' and SLoc eq ''&$expand=VRNHDRITMNAV ";
			Formatter.showLoader();
			that.oModel.read(path,{
				async : true,
				success : function(oData){
					Formatter.hideLoader();
					var oVehModel = new JSONModel(oData.results);
					that.dlgVehicles.setModel(oVehModel);
					sap.ui.getCore().byId("lstVehicles").bindAggregation("items",{
						path : "/",
						template : objListItem,
						filters : [ new sap.ui.model.Filter("Purpose", sap.ui.model.FilterOperator.EQ, "OUTBOUND"),
						            new sap.ui.model.Filter("VehicleType", sap.ui.model.FilterOperator.EQ, Transportation.that.ShippingType)]							
					});
					that.dlgVehicles.open();
				},
				error : function(oError){
					Formatter.hideLoader();
					var msg = JSON.parse(oError.response.body).error.message.value;
					MessageToast.show(msg);
				}
			});
		},
		cnVehicles : function(oEvent){
			var aData=oEvent.getSource().getBindingContext().getObject();
			this.vrndata=aData;
			this.byId("modeId").setText(aData.TransportModeDesc);
			this.byId("vehicleId").setText(aData.Vehiclenum);
			this.VrnDate=Formatter.getDate1(aData.CreatedOn);

			if(this.shipmentDeliveryData[0].ArrangedBy!=="F"||this.shipmentDeliveryData[0].ShippingType!=="RD"){
				if(aData.VehicleId!==""){
					this.byId("vehicletypeId").setEditable(false).setValue(aData.VehicleId);
					this.vehicleId=aData.VehicleId;
					this.byId("vehicletypeId").setTooltip(aData.VehicleDesc);
				}
				if(aData.VehicleId===""){
					this.byId("vehicletypeId").setEditable(true).setValue(aData.VehicleId);
					this.vehicleId=aData.VehicleId;
					this.byId("vehicletypeId").setTooltip(aData.VehicleDesc);
				}
			}
			//this.byId("transportId").setText(aData.Transporter);
			this.byId("driveId").setText(aData.LicenseNum);
			this.byId("vrnInfo").setValue(aData.VRNNum);
			this.dlgVehicles.close();
		},		
		pCancel : function(oEvent){
			this.dlgVehicles.close();
		},
		lCLastLoc : function(oEvent){
			var inpNo = oEvent.getSource();
			inpNo.setValue(inpNo.getValue().toUpperCase());
		},
		lCDepSeal1 : function(oEvent){
			var inpNo = oEvent.getSource();
			this.fnValidate(inpNo, /^[A-Za-z0-9]+$/, "DepSeal1", this.oi18nModel.getProperty("msgDepSeal"), false);
		},
		lCDepSeal2 : function(oEvent){
			var inpNo = oEvent.getSource();
			this.fnValidate(inpNo, /^[A-Za-z0-9]+$/, "DepSeal2", this.oi18nModel.getProperty("msgDepSeal"), false);
		},
		fnPopupData : function(oContext, bCreateTrip, bDisplay){
			var oData = {					
					DeliveryNum : oContext.DeliveryNum,					
					Edd : Formatter.getDate1((oContext.Edd === undefined) ? oContext.DeliveryDate : oContext.Edd),
					NumPackages : (oContext.NumPackages === "" || oContext.NumPackages === undefined) ? 0 : parseInt(oContext.NumPackages),
							PackageUnit : Formatter.getPackageUnit(oContext.PackageUnit),
							Weight : oContext.Weight,
							WeightUnit : Formatter.getWeightUnit(oContext.WeightUnit),
							Volume : oContext.Volume,
							VolumeUnit : Formatter.getVolumeUnit(oContext.VolumeUnit)					
			};
			if(bCreateTrip){
				oData.DocketNum = oContext.LRNum;
				oData.DocketDate = (oContext.LRDate !== null) ? Formatter.getDate1(oContext.LRDate) : Formatter.getDate1(oContext.CurrentDate);
			}
			if(bDisplay){
				oData.ShipToPartyName =  oContext.ShipToPartyName;
				oData.ShipToPartyId = oContext.ShipToPartyId;
				oData.ShippingType = oContext.ShippingType;
				oData.ShippingDesc = oContext.ShippingDesc;
				oData.SystemId = oContext.SystemId;
				oData.LRNum = oContext.LRNum;
				oData.LRDate = oContext.LRDate;
			}
			return oData;
		},
		getDeliveryDetails : function(){
			var  aItemNav, selItems, table = Transportation.that.getTable("open");
			aItemNav = [];
			selItems = [];
			if(table !== ""){
				selItems = table.getSelectedItems();
			}			
			var selItemsLen = selItems.length;
			for(var i = 0; i < selItemsLen; i++){
				var context = selItems[i].getBindingContext().getObject();
				if(context.GroupHeader !== undefined){
					this.shipType = context.ShippingType;
					var oItemNav = {
							DeliveryNum : context.DeliveryNum,
							ItemNum : context.DelItemNum
					};
					aItemNav.push(oItemNav);
				}
			}			
			var data = {
					Mode : Formatter.getMode(),
					TripNum : this.tripNo,
					TRHDRTRDTHDRNAV : aItemNav,
					TRHDRTRDTITMNAV : [] 
			};
			if(Transportation.that.dRSDeliveryDate && Transportation.that.dRSDeliveryDate.getDateValue() !== null && Transportation.that.dRSDeliveryDate.getSecondDateValue() !== null){
				data.FromDate = Formatter.getDate(Transportation.that.dRSDeliveryDate.getDateValue());
				data.ToDate = Formatter.getDate(Transportation.that.dRSDeliveryDate.getSecondDateValue());
			}

			/*fnCallBack = function(oData){
				jsonModel.setData(oData.TRHDRTRDTITMNAV.results);
				that.bindTable(jsonModel);
			},
			fnErrorCallBack = function(){
				jsonModel.setData([]);
				that.bindTable(jsonModel);
			};*/
			//Transportation.that.postData(path, data, [], "S2", "TripDetailsPopUp", false, fnCallBack, fnErrorCallBack);
		},


		handleValueHelpRoute:function(evt){
			this.RouteSrc=evt.getSource();
			this.RouteContxt=evt.oSource.oParent.getBindingContext();
			if(!this.Route2Operator){
				this.Route2Operator = sap.ui.xmlfragment("Transportation.fragment.Route2", this);
			}
			this.Route2Operator.open();
		},

		//Define Value Help Function for SLloc.
		RouteSubmit2 : function(evt) {
			var routeValue=sap.ui.getCore().byId("routeselectionId2").getValue().toUpperCase();
			if(routeValue.length===1||routeValue.length===0){
				sap.m.MessageToast.show("Enter minimum 2 letters");
				return;
			}
			sap.ui.getCore().byId("routeselectionId2").setValue("");
			this.Route2Operator.close();
			this._RouteDialog2 = new sap.m.SelectDialog({
				title : "Select Route",
				noDataText : "No Entries Found",
				growing:true,
				growingThreshold:3000,
				growingScrollToLoad:true,
				items : {
					path : "/RouteListSet?$filter=Route eq'"+routeValue+"'",
					template : new sap.m.StandardListItem({
						title : "{Route}",
						description : "{Description}",
						tooltip:"{Distance}",
					})
				},
				liveChange : [ this._Route22Search, this ],
				confirm : [ this._Route22Close, this ],
				cancel : [ this._Route22Close, this ],
			});
			this._RouteDialog2.setModel(this.oModel);
			this._RouteDialog2.open();
		},
		_Route22Close : function(evt) {

			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				this.RouteSelectionValue = oSelectedItem.getTitle();
				this.distance=oSelectedItem.getTooltip();
				this.byId("shpmtroutId").setValue(this.RouteSelectionValue);
				this.byId("distanceId").setValue(this.distance);
				//oTable.getModel().updateBindings();
				this.RouteSrc.setValue(this.RouteSelectionValue);
			}
		},
		_Route22Search : function(evt) {
			var sValue = evt.getParameter("value").toLowerCase();
			var keys = evt.getSource().getBinding("items").aKeys;
			var smodel =  evt.getSource().getModel();
			for (var i = 0; i < this._RouteDialog2.getItems().length; i++){
				var val = smodel.getProperty("/" + keys[i]).Route.toLowerCase();
				var val1 = smodel.getProperty("/" + keys[i]).Description.toLowerCase();
				if (val.indexOf(sValue) > -1 || val1.indexOf(sValue) > -1){
					this._RouteDialog2.getItems()[i].setVisible(true);
				} else {
					this._RouteDialog2.getItems()[i].setVisible(false);
				}
			}
		},
		RouteCancel2:function(){
			this.Route2Operator.close();
			sap.ui.getCore().byId("routeselectionId2").setValue("");
		},
		bindTable : function(oModel){
			var that=this;
			if(oModel.oData.length > 0){
				this.byId("btnCreateTripSubmit").setVisible(true);//Hide Submit button when no data displayed
			}
			else{
				this.byId("btnCreateTripSubmit").setVisible(false);
			}
			var columns = this.tblTripDetails.getColumns();
			//rgvd_richa added condition for Arrange by F 
			var ArrBy = that.shipmentDeliveryData[0].ArrangedBy;
			if((this.ShippingType == "RD" && ArrBy == "F" ) || this.ShippingType == "HD"){
				columns[3].setVisible(false);
				columns[4].setVisible(false);
			}
			else{
				columns[3].setVisible(true);
				columns[4].setVisible(true);
			}
			/*switch(this.ShippingType){
			case "RD" : 
				columns[3].setVisible(false);
				columns[4].setVisible(false);
				break;
			case "HD" : 
				columns[3].setVisible(false);
				columns[4].setVisible(false);
				break;
			default : 
				columns[3].setVisible(true);
				columns[4].setVisible(true);
			}*/
			/*columns[6].getHeader().setText(this.oi18nModel.getProperty("colVol") + " (" + Formatter.getPackageUnit() + ")");
			columns[6].getHeader().setText(this.oi18nModel.getProperty("colWei") + " (" + Formatter.getWeightUnit() + ")");
			 */
			this.tblTripDetails.unbindAggregation("items");
			this.tblTripDetails.setModel(oModel);
			this.tblTripDetails.bindAggregation("items", {
				path : "/",
				sorter : new Sorter({
					path : "ShipToPartyId",
					descending : false,
					group : false
				}),
				template : new ColumnListItem({
					cells : [
					         new FlexBox({
					        	 items : [
					        	          new Icon({
					        	        	  src : "{path:'ShippingType', formatter:'Transportation.util.Formatter.getShipTypeIcon'}",
					        	        	  tooltip : "{ShippingDesc}",
					        	        	  color : "{path:'ShippingType', formatter:'Transportation.util.Formatter.getShipTypeIconColor'}"
					        	          }).addStyleClass("sapUiSmallMarginEnd"),									         	
					        	          new Text({
					        	        	  text : "{CustName} ({CustomerNum})"
					        	          })
					        	          ]
					         }),
					         new Text({
					        	 text : "{SystemId}"
					         }),
					         new Text({
					        	 text : "{DeliveryNum}"
					         }),	 			            	
					         new Input({
					        	 value : "{LRNum}",
					        	 placeholder : this.oi18nModel.getProperty("phDocNo"),
					        	 maxLength : 15,
					        	 // liveChange : [ this.lCDocNo, this ]
					         }),
					         new DatePicker({
					        	 dateValue : "{LRDate}",
					        	 placeholder : this.oi18nModel.getProperty("phDocDate"),
					        	 displayFormat : Formatter.getDateDisplayFormat(),
					        	 valueFormat : Formatter.getDateDisplayFormat(),
					        	 change:[this.handleDateChange,this]
					         // change : [ this.cDD, this ]
					         }),
					         /* new DatePicker({	 			            		
					        	 dateValue : "{Edd}",
					        	 placeholder : this.oi18nModel.getProperty("phEdd"),
					        	 displayFormat : Formatter.getDateDisplayFormat(),
					        	 valueFormat : Formatter.getDateDisplayFormat(),
					        	 change : [ this.cEDD, this ]
					         }).addEventDelegate(Transportation.that.oAfterRender),*/
					         new Input({
					        	 value : "{NumPackages}",
					        	 placeholder : this.oi18nModel.getProperty("phNoPkgs"),
					        	 maxLength : 9,
					        	 // liveChange : [ this.lCNumPacks, this]
					         }),
					         new Input({
					        	 // change : [ that.handleValueUoM, that ],
					        	 value : "",
					        	 tooltip:"",
					        	 valueHelpOnly:true, 
					        	 showSuggestion:true,
					        	 showValueHelp:true,
					        	 placeholder : "Enter Volume",
					        	 maxLength : 10,
					        	 valueHelpRequest : function(evt){
					        		 that.PackingSrc=evt.getSource();
					        		 if(navigator.onLine){
					        			 that._valueHelpDialog2 = new sap.m.SelectDialog({
					        				 title : "Select UoM",
					        				 growing:true,
					        				 growingThreshold:2000,
					        				 growingScrollToLoad:true,
					        				 noDataText : "No Entries Found",
					        				 items : {
					        					 path : "/UoMListSet",
					        					 template : new sap.m.StandardListItem({
					        						 title : "{UoMDesc}",
					        						 description : "{UoM}",
					        					 })
					        				 },
					        				 liveChange : [ that._handleValueHelpPackingSearch, that ],
					        				 confirm : [ that._handleValueHelpPackingClose, that ],
					        				 cancel : [ that._handleValueHelpPackingClose, that ]
					        			 });
					        			 that._valueHelpDialog2.setModel(that.oModel);
					        			 that._valueHelpDialog2.open();
					        		 }
					        		 else{
					        			 sap.m.MessageToast.show("You are in offline mode");
					        		 }
					        	 }
					         // change : [ this.cVolume, this ]
					         }),
					         new Input({
					        	 value : "{DeliveryWeight}",
					        	 placeholder : this.oi18nModel.getProperty("phWei"),
					        	 maxLength : 10,
					        	 //	 change : [ this.cWeight, this ]
					         }),

					         new Input({
					        	 value : "{DeliveryVolume}",
					        	 placeholder : this.oi18nModel.getProperty("phNoPkgs"),
					        	 maxLength : 9,
					        	 // liveChange : [ this.lCNumPacks, this]
					         })
					         /*  new Input({
					        	 // change : [ that.handleValueUoM, that ],
					        	 value : "",
					        	 id:"volumeUnitId",
					        	 tooltip:"",
					        	 valueHelpOnly:true, 
					        	 showSuggestion:true,
					        	 showValueHelp:true,
					        	 placeholder : "Enter Volume",
					        	 maxLength : 10,
					        	 valueHelpRequest : function(evt){
					        		 that.VolumeSrc=evt.getSource();
					        		 if(navigator.onLine){
					        			 that._valueHelpDialog2 = new sap.m.SelectDialog({
					        				 title : "Select UoM",
					        				 growing:true,
					        				 growingThreshold:2000,
					        				 growingScrollToLoad:true,
					        				 noDataText : "No Entries Found",
					        				 items : {
					        					 path : "/UoMListSet",
					        					 template : new sap.m.StandardListItem({
					        						 title : "{UoMDesc}",
					        						 description : "{UoM}",
					        					 })
					        				 },
					        				 liveChange : [ that._handleValueHelpVolumeSearch, that ],
					        				 confirm : [ that._handleValueHelpVolumeClose, that ],
					        				 cancel : [ that._handleValueHelpVolumeClose, that ]
					        			 });
					        			 that._valueHelpDialog2.setModel(that.oModel);
					        			 that._valueHelpDialog2.open();
					        		 }
					        		 else{
					        			 sap.m.MessageToast.show("You are in offline mode");
					        		 }
					        	 }
					         // change : [ this.cVolume, this ]
					         })*/
					         ]
				})
			});
			/*var aSTP, items = this.tblTripDetails.getItems(), itemsLen = items.length;
			aSTP = [];
			for(var i = 0; i < itemsLen; i++){
				var oContext = items[i].getBindingContext().getObject();
				if(aSTP[oContext.ShipToPartyId]){
					if(this.aSTP2[oContext.SystemId]){
						if(aSTP[oContext.ShipToPartyId].LRNum === ""){
							aSTP[oContext.ShipToPartyId].LRNum = oContext.LRNum;
						}
						if(aSTP[oContext.ShipToPartyId].LRDate === null){
							aSTP[oContext.ShipToPartyId].LRDate = oContext.LRDate;
						}
						if(aSTP[oContext.ShipToPartyId].Edd === null){
							aSTP[oContext.ShipToPartyId].Edd = oContext.Edd;
						}
						if(aSTP[oContext.ShipToPartyId].NumPackages === 0){
							aSTP[oContext.ShipToPartyId].NumPackages = oContext.NumPackages;
						}
						if(parseInt(aSTP[oContext.ShipToPartyId].Weight) === 0){
							aSTP[oContext.ShipToPartyId] = oContext.Weight;
						}
						if(parseInt(aSTP[oContext.ShipToPartyId].Volume) === 0){
							aSTP[oContext.ShipToPartyId].Volume = oContext.Volume;
						}
						for(var j = 3; j <= 7; j++){
							items[i].getCells()[j].setVisible(false);						
						}
					}else{
						aSTP[oContext.ShipToPartyId] = oContext;
						this.aSTP2[oContext.SystemId] = oContext;
						for(var j = 3; j <= 7; j++){
							items[i].getCells()[j].setVisible(true);
						}
					}
				}
				else{
					this.aSTP2=[];
					aSTP[oContext.ShipToPartyId] = oContext;
					this.aSTP2[oContext.SystemId] = oContext;
					for(var j = 3; j <= 7; j++){
						items[i].getCells()[j].setVisible(true);
					}
				}			
			}			
			for(var i = 0; i < itemsLen; i++){
				var oContext = items[i].getBindingContext().getObject();				
				oContext.LRNum = aSTP[oContext.ShipToPartyId].LRNum;
				oContext.LRDate = aSTP[oContext.ShipToPartyId].LRDate;
				oContext.Edd = aSTP[oContext.ShipToPartyId].Edd;
				items[i].getCells()[3].setValue(oContext.LRNum);
				items[i].getCells()[4].setDateValue(oContext.LRDate);
				//items[i].getCells()[5].setDateValue(oContext.Edd);
				if(items[i].getCells()[6].getVisible()){
					items[i].getCells()[6].setValue(aSTP[oContext.ShipToPartyId].NumPackages);
					oContext.NumPackages = aSTP[oContext.ShipToPartyId].NumPackages;
				}
				else{
					items[i].getCells()[6].setValue();
					oContext.NumPackages = 0;
				}
				if(items[i].getCells()[7].getVisible()){
					items[i].getCells()[7].setValue(aSTP[oContext.ShipToPartyId].Weight);
				}
				else{
					items[i].getCells()[7].setValue();
					oContext.Weight = "0";
				}
				if(items[i].getCells()[8].getVisible()){
					items[i].getCells()[8].setValue(aSTP[oContext.ShipToPartyId].Volume);
				}
				else{
					items[i].getCells()[8].setValue();
					oContext.Volume = "0";
				}
			}*/

			var oTable = that.getView().byId("tblTripDetails");
			for(var i=0;i<that.shipmentDeliveryData.length;i++){
				oTable.getItems()[i].getCells()[6].setValue(that.shipmentDeliveryData[i].UoM); //added from 1st page 
			}


		},

		handleDateChange:function(oEvent){
			var src=oEvent.getSource();
			var toDate=new Date(src.getValue());
			var dte = new Date();
			if(dte<toDate){
				sap.m.MessageToast.show("Future Dates must not Select");
				//this.inputFrom=this.formatter.Date(fromDate);
				src.setValue(Formatter.DateFormat(dte));
				return;
			}
		},

		_handleValueHelpPackingClose : function(evt) {
			var that=Transportation.that2;
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				that.PackingSrc.setValue(oSelectedItem.getDescription());
				that.PackingSrc.setTooltip(oSelectedItem.getTitle()+" - "+oSelectedItem.getDescription());
				that.LrUnit =oSelectedItem.getDescription();

			}
		},
		_handleValueHelpPackingSearch : function(evt) {
			var sValue = evt.getParameter("value").toLowerCase();
			var keys = evt.getSource().getBinding("items").aKeys;
			var smodel =  evt.getSource().getModel();
			for (var i = 0; i < this._valueHelpDialog2.getItems().length; i++){
				var val = smodel.getProperty("/" + keys[i]).UoM.toLowerCase();
				var val1 = smodel.getProperty("/" + keys[i]).UoMDesc.toLowerCase();
				if (val.indexOf(sValue) > -1 || val1.indexOf(sValue) > -1){
					this._valueHelpDialog2.getItems()[i].setVisible(true);
				} else {
					this._valueHelpDialog2.getItems()[i].setVisible(false);
				}
			}
		},


		/*_handleValueHelpVolumeClose : function(evt) {
			var that=Transportation.that2;
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				that.VolumeSrc.setValue(oSelectedItem.getTitle()+" - "+oSelectedItem.getDescription());
				that.VolumeSrc.setTooltip(oSelectedItem.getTitle()+" - "+oSelectedItem.getDescription());
				that.VolumeUnit =oSelectedItem.getDescription();

			}
		},
		_handleValueHelpVolumeSearch : function(evt) {
			var sValue = evt.getParameter("value").toLowerCase();
			var keys = evt.getSource().getBinding("items").aKeys;
			var smodel =  evt.getSource().getModel();
			for (var i = 0; i < this._valueHelpDialog2.getItems().length; i++){
				var val = smodel.getProperty("/" + keys[i]).UoM.toLowerCase();
				var val1 = smodel.getProperty("/" + keys[i]).UoMDesc.toLowerCase();
				if (val.indexOf(sValue) > -1 || val1.indexOf(sValue) > -1){
					this._valueHelpDialog2.getItems()[i].setVisible(true);
				} else {
					this._valueHelpDialog2.getItems()[i].setVisible(false);
				}
			}
		},
		 */

		fnValidate : function(inpNo, regex, property, errMsg, bSetAllItems){			
			var inpNoVal = inpNo.getValue();
			if(regex.test(inpNoVal)){
				var currItem = inpNo.getParent(),
				currItemContext = currItem.getBindingContext().getObject();
				if(property === "Edd"){
					var currDate = new Date();
					currDate.setHours(0,0,0,0);
					if(inpNo.getDateValue() < currDate){
						inpNo.setValue();
						inpNo.setValueState("Error");
						inpNo.setValueStateText(this.oi18nModel.getProperty("msgPastDate"));
						MessageToast.show(this.oi18nModel.getProperty("msgPastDate"));
						return;
					}
				}
				if(property === "NumPackages"){
					if(!(parseInt(inpNoVal) > 0)){
						inpNo.setValue();
						inpNo.setValueState("Error");
						inpNo.setValueStateText(this.oi18nModel.getProperty("valNumsNotZero"));
						MessageToast.show(this.oi18nModel.getProperty("valNumsNotZero"));
						return;
					}
				}
				if(property === "Weight"){
					if(!(parseFloat(inpNoVal) > 0)){
						inpNo.setValue();
						inpNo.setValueState("Error");
						inpNo.setValueStateText(this.oi18nModel.getProperty("valNumsNotZero"));
						MessageToast.show(this.oi18nModel.getProperty("valNumsNotZero"));
						return;
					}
				}
				inpNo.setValueState("None");
				inpNo.setValueStateText();
				for(var prop in currItemContext){
					if(prop === property){
						if(inpNo instanceof DatePicker){
							currItemContext[prop] = new Date(inpNoVal);
						}
						else{
							currItemContext[prop] = inpNoVal;
						}
						break;
					}
				}
				if(bSetAllItems){
					var currItemSTP = currItem.getBindingContext().getObject().ShipToPartyId,
					currsysId = currItem.getBindingContext().getObject().SystemId,
					table = currItem.getParent(),
					items = table.getItems(),
					itemsLen = items.length,
					currItemIndex = table.indexOfItem(currItem);
					for(var i = 0; i < itemsLen; i++){
						var oContext = items[i].getBindingContext().getObject(),
						shipToParty = oContext.ShipToPartyId,
						sysId=oContext.SystemId;
						if(currItemSTP === shipToParty && currsysId ===sysId && currItemIndex !== i){
							for(var prop in oContext){
								if(prop === property){
									if(inpNo instanceof DatePicker){
										oContext[prop] = new Date(inpNoVal);
									}
									else{
										if(prop === "NumPackages" || prop === "Weight" || prop === "Volume"){
											if(currsysId===sysId){
												oContext[prop] = "0";
												currItemContext[prop] = inpNoVal;
											}else{
												currItemContext[prop] = inpNoVal;
												return;

											}
										}
										else{
											oContext[prop] = inpNoVal;
										}
									}
									break;
								}
							}
						}
					}
				}				
			}
			else{
				inpNo.setValue();
				inpNo.setValueState("Error");
				inpNo.setValueStateText(errMsg);
				MessageToast.show(errMsg);
			}
		},
		lCDocNo : function(oEvent){
			var inpNo = oEvent.getSource();
			this.fnValidate(inpNo, /^[A-Za-z0-9]+$/, "LRNum", this.oi18nModel.getProperty("valAlphaNum"), true);
		},
		cDD : function(oEvent){
			var inpNo = oEvent.getSource();
			this.fnValidate(inpNo, /^\d{1,2} [A-Za-z]{3} \d{4}$/, "LRDate", this.oi18nModel.getProperty("valDate"), true);
		},
		cEDD : function(oEvent){
			var inpNo = oEvent.getSource();
			this.fnValidate(inpNo, /^\d{1,2} [A-Za-z]{3} \d{4}$/, "Edd", this.oi18nModel.getProperty("valDate"), true);
		},
		lCNumPacks : function(oEvent){			
			var inpNo = oEvent.getSource();
			this.fnValidate(inpNo, /^[0-9]+$/, "NumPackages", this.oi18nModel.getProperty("valNums"), true);
		},
		cWeight : function(oEvent){			
			var inpNo = oEvent.getSource();
			this.fnValidate(inpNo, /^\d+(\.\d{1,4})?$/, "Weight", this.oi18nModel.getProperty("valNums"), true);			
		},
		cVolume : function(oEvent){
			var inpNo = oEvent.getSource();
			this.fnValidate(inpNo, /^\d+(\.\d{1,4})?$/, "Volume", this.oi18nModel.getProperty("valNums"), true);			
		},		
		pCreationTripSubmit2: function(oEvent){
			var items = this.tblTripDetails.getItems(),
			itemsLen = items.length;
			for(var i = 0; i < itemsLen; i++){
				if(this.tblTripDetails.getColumns()[3].getVisible()){
					if(items[i].getCells()[3].getVisible() === true && items[i].getCells()[3].getValue() === ""){
						MessageToast.show(this.oi18nModel.getProperty("phDocNo"));
						return;
					}
				}
				if(items[i].getCells()[5].getVisible() === true && items[i].getCells()[5].getValue() === ""){
					MessageToast.show(this.oi18nModel.getProperty("phEdd"));
					return;
				}
				if(items[i].getCells()[6].getVisible() === true && items[i].getCells()[6].getValue() === ""){
					MessageToast.show(this.oi18nModel.getProperty("phNoPkgs"));
					return;
				}
				if(items[i].getCells()[6].getVisible() === true && (!(parseInt(items[i].getCells()[6].getValue()) > 0))){
					MessageToast.show(this.oi18nModel.getProperty("valPkgsNotZero"));
					return;
				}
				if(items[i].getCells()[7].getVisible() === true && items[i].getCells()[7].getValue() === ""){
					MessageToast.show(this.oi18nModel.getProperty("phWei"));
					return;
				}
				if(items[i].getCells()[7].getVisible() === true && (!(parseFloat(items[i].getCells()[7].getValue()) > 0))){
					MessageToast.show(this.oi18nModel.getProperty("valWeightNotZero"));
					return;
				}
				if(items[i].getCells()[8].getVisible() === true && items[i].getCells()[8].getValue() === ""){
					MessageToast.show(this.oi18nModel.getProperty("phVol"));
					return;
				}				
			}
			if(Transportation.that.Site !== undefined){
				var that = this,
				sSiteVal = this.inpSite.getValue().toUpperCase(),
				sPath = "/SiteF4Set?$filter=Site eq '" + sSiteVal + "'";
				Formatter.showLoader();
				Transportation.that.oModel.read(sPath, {
					async : true,
					success : function(oData, oResponse){
						Formatter.hideLoader();
						var aSite = oData.results.filter(function(ele){
							return (ele.Site === sSiteVal);
						});
						if(aSite.length > 0){
							that.inpSite.setValueState("None");
							that.inpSite.setValueStateText("");
							if(that.tripNo === "0"){
								that.fnCreateTrip();
							}
						}
						else{
							that.inpSite.setValueState("Error");
							that.inpSite.setValueStateText(that.oi18nModel.getProperty("msgSiteInvalid"));
							MessageToast.show(that.oi18nModel.getProperty("msgSiteInvalid"));
						}
					},
					error : function(oError){
						Formatter.hideLoader();
						that.inpSite.setValueState("Error");
						that.inpSite.setValueStateText(that.oi18nModel.getProperty("msgSiteInvalid"));
						MessageToast.show(that.oi18nModel.getProperty("msgSiteInvalid"));
					}
				});
			}
			else{
				if(this.tripNo === "0"){
					this.fnCreateTrip();
				}
				else{
					this.fnAddDeliveryToTrip();
				}
			}			
		},
		fnCreateTrip : function(){
			var items = this.tblTripDetails.getItems(),
			itemsLen = items.length,
			aHeadNav;
			aHeadNav = [];
			for(var i = 0; i < itemsLen; i++){
				var oContext = items[i].getBindingContext().getObject();				
				aHeadNav.push(this.fnPopupData(oContext, true));
			}
			sealItemsLen = sealItems.length,
			aSealInfNav;
			aSealInfNav = [];
			for(var i = 0; i < sealItemsLen; i++){
				var oContext = sealItems[i].getBindingContext().getObject(),
				oSealInf = {
					LocationCode : oContext.LocationCode,
					StageSeq : oContext.StageSeq,
					DepSeal1 : oContext.DepSeal1,
					DepSeal2 : oContext.DepSeal2,
					Indicator : oContext.Indicator
				};
				aSealInfNav.push(oSealInf);
			}
			var data  = {};
			if(Transportation.that.oContextVehicle){
				Transportation.that.fnAddVRNDetails(data);
			}
			if(Transportation.that.Site !== undefined){				
				data.Site = this.inpSite.getValue().toUpperCase();
				Transportation.that.Site = undefined;
			}
			data.TRCRHDRTRPOPNAV = aHeadNav;
			data.TRCRHDREXECUTNAV = Transportation.that.fnGetItemNav();
			data.TRCRHDRSELINFNAV = aSealInfNav;
			var that = this,
			path = "TripCreHeaderSet",
			fnCallBack = function(oData, oResponse){
				var tripNo = "",
				bSuccess = true;
				if (oResponse.headers instanceof Array) {
					var sapmsg = oResponse.headers['sap-message'];
					if (sapmsg == undefined) {
						console.log("no sap-message is defined");
						bSuccess = false;
					}
					else {
						var svl = oResponse.headers['sap-message'].toString(),
						regex = /[0-9]+/g,
						msg = JSON.parse(svl);
						tripNo  = msg.message.match(regex)[0];
					}
				} else {
					bSuccess = false;
				}
				var shipTypes =  Formatter.getValidCNShipTypes();
				if(shipTypes.indexOf(that.shipType) > -1 && Transportation.that.oContextVehicle !== undefined && bSuccess){
					MessageBox.show(that.oi18nModel.getProperty("msgCreateCN"), {
						title : "Confirmation",
						icon : MessageBox.Icon.QUESTION,
						actions : [ 'Yes', 'No' ],
						onClose : function(oAction) {
							if(oAction === "Yes"){
								that.fnCreateCN(tripNo, data.TRCRHDREXECUTNAV);
							}
							else{
								Transportation.that.fnRefreshData();
								that.navBack();
							}
						}
					});
				}
				else if(bSuccess){
					Transportation.that.fnRefreshData();
					that.navBack();
				}
			};
			Transportation.that.postData(path, data, [ "/001" ], "S2", "TripCreation", true, fnCallBack);
		},
		lCStartKMS : function(oEvent){
			var control = oEvent.getSource(), val = control.getValue();
			if(!/^[0-9]+$/.test(val)){
				MessageToast.show(this.oi18nModel.getProperty("valNums"));
				control.setValue();
			}
		},
		pStartKMSCancel : function(){
			this.dlgStartKMS.close();
			this.fnCreateCNPopUp();
		},
		pStartKMSSubmit : function(){
			if(this.inpStartKMS !== ""){
				var aItem;
				aItem = [];
				for(var i = 0; i < aItemNav.length; i++){
					var oItem = {
							DeliveryNum : aItemNav[i].DeliveryNum	
					};
					aItem.push(oItem);
				}
				var that = this,
				path = "",
				data = {
						TripNum : tripNo,
						CNCREHDRITEMNAV : aItem
				},
				fnCallBack = function(oData, oResponse){
					that.fnCreateCNPopUp();
				};
				Transportation.that.postData(path, data, [ "ZMOB/275" ], "S2", "StartKMS", true, fnCallBack);
			}
			else{
				MessageToast.show(this.oi18nModel.getProperty("msgStartKms"));
			}
		},
		fnCreateCNPopUp : function(data){
			var that = this;
			var cNShipTypes = Formatter.getValidCNShipTypes();
			if(cNShipTypes.indexOf(this.shipType) > -1){
				MessageBox.show(this.oi18nModel.getProperty("msgCreateCN"), {
					title : "Confirmation",
					icon : MessageBox.Icon.QUESTION,
					actions : [ 'Yes', 'No' ],
					onClose : function(oAction) {
						if(oAction === "Yes"){
							that.fnCreateCN(that.tripNo, data.TRCRHDREXECUTNAV);
						}
						else{
							Transportation.that.fnRefreshData();
							that.navBack();
						}
					}
				});
			}
		},
		fnPrint : function(tripNo, actions){
			var that = this;
			MessageBox.show(that.oi18nModel.getProperty("msgPrinting"), {
				title : "Information",
				icon : MessageBox.Icon.INFORMATION,
				actions : actions,
				onClose : function(oAction) {
					var printCN = new PrintCN();
					if(oAction === that.oi18nModel.getProperty("printTrip")){										
						printCN.downloadPDF(tripNo);
					}
					else if(oAction === that.oi18nModel.getProperty("printCN")){
						printCN.downloadPDF(tripNo, "");
					}
					Transportation.that.fnRefreshData();
					that.navBack();
				}
			});
		},		
		fnCreateCN : function(tripNo, aItemNav){
			var aItem;
			aItem = [];
			for(var i = 0; i < aItemNav.length; i++){
				var oItem = {
						DeliveryNum : aItemNav[i].DeliveryNum	
				};
				aItem.push(oItem);
			}
			var that = this,
			path = "CNCreateHdrSet",
			data = {
					VRNNum : Transportation.that.oContextVehicle.VRNNum,
					TripNum : tripNo,
					CNCREHDRITEMNAV : aItem
			},
			fnCallBack = function(oData, oResponse){
				Transportation.that.fnRefreshData();
				that.navBack();
			};
			Transportation.that.postData(path, data, [ "ZMOB/275", "ZMOB/276" ], "S2", "CreateCN", true, fnCallBack);
		},
		fnAddDeliveryToTrip : function(){
			var items = this.tblTripDetails.getItems(), itemsLen = items.length, aItemNav, aHeadNav;
			aItemNav = [];			
			aHeadNav = [];
			for(var i = 0; i < itemsLen; i++){
				var oContext = items[i].getBindingContext().getObject(),
				oItemNav = {
					TripNum : oContext.TripNum,
					VRNNum : oContext.VRNNum,
					GroupId : oContext.GroupId,
					InvoiceNum : oContext.InvoiceNum,
					DeliveryNum : oContext.DeliveryNum,
					InWardPermit : oContext.InWardPermit,
					OutWardPermit : oContext.OutWardPermit,
					LRNum : oContext.LRNum,
					LRDate: Formatter.getDate1(oContext.LRDate),
					Edd: Formatter.getDate1(oContext.Edd),
					Weight : oContext.Weight,
					WeightUnit: oContext.WeightUnit,
					Volume : oContext.Volume,
					VolumeUnit : oContext.VolumeUnit,
					NumPackages : parseInt(oContext.NumPackages),
					PackageUnit : oContext.PackageUnit,
					ShippingType : oContext.ShippingType,
					ShippingDesc : oContext.ShippingDesc,
					Site : oContext.Site,
					Site1 : oContext.Site1,
					DropSeq : oContext.DropSeq,
					LoadSeq : oContext.LoadSeq,
					ShipToPartyId : oContext.ShipToPartyId,
					ShipToPartyName : oContext.ShipToPartyName,
					Destination : oContext.Destination,
					SystemId : oContext.SystemId,
					Type : oContext.Type,
					DeliveryType : oContext.DeliveryType
				};
				aHeadNav.push(this.fnPopupData(oContext));
				aItemNav.push(oItemNav);
			}
			var data  = {
					Dummy : "",					
					ADDELTRDTHDRNAV : aHeadNav,
					ADDELTRDTITMNAV : aItemNav
			};
			var path = "AddDeliverySet";			
			Transportation.that.postData(path, data, [ "/001" ], "S2", "AddDelivery");
			this.navBack();
		},
		navBack : function(){
			this.getRouter().navTo("S1");
		},
		getRouter : function(){
			return UIComponent.getRouterFor(this);
		},
		vHRLocs : function(oEvent){
			var path = "/SiteF4Set?$filter=Site eq '" + this.inpSite.getValue().toUpperCase() + "'";
			if(!this.dlgSites){
				this.dlgSites = sap.ui.xmlfragment("Transportation.fragment.Sites", this);				
			};
			this.dlgSites.bindAggregation("items", path, new StandardListItem({
				title : "{FirstName}",
				description : "{LastName}",
				type : "Active",
				info : "{Site}"
			}));
			this.dlgSites.open();
		},
		sSite : function(oEvent){
			var searchVal = oEvent.getParameter("value").toLowerCase(),
			items = this.dlgSites.getItems(),
			itemsLen = items.length;
			for(var i = 0; i < itemsLen; i++){
				var title = items[i].getTitle().toLowerCase(),
				desc = items[i].getDescription().toLowerCase(),
				info = items[i].getInfo().toLowerCase();
				items[i].setVisible((title.indexOf(searchVal) > -1 || desc.indexOf(searchVal) > -1 || info.indexOf(searchVal) > -1));
			}
		},
		cSite : function(oEvent){			
			this.inpSite.setValue(site);
			var site = oEvent.getParameter("selectedItem").getBindingContext().getObject().Site,
			//selInfItems = this.tblSealInfo.getItems(),
			selInfItemsLen = selInfItems.length;
			selInfItems[selInfItemsLen - 1].getBindingContext().getObject().LocationCode = site;
			selInfItems[selInfItemsLen - 1].getCells()[0].setText(site);
		},



		//Define Value Help Function for SLloc.
		handleValueHelpVehicle : function() {
			if(navigator.onLine){
				this._valueHelpDialog2 = new sap.m.SelectDialog({
					title : "Select Vehicle Type",
					noDataText : "No Entries Found",
					items : {
						path : "/VehicleTypeSet",
						template : new sap.m.StandardListItem({
							title : "{VehicleTypeDesc}",
							description : "{VehicleId}",
						})
					},
					liveChange : [ this._handleValueHelp2Search, this ],
					confirm : [ this._handleValueHelp2Close, this ],
					cancel : [ this._handleValueHelp2Close, this ]
				});
				this._valueHelpDialog2.setModel(this.oModel);
				this._valueHelpDialog2.open();
			}
			else{
				sap.m.MessageToast.show("You are in offline mode");
			}
		},
		_handleValueHelp2Close : function(evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var i1 = this.getView().byId("vehicletypeId");
				i1.setValue(oSelectedItem.getDescription());
				this.vehicleId = oSelectedItem.getDescription();
			}
		},
		_handleValueHelp2Search : function(evt) {
			var sValue = evt.getParameter("value").toLowerCase();
			var keys = evt.getSource().getBinding("items").aKeys;
			var smodel =  evt.getSource().getModel();
			for (var i = 0; i < this._valueHelpDialog2.getItems().length; i++){
				var val = smodel.getProperty("/" + keys[i]).VehicleTypeDesc.toLowerCase();
				var val1 = smodel.getProperty("/" + keys[i]).VehicleId.toLowerCase();
				if (val.indexOf(sValue) > -1 || val1.indexOf(sValue) > -1){
					this._valueHelpDialog2.getItems()[i].setVisible(true);
				} else {
					this._valueHelpDialog2.getItems()[i].setVisible(false);
				}
			}
		},


		pCreationTripSubmit:function(evt){
			var that=this;
			var a=that.vrndata;
			var b=that.shipmentDeliveryData[0];
			var oTable = that.getView().byId("tblTripDetails");
			var c=oTable.getModel().getData()[0];
			var data={};
			var table_data=[],table_data2=[],table_data3=[];
			//var selItems;
			//pass value
			data.ShipmentNum=b.ShipmntNum;
			data.ShipmentType=c.ShipmentType;
			//data.TransPlant=a.TransPlant; check once for manoj 25 March 2019 WHy used
			//TransId
			data.ShippingType=b.ShippingType;
			data.ShippingCond="";
			data.ShipmentRoute=that.byId("shpmtroutId").getValue();
			data.Distance=that.byId("distanceId").getValue();
			data.DistanceUnit="Km";
			//data.ContainerId=a.Vehiclenum;
			data.ContainerId=(a) ? a.Vehiclenum : "";
			//pass blank
			data.ExternalId1="";
			data.ExternalId2="";
			data.Description="";
			//pass X
			data.StatusPlan="X";
			data.StatusCheckIn="X";
			data.StatusLoadStart="X";
			data.StatusLoadEnd="X";
			data.StatusComplInd="X";
			data.StatusShpmntStart="X";
			//pass blank
			data.StatusShpmntEnd="";
			//pass value
			data.ServiceAgentId=c.ServiceAgent;

			//pass null
			data.Suppl1="";
			//pass value
			data.VechileType=that.vehicleId;
			data.VrnDate=that.VrnDate;
			//manual entry and waiting for rfc
			data.TruckLoad="";
			//pass blank
			data.ShipmentBlock="";
			data.Text1="";
			data.Text2= (a) ? "OBDVRN "+a.VRNNum : "";
			//data.Text2="OBDVRN "+a.VRNNum;
			//pass value
			data.TruckNum=(a) ? a.Vehiclenum : "";
			data.TransTruckNum="";
			var ArrBy = that.shipmentDeliveryData[0].ArrangedBy;
			if(that.ShippingType !=="HD" && !that.vehicleId){
				sap.m.MessageToast.show("Enter Vehicle Type");
				return;
			}
			else if(ArrBy != "N" && !that.TransId && that.ShippingType !=="HD"){
				sap.m.MessageToast.show("Enter Transporter Id");
				return;
			}
			data.TransId=that.TransId;
			if((that.ShippingType == "RD" && ArrBy == "F" ) || that.ShippingType == "HD"){
				//if(that.ShippingType==="RD"||that.ShippingType==="HD"){
				data.LRNum="";
				data.LRDate=null;
			}else{
				data.LRNum=oTable.getItems()[0].getCells()[3].getValue();//pass first data
				data.LRDate=Formatter.getDate1(new Date(oTable.getItems()[0].getCells()[4].getValue()));//pass first data
			}
			var TableData = oTable.getModel().getData(), arrWt = 0;
			var Wt;
			for(var i = 0; i< TableData.length; i++){
				Wt = (TableData[i].NumPackages) ? parseInt(TableData[i].NumPackages) : 0;
				arrWt = arrWt+Wt;
			}
			data.LRQuantity=arrWt.toString();
			//data.LRQuantity=oTable.getItems()[0].getCells()[5].getValue();//pass first data
			data.LRUnit=oTable.getItems()[0].getCells()[6].getValue();//changed to get Uom rgvd_richa 
			//data.LRUnit="";//pass blank
			data.FleetType="";//pass blank
			//data.ShipmentWeight=that.byId("shipmentweigthId").getValue();
			//data.ShipmentVolume=that.byId("shipmentVolumeId").getValue();
			//rgvd_richa added Volumne and Weight from table for shipment
			var shipDeliveryData =  this.tblTripDetails.getModel().getData(), arrWt = 0, arrVol = 0;
			var Wt, vol;
			for(var i = 0; i< shipDeliveryData.length; i++){
				Wt = (shipDeliveryData[i].DeliveryWeight) ? parseInt(shipDeliveryData[i].DeliveryWeight) : 0;
				arrWt = arrWt+Wt;
				vol = (shipDeliveryData[i].DeliveryVolume) ? parseInt(shipDeliveryData[i].DeliveryVolume) : 0;
				arrVol = arrVol+vol;
			}
			data.ShipmentWeight=arrWt.toString();
			data.ShipmentWeightUnit="KG";
			data.ShipmentVolume=arrVol.toString();
			data.ShipmentVolumeUnit="KG";
			//rgvd_richa added Volumne and Weight from table for shipment
			data.ExciseInvNum="";//blank
			for(var i=0;i<that.shipmentDeliveryData.length;i++){
				var oData=that.shipmentDeliveryData[i];
				var tabdata1 ={
						Site:oData.Site,
						SLoc:oData.SLoc,
						DeliveryNum:oData.DeliveryNum,
						ItemNum:oData.ItemNum,
						OrdQty:oData.OrdQty,
						UoM:oData.UoM,
						ArticleNum:oData.ArticleNum,
						ArticleDesc:oData.ArticleDesc,
						DeliveryInd:oData.DeliveryInd,
						SalesDocNum:oData.SalesDocNum,
						BillingDate:oData.BillingDate,
						CustomerNum:oData.CustomerNum,
						CustName:oData.CustName,
						VendorNum:oData.VendorNum,
						VendorName:oData.VendorName,
						Country:oData.Country,
						ShippingType:oData.ShippingType,
						SalesRefDocNum:oData.SalesRefDocNum,
						DeliveryDate:oData.DeliveryDate,
						ShipmntNum:oData.ShipmntNum,
						Server:oData.Server,
						Route:oData.Route,
						TransptZone:oData.TransptZone,
						Distance:oData.Distance,
						IncoTerms:oData.IncoTerms,
						TransZonefC:oData.TransZonefC,
						TransZonedC:oData.TransZonedC,
						RouteC:oData.RouteC,
						ShpmntStart:oData.ShpmntStart,
						CurrentDate:oData.CurrentDate,
						Plant:oData.Plant,
						VRNNum:a.VRNNum,//update the value
						StatusInd:oData.StatusInd,
						//added on 25 March 2019 rgvd_richa
						InvoiceAmount: oData.InvoiceAmount,
						InvoiceDate:Formatter.getDate1(oData.InvoiceDate),
						InvoiceType: oData.InvoiceType,
						ArrangedBy : ArrBy
				};
				var tabdata2 ={
						DeliveryNum:"",
						DeliveryInd:""
				};
				table_data.push(tabdata1);
				table_data2.push(tabdata2);
			}
			for(var i=0;i<oTable.getModel().getData().length;i++){
				var tabdata3 ={
						ShipmentNum:oTable.getModel().getData()[i].ShipmentNum,
						DeliveryNum:oTable.getModel().getData()[i].DeliveryNum,
						ContainerWeight:oTable.getItems()[i].getCells()[7].getValue(),
						ContainerWeightUnit:"KG", //on 25 march 2019
						CargoWeight:"0.0",
						CargoWeightUnit:"",
						StartSealNum:"",
						DestSealNum:"",
						Server:oTable.getModel().getData()[i].Server,
						//added on 25 March 2019
						LRNum:oTable.getModel().getData()[i].LRNum,
						LRDate:Formatter.getDate1(oTable.getModel().getData()[i].LRDate),
						LRQuantity:oTable.getModel().getData()[i].NumPackages,
						//LRUnit:oTable.getModel().getData()[i].UoMDesc
						LRUnit:oTable.getItems()[i].getCells()[6].getValue()
				};
				table_data3.push(tabdata3);
			}
			data.TRSHPCHNGHDRLRDETNAV=table_data3;
			data.TRSHPCHNGHDRLSTNAV=table_data;
			data.TRSHPCHNGHDRITMNAV=table_data2;
			Formatter.showLoader();
			that.oModel.create("/TRShipChangeHdrSet", data, {async : true,
				success :function(value, oResponse) {
					Formatter.hideLoader();
					//	this.messageVal=value;
					var msgCode = [{
						code : "/000",
						gaParams : [ {
							param3 : "Posted",
							param4 : "HeaderSet",
							param5: "",
							path : "PhysicalInventory/Detail/Submit"
						} ]
					} ];
					sap.custom.MessageHandling.handleRequestSuccess(oResponse, msgCode, $.proxy(function(msg){that.handlePostReturn();}),that);
				},
				error:function(oError) {
					Formatter.hideLoader();
					var msgCode = [ {
						code : "",
						gaParams : [ {
							param3 : "Posted with Error",
							param4 : "HeaderSet",
							param5: "",
							path : "PhysicalInventory/Detail/Submit"
						} ]
					} ];
					sap.custom.MessageHandling.handleRequestFailure(oError,msgCode,false);
				}});
		},
		handleReset:function(){
			/*this.byId("shipmentweigthId").setValue("");
			this.byId("shipmentVolumeId").setValue("");
			 */this.byId("vehicletypeId").setValue("");
		},

		handlePostReturn:function(){
			this.handleBack();
			Transportation.that.getOwnerComponent().getEventBus().publish("Transportation", "TransportRefresh");
		},

		handleBack:function(){
			this.handleReset();
			Transportation.that.getRouter().navTo("S1");	
		},
		onExit : function(){
			if(this.Route2Operator){
				this.Route2Operator.destroy();				
			}
		}


	});
});