jQuery.sap.require("sap.custom.MessageHandling");
jQuery.sap.require("sap.m.MessageBox");
sap.ui.define([ 'sap/ui/core/mvc/Controller', 'sap/ui/core/UIComponent', 'sap/ui/model/json/JSONModel',
                'sap/custom/MessageHandling', 'sap/m/MessageToast', 'sap/m/MessageBox', 'sap/m/GroupHeaderListItem',
                'sap/m/ColumnListItem', 'sap/m/Text', 'sap/m/Link', 'sap/ui/model/Sorter', 'sap/m/Button',
                'sap/m/StandardListItem', 'Transportation/util/Formatter', 'sap/m/Column', 'sap/ui/core/Icon',
                'sap/m/Label', 'sap/m/DisplayListItem', 'sap/m/ResponsivePopover', 'sap/m/List', 'sap/m/Input',
                'sap/m/FlexBox', 'Transportation/controller/Filter', 'Transportation/controller/PrintCN',
                'sap/m/ObjectStatus', 'sap/m/Table', 'sap/m/IconTabFilter', 'sap/m/ScrollContainer',
                'sap/m/ActionSheet', 'sap/m/ObjectListItem', 'sap/m/ObjectAttribute', 'sap/m/CheckBox','sap/m/Link'],
                function(Controller, UIComponent, JSONModel, 
                		MessageHandling, MessageToast, MessageBox, GroupHeaderListItem,
                		ColumnListItem, Text, Link, Sorter, Button,
                		StandardListItem, Formatter, Column, Icon, 
                		Label, DisplayListItem, ResponsivePopover, List, Input,
                		FlexBox, Filter, PrintCN, 
                		ObjectStatus, Table, IconTabFilter, ScrollContainer,
                		ActionSheet, ObjectListItem, ObjectAttribute, CheckBox) {
	"use strict";
	return Controller.extend("Transportation.controller.S3", {
		onInit : function() {
			Transportation.that = this;
			this.oCore = sap.ui.getCore();
			this.pgExe = this.byId("S3pgExe");
			this.iTBDelvy = this.byId("S3iTBDelvy");			
			//	this.btnAddToTrip = this.byId("S3btnAddToTrip");
			this.btnCreateTrip = this.byId("S3btnCreateTrip");
			this.btnVRNChange = this.byId("S3btnVRNChange");
			this.btnAddVRN = this.byId("S3btnAddVRN");
			this.mPError = this.byId("S3mPError");
			this.btnFilter = this.byId("S3btnFilter");
			var colsPath = ((Formatter.getProxy() === "") ? "/sap/bc/ui5_ui5/sap/ZJIO_P91_TRPSHP/" : "") + "model/Columns3.json";
			this.oColumnsModel = new JSONModel();
			this.oColumnsModel.loadData(colsPath, null, false);
			var colsPath2 = ((Formatter.getProxy() === "") ? "/sap/bc/ui5_ui5/sap/ZJIO_P91_TRPSHP/" : "") + "model/Columns2.json";
			this.oColumnsModel2 = new JSONModel();
			this.oColumnsModel2.loadData(colsPath2, null, false);
			this.oModel = this.getOwnerComponent().getModel();
			this.oi18nModel = this.getOwnerComponent().getModel("i18n");
			this.oCore.setModel(this.oModel);
			this.oCore.setModel(this.oi18nModel, "i18n");
			this.getRouter().attachRoutePatternMatched(this.onRouteMatched, this);			
			this.initTableModel();
			this.oModel.attachRequestFailed(function(oError){
				var error = JSON.parse(oError.getParameter("responseText")).error.message.value;
				MessageToast.show(error);
			});
			if (sap.ui.Device.system.phone){
				this.byId("S3sFLocSearch").setVisible(false);
				this.byId("S3btnSearch").setVisible(true);
			}
			this.iTBDelvy.addEventDelegate({
				onAfterRendering : function(){
					Transportation.that.setScrollHeight();
					Transportation.that.showMsgPage("", "", false);
					var bFilterDateSelected = (Transportation.that.dRSDeliveryDate !== undefined && Transportation.that.dRSDeliveryDate.getDateValue() !== null && Transportation.that.dRSDeliveryDate.getSecondDateValue() !== null);
					Transportation.that.addRemoveFilterClass(3, bFilterDateSelected);
					if(typeof TransportScheduling !== "undefined" && TransportScheduling.that && TransportScheduling.that.bSetGroupedTabSelected){
						//	TransportScheduling.that.bSetGroupedTabSelected = undefined;
						Transportation.that.iTBDelvy.setSelectedKey("grouped");
					}
				}
			});
			this.getOwnerComponent().getEventBus().subscribe("Transportation", "TransportRefresh", this.initTableModel, this);
		},
		onAfterRendering : function(){
			var that = this;
			$(window).resize(function(){
				that.setScrollHeight();
			});
		},
		onRouteMatched : function(oEvent){
         if(oEvent.getParameter("name")==="S3"){
        	 this.byId("secondarySgmtId").setSelectedKey("S");
			}
		},
		handlePrimaryAgent:function(){
			var that=this;
			sap.m.MessageBox.show("Do you want to move primary process?",{
				title : "Confirmation",
				icon:sap.m.MessageBox.Icon.QUESTION,
				actions : [ 'Ok','Cancel' ],
				//actions : ['Inbound','Mixed'],
				onClose : function(oAction) {
					if(oAction=="Ok"){
						that.getRouter().navTo("S1");			
					}}
			});
		},
		setScrollHeight : function(){
			var documentHeight = $(document).height();
			var footer = this.pgExe.getAggregation("footer");
			var footerHeight = (footer !== null) ? ($("#" + footer.sId).height()) : 39;//Get footer height			
			var height = documentHeight - footerHeight - ((Formatter.getProxy() === "") ? 205 : 160);
			var iTBItems = this.iTBDelvy.getItems();
			for(var i = 0; i < iTBItems.length; i++){
				var iTFContent = iTBItems[i].getContent();
				for(var j = 0; j < iTFContent.length; j++){
					if(iTFContent[j] instanceof ScrollContainer){
						iTFContent[j].setHeight(height + "px");
					}
				}
			}
		},
		initTableModel : function(){
			var that = this;			
			var sPath = "TransportListSet?$filter=IMode eq '" + Formatter.getMode() + "'@DateFilter";
			var fromDate, toDate;
			if(this.dRSDeliveryDate !== undefined && this.dRSDeliveryDate.getDateValue() !== null && this.dRSDeliveryDate.getSecondDateValue() !== null){
				fromDate = Formatter.getDate1(this.dRSDeliveryDate.getDateValue());
				toDate = Formatter.getDate1(this.dRSDeliveryDate.getSecondDateValue());
				this.addRemoveFilterClass(3, true);
				sPath = sPath.replace("@DateFilter", " and FromDate eq datetime'" + fromDate + "' and ToDate eq datetime'" + toDate + "'");
			}
			else{
				this.addRemoveFilterClass(3, false);
				sPath = sPath.replace("@DateFilter", "");				
			}
			Formatter.showLoader();
			this.oModel.read(sPath, {
				async : true,
				success : function(oData){
					that.MainData=oData.results;
					var a = [], // uniques get placed into here
					b = 0; // counter to test if value is already in array 'a'
					for (var i = 0; i < oData.results.length; i++ ) {
						var current =  oData.results[i]; // get a value from the original array
						for (var j = 0; j < a.length; j++ ) { // loop and check if value is in new array 
							if ( current.DeliveryNum != a[j].DeliveryNum ) {
								b++; // if its not in the new array increase counter
							}
						}
						if ( b == a.length ) { // if the counter increased on all values 
							// then its not in the new array yet
							a.push( current ); // put it in
						}
						b = 0; // reset counter
					}
					oData.results=a;
					if(oData.results.length > 0){
						that.handleMainData(oData);
						that.oData=oData;
					}
					else{
						Formatter.hideLoader();
						that.bindITB([]);
						that.showMsgPage(that.oi18nModel.getProperty("msgNoDataFound"), "", true);
					}
				},
				error : function(oError){
					Formatter.hideLoader();
					var msg = "";
					try{
						msg = JSON.parse(oError.response.body).error.message.value;
					}
					catch(err){
						msg = oError.response.body;
					}				
					that.showMsgPage(msg, "", true);
				}
			});			
		},
		handleMainData:function(oData){
			var that=this;
			var aOpenDelvy, aGrouped,aCN;
			aOpenDelvy = [];
			aGrouped = [];
			that.shipmentData=[];
			//aTripWOVRN = [];
			aCN = [];
			that.MainData=oData.results;
			for(var i = 0; i < oData.results.length; i++){
				var dataItem = oData.results[i];

				//var RefrenceNum=dataItem.SalesRefDocNum;
				var ShipmntNum =dataItem.ShipmntNum;
				var ShpmntStart=dataItem.ShpmntStart;
				var shipType = dataItem.ShippingType;
				var ArrangedBy = dataItem.ArrangedBy;
				//	var shipDesc = dataItem.ShippingDesc;
				dataItem.GroupHeader = ShipmntNum + "/"  + ShpmntStart + "/" + ((ShipmntNum !== ""  || ShpmntStart !== "") ? shipType : "") + "/"  + ArrangedBy ;
				if(ShipmntNum === "" && ShpmntStart === ""){
					aOpenDelvy.push(dataItem);
				}
				else if(ShipmntNum !== ""  && ShpmntStart === ""){
					aGrouped.push(dataItem);
					that.shipmentData.push(dataItem);
				}
				else if(ShipmntNum !== ""  && ShpmntStart !== ""){
					aCN.push(dataItem);
				}
			}
			var oITBData;
			oITBData = [];
			if(aOpenDelvy.length > 0){
				var oITF = {
						key : "open",
						header : that.oi18nModel.getProperty("iTF1Text"),
						mode : "MultiSelect",
						count : that.oi18nModel.getProperty("delivery") + aOpenDelvy.length,
						icon : "email-read",
						tabColumns : that.oColumnsModel.oData,
						tabItems : aOpenDelvy 
				};
				oITBData.push(oITF);
			}
			if(aGrouped.length > 0){
				var groups = aGrouped.map(function(obj){
					return obj.ShipmntNum;
				});
				var distinctGroups = groups.filter(function(v, i){
					return groups.indexOf(v) == i && v !== "";
				});							
				var oITF = {
						key : "grouped",
						header : that.oi18nModel.getProperty("iTF2Text"),
						mode : "None",
						count : that.oi18nModel.getProperty("ShipmntNum") + distinctGroups.length + ", " + that.oi18nModel.getProperty("delivery") + aGrouped.length,
						icon : "group-2",
						tabColumns : that.oColumnsModel.oData,
						tabItems : aGrouped 
				};
				oITBData.push(oITF);
			}
			if(aCN.length > 0){
				var groups = aCN.map(function(obj){
					return obj.ShipmntNum;
				});
				var distinctGroups = groups.filter(function(v, i){
					return groups.indexOf(v) == i && v !== "";
				});						
				var oITF = {
						key : "cn",
						header : that.oi18nModel.getProperty("iTF4Text"),
						mode : "None",
						//	count : that.oi18nModel.getProperty("ShpmntStart") + distinctVRNs.length + ", " + that.oi18nModel.getProperty("delivery") + aCN.length,
						count : that.oi18nModel.getProperty("ShipmntNum") + distinctGroups.length + ", " + that.oi18nModel.getProperty("delivery") + aCN.length,
						icon : "notes",
						tabColumns : that.oColumnsModel2.oData,
						tabItems : aCN 
				};
				oITBData.push(oITF);
			}
			that.iTBDelvy.setVisible(true);
			that.bindITB(oITBData);						
			Transportation.that.fnFilterCallBack(true);//true for not allowing local search for ship type when only date changed
		},
		bindITB : function(oITBData){
			var oTempModel = new JSONModel(oITBData);
			this.iTBDelvy.setModel(oTempModel);
			this.iTBDelvy.bindAggregation("items", {
				path : "/",
				template : new IconTabFilter({
					design : "Horizontal",
					key : "{key}",
					icon : "sap-icon://{icon}",
					count : "{header}",
					text : "{count}",
					content : this.getITFContent()
				})	
			});
		},
		showMsgPage : function(text, desc, bVisible){
			this.mPError.setText(text);
			this.mPError.setDescription(desc);
			this.mPError.setVisible(bVisible);
			if(this.iTBDelvy.getItems().length > 0){
				this.setButtonsVisibility(this.iTBDelvy.getSelectedKey());
			}
			else{
				this.btnCreateTrip.setVisible(!bVisible);
				this.iTBDelvy.setVisible(!bVisible);
			}			
		},
		getITFContent : function(){
			var tblDelvyH = new Table({
				mode : "{mode}",
				selectionChange : this.sTblGroupH,
				columns : {
					path : "tabColumns",
					template : new Column({
						hAlign : "{hAlign}",
						vAlign : "{vAlign}",
						width : "{width}",
						demandPopin : "{demandPopin}",
						minScreenWidth : "{minScreenWidth}",
						/*header : new Label({
							text : "{ColumnName}",
							design : "Bold",
						})*/
						header : new Link({
							text : "{ColumnName}",
							design : "Bold",
							//press:"handleColumnPress"
							press : [ Transportation.that.handleColumnPress, Transportation.that]
						})
					})
				},				
				items : [
				         new ColumnListItem({
				        	 visible : false				         		
				         })
				         ]
			});			
			var tblDelvy = new Table({
				mode : "{mode}",
				selectionChange : this.sTblGroup,
				growing : true,
				growingThreshold : 10000,
				growingScrollToLoad : false,
				columns : {
					path : "tabColumns",
					template : new Column({
						hAlign : "{hAlign}",
						vAlign : "{vAlign}",
						width : "{width}",
						demandPopin : "{demandPopin}",
						minScreenWidth : "{minScreenWidth}"
					})
				},
				items : {
					path : "tabItems",
					sorter : [ new Sorter({
						path : "GroupHeader",
						descending : false,
						group : true
					}), new Sorter({
						path : "CustName",
						descending : true,
						group : false
					}), new Sorter({
						path : "CustomerNum",
						descending : false,
						group : false
					}) ],
					groupHeaderFactory : function(oGroup){
						var group = oGroup.key.split('/');
						var ShipmntNum = group[0];
						var ShpmntStart  = group[1];
						var ShippingType  = group[2];
						var ArrangedBy = group[3];
						var dispShipmntNum = (ShipmntNum === "") ? "" : Transportation.that.oi18nModel.getProperty("ShipmntNum") + parseInt(ShipmntNum).toString();						
						//		var dispShpmntStart = (ShpmntStart === "") ? "" : Transportation.that.oi18nModel.getProperty("ShpmntStart") + parseInt(ShpmntStart).toString();
						var tabGroupHeadItem = new ColumnListItem({
							visible : (oGroup.key !== "///"),
							cells:[							       
							       new FlexBox({
							    	   alignItems : "Center",
							    	   justifyContent : "Start",
							    	   items : [													
							    	            new Icon({
							    	            	src : "sap-icon://navigation-right-arrow",
							    	            	press : Transportation.that.pGroupHeader,
							    	            	color : "#666666"	
							    	            }).addStyleClass("sapUiTinyMarginEnd"),
							    	            new Icon({
							    	            	src : Formatter.getShipTypeIcon(ShippingType),
							    	            	color : Formatter.getShipTypeIconColor(ShippingType),
							    	            	//tooltip : shipDesc
							    	            }).addStyleClass("sapUiTinyMarginEnd"),
							    	            new Label({
							    	            	text : (dispShipmntNum).trim(),
							    	            	design : "Bold"
							    	            }).addStyleClass("sapUiSmallMarginEnd"),
							    	            /*new Label({
							    	            	text : dispShpmntStart.trim(),
							    	            	design : "Bold"
							    	            })*/
							    	            ]
							       }),
							       new Text(),
							       new Text(),				       	
							       new Text(),
							       new Text(),
							       new Text(),
							       new Text(),
							       new Button({
							    	   type: (ShipmntNum !== "") ? "Accept" : (ShpmntStart !== "") ? "Accept" : "Default",
							    			   icon: "sap-icon://" + ((ShipmntNum !== ""&&ShpmntStart === "") ? "suitcase" : (ShipmntNum !== ""&&ShpmntStart !== "") ? "notes" : "Default"),
							    			   tooltip: (ShipmntNum !== "") ? Transportation.that.oi18nModel.getProperty("createTripTT") : (ShpmntStart !== "") ? Transportation.that.oi18nModel.getProperty("createCNTT") : Transportation.that.oi18nModel.getProperty("addToTripTT"),
							    					   visible: (ShipmntNum !== ""&& ShpmntStart === "" ) ,
							    					   press : [(ShipmntNum !== "" && ShpmntStart === "") ? Transportation.that.cnVehicles : (ShpmntStart !== "") ? Transportation.that.pCreateCN : Transportation.that.pAddToTrip, Transportation.that]
							       }),							       	
							       new Icon({
							    	   src: "sap-icon://" + ((ShipmntNum !== ""&&ShpmntStart === "") ? "delete" : (ShipmntNum !== ""&&ShpmntStart !== "") ? "print" : "Default"),
							    	   color: "sap-icon://" + ((ShipmntNum !== ""&&ShpmntStart === "") ? "red" : (ShipmntNum !== ""&&ShpmntStart !== "") ? "blue" : "Default"),
							    	   //tooltip : Transportation.that.oi18nModel.getProperty("delTripTT"),
							    	   visible:((ShipmntNum!==""&& ShpmntStart==="" )||( ShpmntStart!==""&&Formatter.getValidCNShipTypes().indexOf(ShippingType) > -1&&Formatter.getValidCNShipTypes2().indexOf(ArrangedBy) > -1)),
							    	   press : [(ShipmntNum !== "" && ShpmntStart === "") ? Transportation.that.ShipmentDelete : (ShpmntStart !== "") ? Transportation.that.ShipmentPrint :Transportation.that],
//							    	   press : [Transportation.that.ShipmentDelete, Transportation.that]
							       })
							       ]
						}).addStyleClass("GroupHeader");
						tabGroupHeadItem.addEventDelegate({
							onAfterRendering : function(oEvent){
								var currItem = oEvent.srcControl;
								var oContext = currItem.getBindingContext().getObject();
								var table = currItem.getParent();
								var items = table.getItems();
								var currItemIndex = table.indexOfItem(currItem);
								if(oContext.GroupHeader === undefined&&items[currItemIndex + 1]!==undefined){
									oContext = items[currItemIndex + 1].getBindingContext().getObject();
									//	if((oContext.ShipmntNum !== "" || (oContext.TripNum !== "" && oContext.VRNNum  === "")) && Formatter.getValidCreateTripShipTypes().indexOf(oContext.ShippingType) === -1){
									if((oContext.ShipmntNum !=="" || oContext.ShpmntStart!=="")){
										currItem.$().find(".sapMCb").removeClass("sapMPointer");
										currItem.$().find(".sapMCbBg ").css("display", "none");
									}
								}								
							}
						});
						return tabGroupHeadItem;
					},
					factory : function(sId, oContext){
						var tabItem = new ColumnListItem({
							visible : "{path: 'GroupHeader', formatter: 'Transportation.util.Formatter.getColumnVisible'}",//Hide Group's Child Items Initially
							cells:[								
							       new FlexBox({
							    	   alignItems : "Center",
							    	   justifyContent : "Start",
							    	   items : [												
							    	            new Text({
							    	            	visible :"{path: 'GroupHeader', formatter: 'Transportation.util.Formatter.getShipTypeVisibility'}"
							    	            }).addStyleClass("sapUiLargeMarginEnd"),
							    	            new Icon({
							    	            	src : "{path:'ShippingType', formatter:'Transportation.util.Formatter.getShipTypeIcon'}",
							    	            	tooltip : "{ShippingDesc}",
							    	            	color : "{path:'ShippingType', formatter:'Transportation.util.Formatter.getShipTypeIconColor'}",
							    	            	visible :"{path: 'GroupHeader', formatter: 'Transportation.util.Formatter.getColumnVisible'}"
							    	            }).addStyleClass("sapUiSmallMarginEnd"),
							    	            new Icon({
							    	            	src : "{path:'Status', formatter:'Transportation.util.Formatter.getStatusIcon'}",
							    	            	color : "{path:'Status', formatter:'Transportation.util.Formatter.getStatusColor'}",							
							    	            	tooltip :"{path:'Status', formatter:'Transportation.util.Formatter.getStatusTooltip'}",
							    	            	size : "0.9rem",
							    	            	press : Transportation.that.pRemarks
							    	            }).addStyleClass("sapUiTinyMarginEnd"),
							    	            new ObjectStatus({
							    	            	text : "{CustName} ({CustomerNum})",
							    	            	state : "{path:'Status', formatter:'Transportation.util.Formatter.getObjectStatus'}"
							    	            })
							    	            ]
							       }),					
							       new ObjectStatus({
							    	   text : "{Server}",
							    	   state : "{path:'Status', formatter:'Transportation.util.Formatter.getObjectStatus'}"
							       }),
							       new ObjectStatus({
							    	   text : "{SLoc}",
							    	   state : "{path:'Status', formatter:'Transportation.util.Formatter.getObjectStatus'}"
							       }),
							       /*new Input({
							    	   tooltip : "{Distance} Km",
							    	   valueHelpOnly:true,
							    	   showSuggestion:true,
							    	   showValueHelp:true,
							    	   placeholder:"Select Route",
							    	   valueHelpRequest:[Transportation.that.handleRouteSelection, Transportation.that] ,
							    	   value : "{Route}",
							    	   textAlign :"Right",
							    	   editable:"{parts:[{path:'ShipmntNum'},{path:'ShpmntStart'}],formatter : 'Transportation.util.Formatter.RouteEditable'}",
							    	   state : "{path:'Status', formatter:'Transportation.util.Formatter.getObjectStatus'}"
							       }),*/
							       new sap.m.Text({
							    	   text : "{Route}",  
							    	   tooltip : "{Distance} Km",
							       }),
							       /*  new ObjectStatus({
							    	   text : "{Route}",
							    	   tooltip : "{Distance} Km",
							    	   state : "{path:'Status', formatter:'Transportation.util.Formatter.getObjectStatus'}"
							       }),*/
							       new ObjectStatus({
							    	   text : "{DeliveryNum}",
							    	   state : "{path:'Status', formatter:'Transportation.util.Formatter.getObjectStatus'}"
							       }),
							       new ObjectStatus({
							    	   text:"{path: 'CreatedOn', formatter: 'Transportation.util.Formatter.getDateFormatted'}",
							    	   state : "{path:'Status', formatter:'Transportation.util.Formatter.getObjectStatus'}"
							       }),
							       new ObjectStatus({
							    	   text : "{SalesDocNum}",
							    	   state : "{path:'Status', formatter:'Transportation.util.Formatter.getObjectStatus'}"
							       }),
							       new ObjectStatus({
							    	   text : "{LRNum}",
							    	   visible : "{path:'ShpmntStart', formatter:'Transportation.util.Formatter.LRNOvisible'}",
							    	   state : "{path:'Status', formatter:'Transportation.util.Formatter.getObjectStatus'}"
							       }),
							       new Button({
							    	   type : "Accept",
							    	   icon : "sap-icon://suitcase",
							    	   tooltip : Transportation.that.oi18nModel.getProperty("createTripTT"),
							    	   //visible : "{parts : [{path:'ShipmntNum'}, {path:'ShpmntStart'}], formatter:'Transportation.util.Formatter.getCreateTripVisibility'}",
							    	   visible:false,
							    	   press : [Transportation.that.vrnCreateTrip, Transportation.that]
							       }),								
							       new Icon({
							    	   src : "sap-icon://sys-cancel",
							    	   color : "red",
							    	   tooltip : Transportation.that.oi18nModel.getProperty("remDelTT"),
							    	   // visible : "{path:'TripNum', formatter:'Transportation.util.Formatter.getTripAssigned'}",
							    	   visible:false,
							    	   press : [Transportation.that.pDelDelvy, Transportation.that]
							       })
							       ]
						});
						tabItem.addEventDelegate({
							onAfterRendering : function(oEvent){
								var currItem = oEvent.srcControl;
								var oContext = currItem.getBindingContext().getObject();
								if(oContext.Route === ""){
									currItem.$().find(".sapMCb").removeClass("sapMPointer");
									currItem.$().find(".sapMCbBg ").css("display", "none");
								}
							}
						});
						return tabItem;
					}					
				}
			});
			tblDelvy.addEventDelegate({
				onAfterRendering : function(){
					Formatter.hideLoader();
				}
			});
			var scrlContDelvy = new ScrollContainer({
				height : "100%",
				width : "100%",
				vertical : true,
				content : [ tblDelvy ]
			});
			return [ tblDelvyH, scrlContDelvy ];
		},
		handleRouteSelection:function(evt){
			this.RouteSrc=evt.getSource();
			this.RouteContxt=evt.oSource.oParent.getBindingContext();
			if(!this.RouteOperator2){
				this.RouteOperator2 = sap.ui.xmlfragment("Transportation.fragment2.Route21", this);
			}
			this.RouteOperator2.open();
		},

		//Define Value Help Function for SLloc.
		RouteSubmit : function(evt) {
			var routeValue=sap.ui.getCore().byId("S3routeselectionId").getValue().toUpperCase();
			if(routeValue.length===1||routeValue.length===0){
				sap.m.MessageToast.show("Enter minimum 2 letters");
				return;
			}
			sap.ui.getCore().byId("S3routeselectionId").setValue("");
			this.RouteOperator2.close();
			this._RouteDialog2 = new sap.m.SelectDialog({
				title : "Select Route",
				noDataText : "No Entries Found",
				growing:true,
				growingThreshold:3000,
				growingScrollToLoad:true,
				items : {
					path : "/RouteListSet?$filter=Route eq'"+routeValue+"'",
					template : new sap.m.StandardListItem({
						title : "{Route}",
						description : "{Description}",
						tooltip:"{Distance}",
					})
				},
				liveChange : [ this._Route2Search, this ],
				confirm : [ this._Route2Close, this ],
				cancel : [ this._Route2Close, this ],
			});
			this._RouteDialog2.setModel(this.oModel);
			this._RouteDialog2.open();
		},
		_Route2Close : function(evt) {
			var oTable = this.getTable("open");
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				this.RouteSelectionValue = oSelectedItem.getTitle();
				this.distance=oSelectedItem.getTooltip();
				this.RouteContxt.getModel().setProperty("Route",this.RouteSelectionValue, this.RouteContxt);
				this.RouteContxt.getModel().setProperty("Distance",this.distance, this.RouteContxt);
				oTable.getModel().updateBindings();
				this.RouteSrc.setValue(this.RouteSelectionValue);
			}
		},
		_Route2Search : function(evt) {
			var sValue = evt.getParameter("value").toLowerCase();
			var keys = evt.getSource().getBinding("items").aKeys;
			var smodel =  evt.getSource().getModel();
			for (var i = 0; i < this._RouteDialog2.getItems().length; i++){
				var val = smodel.getProperty("/" + keys[i]).Route.toLowerCase();
				var val1 = smodel.getProperty("/" + keys[i]).Description.toLowerCase();
				if (val.indexOf(sValue) > -1 || val1.indexOf(sValue) > -1){
					this._RouteDialog2.getItems()[i].setVisible(true);
				} else {
					this._RouteDialog2.getItems()[i].setVisible(false);
				}
			}
		},
		RouteCancel:function(){
			this.RouteOperator2.close();
			sap.ui.getCore().byId("S3routeselectionId").setValue("");
		},


		handleColumnPress:function(oEvent){
			if(!this.filterOperator){
				this.filterOperator = sap.ui.xmlfragment("Transportation.fragment2.FilterOperator2", this);
			}
			this.key=oEvent.getSource().getParent().getParent().getParent().getKey();
			this.filterOperator.open();
			this.property=oEvent.oSource.getText();
			sap.ui.getCore().byId("S3filterelementId").setValue("");
			sap.ui.getCore().byId("S3filterId").setTitle(this.property+" Filtering");
		},

		handlefilterSubmit:function(){
			var oTable = this.getTable(this.key);
			var that=this;
			var property=that.property;
			var oData=that.oData,context="",context2="",context3="",filters=[];
			var binding = oTable.getBinding("items");
			var filt = [];
			var filtData= "",filtData2= "";
			that.Data=[];
			var sQuery=sap.ui.getCore().byId("S3filterelementId").getValue();
			var a=sQuery.split(',');
			if(property==="System Id"){
				context="Server";context2="";
			}else if(property==="Location"){
				context="SLoc";context2="";
			}else if(property==="Route"){
				context="Route";context2="";
			}else if(property==="Delivery No."){
				context="DeliveryNum";context2="";
			}else if(property==="Delivery Created "){
				context="CreatedOn";context2="";
			}else if(property==="STN No."){
				context="SalesDocNum";context2="";
			}else if(property==="LR No./CN No."){
				context="LRNum";context2="";
			}else if(property==="Ship to Party"){
				context="CustName";context2="CustomerNum";
			}
			//if(context!==""&&context2===""){
			if(context!==""&&context2===""){
				for(var i=0;i<a.length;i++){
					filtData= new sap.ui.model.Filter(context, sap.ui.model.FilterOperator.Contains, a[i]);
					filt.push(filtData);
				}
			}else{
				for(var i=0;i<a.length;i++){
					filtData= new sap.ui.model.Filter(context, sap.ui.model.FilterOperator.Contains, a[i]);
					filt.push(filtData);
				}
				for(var i=0;i<a.length;i++){
					filtData2= new sap.ui.model.Filter(context2, sap.ui.model.FilterOperator.Contains, a[i]);
					filt.push(filtData2);
				}
			}

			this.filterOperator.close();
			binding.filter(filt);

			// oTable.getModel().updateBindings();
			/*var sField = "profam";
		     var sQuery = oEvent.getParameter("query");
		  var filters = new sap.ui.model.Filter(sField, sap.ui.model.FilterOperator.Contains, sQuery);
		var list = this.getView().byId("S3table");
		var binding = list.getBinding("items");
		binding.filter(filters);*/
			//that.handleMainData(that.Data);	
		},

		handlefilterClose:function(){
			this.filterOperator.close();
		},


		pGroupHeader : function(oEvent){
			var icon = oEvent.getSource();			
			var currItem = icon.getParent().getParent();
			var table = currItem.getParent();
			var items = table.getItems();
			var currItemIndex = table.indexOfItem(currItem);
			var colVisible;
			if(icon.getSrc().indexOf("right") > -1){
				icon.setSrc("sap-icon://navigation-down-arrow");
				colVisible = true;
			}
			else{
				icon.setSrc("sap-icon://navigation-right-arrow");
				colVisible = false;
			}
			for(var i = currItemIndex + 1; i < items.length && items[i].getBindingContext().getObject().GroupHeader !== undefined; i++){				
				items[i].setVisible(colVisible);
			}
		},		
		sDelvy : function(oEvent){
			var key = oEvent.getParameter("selectedKey");
			this.setButtonsVisibility(key);
		},
		setButtonsVisibility : function(key){
			//	this.btnAddToTrip.setVisible(key === "open");
			this.btnCreateTrip.setVisible(key === "open");
			//this.btnAddVRN.setVisible(key === "trip");			
		},
		pRemarks : function(oEvent){
			var icon = oEvent.getSource();
			var currItem = icon.getParent();
			var remarks = currItem.getBindingContext().getProperty("StatusDesc");			
			var rPRemarks = new ResponsivePopover({
				showHeader : false,
				placement : "Right",				
				content : [
				           new Text({
				        	   text : remarks
				           }).addStyleClass("sapUiSmallMarginBeginEnd sapUiSmallMarginTopBottom")
				           ]
			});
			rPRemarks.openBy(icon);
		},
		getTable : function(key){
			var table = "";
			var iTBItems = this.iTBDelvy.getItems();
			for(var i = 0; i < iTBItems.length; i++){
				if(iTBItems[i].getKey() === key){
					var content = iTBItems[i].getContent();
					for(var j = 0; j < content.length; j++){
						if(content[j] instanceof ScrollContainer){
							table = content[j].getContent()[0];						
						}
					}
				}				
			}
			return table;
		},
		pAddToTrip : function(oEvent){
			var table = this.getTable("open");
			if(table !== ""){				
				var selItems = table.getSelectedItems();
				var selItemsLen = selItems.length;				
				if(selItemsLen > 0){
					var shipType = "";
					var shipDesc = "";
					var shipToParty = "";
					var systemId = "";
					var bShipTypeSame = true;
					var bShipToPartySame = true;
					var bSystemIdSame = true;
					var aShipTypes = Formatter.getValidSameSTPShipTypes();
					for(var i = 0; i < selItemsLen; i++){
						var oContext = selItems[i].getBindingContext().getObject(); 
						if(oContext.GroupHeader !== undefined){
							if(shipType === ""){
								shipType = oContext.ShippingType;
								shipDesc = oContext.ShippingDesc;
							}
							else if(oContext.ShippingType !== shipType){
								bShipTypeSame = false;
							}							
							if(aShipTypes.indexOf(shipType) > -1){
								if(shipToParty === ""){
									shipToParty = oContext.ShipToPartyId;
								}
								else if(oContext.ShipToPartyId !== shipToParty){
									bShipToPartySame = false;
								}
								if(systemId === ""){
									systemId = oContext.SystemId;
								}
								else if(oContext.SystemId !== systemId){
									bSystemIdSame = false;
								}
							}							
						}
					}
					if(bShipTypeSame && bShipToPartySame && bSystemIdSame){
						if(!this.dlgTripsList2){
							this.dlgTripsList2 = sap.ui.xmlfragment("Transportation.fragment2.TripsList2", this);
						}
						var oModel = this.iTBDelvy.getModel();
						var aITBData;
						aITBData = [];
						for(var i = 0; i < oModel.oData.length; i++){
							if(oModel.oData[i].key === "trip" || oModel.oData[i].key === "cn"){
								aITBData.push(oModel.oData[i]);
							}
						}
						var colsPath = ((Formatter.getProxy() === "") ? "/sap/bc/ui5_ui5/sap/ZJIO_TRN_EXE/" : "") + "model/PopupColumns.json";
						var oColumnsModel = new JSONModel();
						oColumnsModel.loadData(colsPath, null, false);
						for(var i = 0; i < aITBData.length; i++){
							var aTripsData;
							aTripsData = [];
							for(var j = 0; j < aITBData[i].tabItems.length; j++){
								if(aITBData[i].tabItems[j].ShippingType === shipType){
									if(aShipTypes.indexOf(shipType) === -1 || (aShipTypes.indexOf(shipType) > -1 && 
											aITBData[i].tabItems[j].ShipToPartyId === shipToParty &&
											aITBData[i].tabItems[j].SystemId === systemId)){
										aTripsData.push(aITBData[i].tabItems[j]);
									}
								}
							}							
							var trips = aTripsData.map(function(obj){
								return obj.TripNum;
							});
							var distinctTrips = trips.filter(function(v, i){
								return trips.indexOf(v) == i  && v !== "";
							});
							aITBData[i].mode = "MultiSelect";
							aITBData[i].count = this.oi18nModel.getProperty("tripNo") + distinctTrips.length + ", " + this.oi18nModel.getProperty("delivery") + aTripsData.length;
							aITBData[i].listItems = aTripsData;
							aITBData[i].listColumns = oColumnsModel.oData;
						}
						this.oCore.byId("S3iconTripsShipType").setSrc(Formatter.getShipTypeIcon(shipType));
						this.oCore.byId("S3iconTripsShipType").setColor(Formatter.getShipTypeIconColor(shipType));
						this.oCore.byId("S3titTrips").setText(shipDesc + " Trips");
						var oTripsModel = new JSONModel(aITBData);
						this.oCore.byId("S3iTBTrips").setModel(oTripsModel);
						this.oCore.byId("S3iTBTrips").bindAggregation("items", {
							path : "/",
							template : new IconTabFilter({
								design : "Horizontal",
								key : "{key}",
								icon : "sap-icon://{icon}",
								count : "{header}",
								text : "{count}",
								content : [ this.getPopupITFContent() ]
							})
						});
						var iTBItems = this.oCore.byId("S3iTBTrips").getItems();
						for(var i = 0; i < iTBItems.length; i++){
							var iTFContent = iTBItems[i].getContent();
							for(var j = 0; j < iTFContent.length; j++){
								if(iTFContent[j] instanceof ScrollContainer){
									iTFContent[j].setHeight("330px");
								}
							}
						}
						this.dlgTripsList2.open();
					}
					else if(!bShipTypeSame){
						MessageToast.show(this.oi18nModel.getProperty("msgSameShipType"));
					}
					else if(!bShipToPartySame){
						MessageToast.show(this.oi18nModel.getProperty("msgSameSTP"));
					}
					else if(!bSystemIdSame){
						MessageToast.show(this.oi18nModel.getProperty("msgSameSysID"));
					}
				}
				else{
					MessageToast.show(this.oi18nModel.getProperty("msgAddToTrip"));
				}
			}
			else{
				MessageToast.show(this.oi18nModel.getProperty("msgNoItems"));
			}
		},
		getPopupITFContent : function(){},		
		pTripsListCancel : function(oEvent){
			var dialog = oEvent.getSource().getParent();
			dialog.close();
		},
		handleNavigation:function(oEvent){
			if(bSameTrip && tripNo !== ""){
				this.getRouter().navTo("S2", {
					tripNo : tripNo
				});
			}
		},

		ShipmentDelete:function(oEvent){
			var that=this;
			var oTable=oEvent.getSource().getParent().getParent();
			var index=oTable.indexOfItem(oEvent.getSource().getParent());
			this.EntireShipmentNo=oTable.getItems()[index+1].getBindingContext().getObject().ShipmntNum;
			//var aData=oEvent.getSource().getBindingContext().getObject();
			MessageBox.show("Are you want to delete the shipment",{
				title : "Confirmation",
				icon: MessageBox.Icon.QUESTION,
				actions : ['Yes', 'No'],
				onClose : function(oAction){
					if(oAction === "Yes"){
						var path="/ShipmentDeleteSet(ShipmentNum='"+that.EntireShipmentNo+"')"; 
						Transportation.that.oModel.remove(path, {async : true,
							success :function(value, oResponse) {
								//	this.messageVal=value;
								var msgCode = [{
									code : "/000",
									gaParams : [ {
										param3 : "Posted",
										param4 : "HeaderSet",
										param5: "",
										path : "PhysicalInventory/Detail/Submit"
									} ]
								} ];
								sap.custom.MessageHandling.handleRequestSuccess(oResponse, msgCode, $.proxy(function(msg){Transportation.that.initTableModel();}),that);
							},
							error:function(oError) {
								var msgCode = [ {
									code : "",
									gaParams : [ {
										param3 : "Posted with Error",
										param4 : "HeaderSet",
										param5: "",
										path : "PhysicalInventory/Detail/Submit"
									} ]
								} ];
								sap.custom.MessageHandling.handleRequestFailure(oError,msgCode,false);
							}});
					}
				}
			});		
		},

		ShipmentPrint:function(oEvent){
			var that=this;
			var oTable=oEvent.getSource().getParent().getParent();
			var index=oTable.indexOfItem(oEvent.getSource().getParent());
			that.EntireShipmentNo=oTable.getItems()[index+1].getBindingContext().getObject().ShipmntNum;
			MessageBox.show("Are you want to print the CN Number",{
				title : "Confirmation",
				icon: MessageBox.Icon.QUESTION,
				actions : ['Yes', 'No'],
				onClose : function(oAction){
					var path="/CNPrintSet(ShipmentNum='"+that.EntireShipmentNo+"',CNNum='',Mode='O',PrintInd='')/$value";
					Transportation.that.oModel.read(path, null, [], false, function(data, response) {
						var  url = response.requestUri;
						//sap.m.URLHelper.redirect(url, "false");
						window.open(url);
					}, function(oError) {
						var msgE = JSON.parse(oError.response.body).error.message.value;
						sap.m.MessageBox.show(msgE, {
							icon: sap.m.MessageBox.Icon.ERROR,
							title : "Error"
						});
						return;
					});
				}
			});		
		},
		pTripsListSubmit : function(){
			var tripNo = "",
			bSameTrip = true,
			iTBItems = this.iTBDelvy.getItems();
			for(var i = 0; i < iTBItems.length; i++){
				var iTFContent = iTBItems[i].getContent();
				for(var j = 0; j < iTFContent.length; j++){
					if(iTFContent[j] instanceof ScrollContainer){
						var table = iTFContent[j].getContent()[0],
						selItems = table.getSelectedItems(),
						selItemsLen = selItems.length;
						for(var k = 0; k < selItemsLen; k++){
							var oContext = selItems[k].getBindingContext().getObject();
							if(oContext.GroupHeader !== undefined){
								if(tripNo === ""){
									tripNo = oContext.TripNum;
								}
								else if(tripNo !== oContext.TripNum){
									bSameTrip = false;
								}
							}							
						}
					}
				}
			}
			if(bSameTrip && tripNo !== ""){
				this.getRouter().navTo("S2", {
					tripNo : tripNo
				});
			}
			else if(tripNo === ""){
				MessageToast.show("Select some trip");
			}
			else{
				MessageToast.show("Select only one Trip");
			}	
		},

		fnShowVehicles : function(oEvent){
			var oTable=oEvent.getSource().getParent().getParent();
			var index=oTable.indexOfItem(oEvent.getSource().getParent());
			this.EntireShipmentNo=oTable.getItems()[index+1].getBindingContext().getObject().ShipmntNum;
			this.VRNsite=oTable.getItems()[index+1].getBindingContext().getObject().Site;
			this.ShippingType=oTable.getItems()[index+1].getBindingContext().getObject().ShippingType;
			var that=this;
		},
		pCreateTripWVRN : function(oEvent){
			this.bCreateTrip = false;
			var shipType = "";
			var shipDesc = "";
			this.btnVRN = oEvent.getSource();
			var currItem = this.btnVRN.getParent();
			if(currItem instanceof ColumnListItem){
				var oContext = currItem.getBindingContext().getObject();
				if(oContext.GroupHeader === undefined){
					var table = currItem.getParent();
					var items = table.getItems();
					var currItemIndex = table.indexOfItem(currItem);
					oContext = items[currItemIndex + 1].getBindingContext().getObject();
					shipType = oContext.ShippingType;
					shipDesc = oContext.ShippingDesc;
					this.Site = oContext.Site1;
					this.fnShowVehicles(this, shipType, shipDesc);
				}
			}
			else{
				var bSameShipType = true;
				var count = 0;
				var table = this.getTable("trip");
				if(table !== ""){
					var selItems = table.getSelectedItems();
					var selItemsLen = selItems.length;
					for(var i = 0; i < selItemsLen; i++){
						var oContext = selItems[i].getBindingContext().getObject();					
						if(oContext.GroupHeader === undefined){
							count++;
							var currShipType = selItems[i + 1].getBindingContext().getObject().ShippingType;
							var currShipDesc = selItems[i + 1].getBindingContext().getObject().ShippingDesc;
							var currSite = selItems[i + 1].getBindingContext().getObject().Site1;
							if(shipType === ""){
								shipType = currShipType;
								shipDesc = currShipDesc;
								this.Site = currSite;
							}
							else if(shipType !== currShipType){
								bSameShipType = false;
							}
						}
					}				
					if(count > 0){
						if(bSameShipType){
							if(Formatter.getValidSameSTPShipTypes().indexOf(shipType) > -1 || count === 1){
								this.fnShowVehicles(this, shipType, shipDesc);
							}
							else{
								MessageToast.show(this.oi18nModel.getProperty("msgAddVRNToTrip"));
							}
						}
						else{
							MessageToast.show(this.oi18nModel.getProperty("msgTripsSameShipType"));
						}
					}
					else{
						MessageToast.show(this.oi18nModel.getProperty("msgSelectTrip"));					
					}
				}
				else{
					MessageToast.show(this.oi18nModel.getProperty("msgNoItems"));					
				}
			}				
		},
		lCVehicles : function(oEvent){
			var searchVal = oEvent.getSource().getValue().toLowerCase();
			var items = this.oCore.byId("S3lstVehicles").getItems();
			var itemsLen = items.length;
			for(var i = 0; i < itemsLen; i++){
				var title = items[i].getTitle().toLowerCase();
				var num = items[i].getNumber().toLowerCase();
				//var attr = items[i].getAttributes()[0].getText().toLowerCase();
				if(title.indexOf(searchVal) > -1 || num.indexOf(searchVal) > -1 ){
					items[i].setVisible(true);
				}
				else{
					items[i].setVisible(false);
				}
			}
		},
		cnVehicles : function(oEvent){
			var oTable=oEvent.getSource().getParent().getParent();
			var index=oTable.indexOfItem(oEvent.getSource().getParent());

			this.EntireShipmentNo=oTable.getItems()[index+1].getBindingContext().getObject().ShipmntNum;
			this.VRNsite=oTable.getItems()[index+1].getBindingContext().getObject().Site;
			this.ShippingType=oTable.getItems()[index+1].getBindingContext().getObject().ShippingType;
			var that=this;
			var EnteringFlag="N";
			for(var i=0;i<that.shipmentData.length;i++){
				if(this.EntireShipmentNo===that.shipmentData[i].ShipmntNum&&that.shipmentData[i].SalesDocNum!==""){
					EnteringFlag="S";
				}
				//rgvd_richa ro check both values 
				else if(this.EntireShipmentNo===that.shipmentData[i].ShipmntNum){
					EnteringFlag="";
					break;
				}
			}
			that.oContextVehicle = oEvent.getSource().getBindingContext().getObject();			
			if(EnteringFlag==="S"){
				this.getRouter().navTo("S2", {
				});
			}else{
				sap.m.MessageToast.show("STN required");
			}
		},
		handleNavigation:function(oEvent){

		},
		vHRLocs : function(oEvent){
			var path = "/SiteF4Set?$filter=Site eq '" + this.inpSite.getValue().toUpperCase() + "'";
			if(!this.dlgSite2s){
				this.dlgSite2s = sap.ui.xmlfragment("Transportation.fragment2.Sites2", this);				
			};
			this.dlgSite2s.bindAggregation("items", path, new StandardListItem({
				title : "{FirstName}",
				description : "{LastName}",
				type : "Active",
				info : "{Site}"
			}));
			this.dlgSite2s.open();
		},
		lCLastLoc : function(oEvent){
			var inpNo = oEvent.getSource();
			inpNo.setValue(inpNo.getValue().toUpperCase());
		},
		sSite : function(oEvent){
			var searchVal = oEvent.getParameter("value").toLowerCase();
			var items = this.dlgSite2s.getItems();
			var itemsLen = items.length;
			for(var i = 0; i < itemsLen; i++){
				var title = items[i].getTitle().toLowerCase();
				var desc = items[i].getDescription().toLowerCase();
				var info = items[i].getInfo().toLowerCase();
				if(title.indexOf(searchVal) > -1 || desc.indexOf(searchVal) > -1 || info.indexOf(searchVal) > -1){
					items[i].setVisible(true);
				}
				else{
					items[i].setVisible(false);
				}
			}
		},		
		cSite : function(oEvent){
			this.Site = oEvent.getParameter("selectedItem").getBindingContext().getObject().Site;
			this.inpSite.setValue(this.Site);			
		},
		pSiteCancel : function(){
			this.dlgSite2.close();
		},
		pSiteSubmit : function(){
			if(this.Site !== undefined){
				var that = this;
				var sSiteVal = this.inpSite.getValue().toUpperCase();
				var sPath = "/SiteF4Set?$filter=Site eq '" + sSiteVal + "'";
				Formatter.showLoader();
				this.oModel.read(sPath, {
					async : true,
					success : function(oData, oResponse){
						Formatter.hideLoader();
						var aSite = oData.results.filter(function(ele){
							return (ele.Site === sSiteVal);
						});
						if(aSite.length > 0){
							that.inpSite.setValueState("None");
							that.inpSite.setValueStateText("");
							that.Site = sSiteVal;
							that.fnAddVRNToTrip();
							that.dlgSite2.close();
						}
						else{
							that.inpSite.setValueState("Error");
							that.inpSite.setValueStateText(that.oi18nModel.getProperty("msgSiteInvalid"));
							MessageToast.show(that.oi18nModel.getProperty("msgSiteInvalid"));
						}
					},
					error : function(oError){
						Formatter.hideLoader();
						that.inpSite.setValueState("Error");
						that.inpSite.setValueStateText(that.oi18nModel.getProperty("msgSiteInvalid"));
						MessageToast.show(that.oi18nModel.getProperty("msgSiteInvalid"));
					}
				});
			}			
		},
		pCancel : function(oEvent){
			this.dlgVehicles2.close();
		},
		fnItemNav : function(oContext){
			var oItemNav = {
					Status : oContext.Status,							
					TripNum : oContext.TripNum,							
					VRNNum : oContext.VRNNum,
					CNNum : oContext.CNNum,
					OrderNum : oContext.OrderNum,
					OrdItemNum : oContext.OrdItemNum,
					DeliveryNum : oContext.DeliveryNum,
					DelItemNum : oContext.DelItemNum,
					ItemCatgry : oContext.ItemCatgry,
					OrderQty : oContext.OrderQty,
					ShippingType : oContext.ShippingType,
					DeliveryDate : Formatter.getDate1(oContext.DeliveryDate),
					ConfirmDate : Formatter.getDate1(oContext.ConfirmDate),
					Destination : oContext.Destination,
					VendorNum : oContext.VendorNum,
					SystemId : oContext.SystemId,
					UoM : oContext.UoM,
					Type : oContext.Type,
					ShipmntNum : oContext.ShipmntNum,
					TimeStamp : oContext.TimeStamp,
					ArticleDesc : oContext.ArticleDesc,
					StageSeq : oContext.StageSeq,
					Site : oContext.Site,
					ShippingPoint : oContext.ShippingPoint,
					ShipToPartyId : oContext.ShipToPartyId,
					Site1 : oContext.Site1,
					Route : oContext.Route,
					ReferenceNum:oContext.ReferenceNum,
					TotalWeight : oContext.TotalWeight,
					Netweight : oContext.Netweight,
					WeightUnit : oContext.WeightUnit,
					ShipToPartyName : oContext.ShipToPartyName,
					Volume : oContext.Volume,
					VolumeUnit : oContext.VolumeUnit,
					ShippingDesc : oContext.ShippingDesc,
					LoadSeq : oContext.LoadSeq,
					DropSeq : oContext.DropSeq,
					Sloc : oContext.Sloc,
					IssueSloc : oContext.IssueSloc,
					InvoiceNum : oContext.InvoiceNum,
					ArtiFreigtGRP : oContext.ArtiFreigtGRP,
					Number : oContext.Number,
					Detail : oContext.Detail,
					InCoterms : oContext.InCoterms,
					DestinationTeri : oContext.DestinationTeri,
					Distance : oContext.Distance,
					StatusDesc : oContext.StatusDesc,
					InvoiceDate : Formatter.getDate1(oContext.InvoiceDate),
					InvoiceTime : oContext.InvoiceTime,
					BillDate : Formatter.getDate1(oContext.BillDate),
					BillTime : oContext.BillTime,
					BillQty : oContext.BillQty,
					SaleUnit : oContext.SaleUnit,
					StIcon : oContext.StIcon,
			};
			return oItemNav;
		},
		fnAddVRNDetails : function(oData){
			oData.Status = this.oContextVehicle.Status;
			oData.VRNNum = this.oContextVehicle.VRNNum;
			oData.Vehiclenum = this.oContextVehicle.Vehiclenum;
			oData.TransportName = this.oContextVehicle.TransportName;
			oData.Capacity = this.oContextVehicle.Capacity;
			oData.CapacityUnit = this.oContextVehicle.CapacityUnit;
			oData.VehSecDate = this.oContextVehicle.VehSecDate;
			oData.VehSecTime = this.oContextVehicle.VehSecTime;
			oData.Purpose = this.oContextVehicle.Purpose;
			oData.Vendor = this.oContextVehicle.Vendor;
			oData.VehicleTyp = this.oContextVehicle.VehicleTyp;
			oData.ShippingDesc = this.oContextVehicle.ShippingDesc;
			oData.VehicleId = this.oContextVehicle.VehicleId;
			oData.VehicleIdDesc = this.oContextVehicle.VehicleIdDesc;
			oData.VendorName = this.oContextVehicle.VendorName;
			oData.FleetType = this.oContextVehicle.FleetType;
			oData.FromDate = Formatter.getDate1(this.oContextVehicle.FromDate);
			oData.Todate = Formatter.getDate1(this.oContextVehicle.Todate);
			oData.DriverName = this.oContextVehicle.DriverName;
			oData.LicenceNum = this.oContextVehicle.LicenceNum;
			oData.StIcon = this.oContextVehicle.StIcon;			
		},
		fnGetItemNav : function(){
			var aItemNav;
			aItemNav = [];
			var currItem = this.btnCreTrip.getParent();
			if(currItem instanceof ColumnListItem){
				var oContext = currItem.getBindingContext().getObject();
				if(oContext.GroupHeader === undefined){
					var table = currItem.getParent();
					var items = table.getItems();
					var currItemIndex = table.indexOfItem(currItem);
					for(var i = currItemIndex + 1; i < items.length && items[i].getBindingContext().getObject().GroupHeader !== undefined; i++){
						oContext = items[i].getBindingContext().getObject();							
						aItemNav.push(this.fnItemNav(oContext));
					}
				}
				else{
					aItemNav.push(this.fnItemNav(oContext));
				}
			}
			else{
				var oTable = this.getTable("open");
				var gTable = this.getTable("grouped");
				var selItems; 
				selItems = [];
				if(oTable !== ""){
					selItems = oTable.getSelectedItems();
				}
				if(gTable !== ""){
					var gItems = gTable.getSelectedItems();
					selItems = selItems.concat(gItems);						
				}
				var selItemsLen = selItems.length;
				for(var i = 0; i < selItemsLen; i++){
					var oContext = selItems[i].getBindingContext().getObject();
					if(oContext.GroupHeader !== undefined){
						aItemNav.push(this.fnItemNav(oContext));
					}
				}
			}
			return aItemNav;
		},
		fnAddVRNToTrip : function(){
			var aItemNav;
			aItemNav = [];
			var currItem = this.btnVRN.getParent();
			if(currItem instanceof ColumnListItem){
				var table = currItem.getParent();
				var items = table.getItems();
				var itemsLen = items.length;
				var currItemIndex = table.indexOfItem(currItem);
				for(var i = currItemIndex + 1; i < itemsLen && items[i].getBindingContext().getObject().GroupHeader !== undefined; i++){
					var oContext = items[i].getBindingContext().getObject();
					aItemNav.push(this.fnItemNav(oContext));
				}
			}
			else{
				var table = this.getTable("trip");
				if(table !== ""){
					var selItems = table.getSelectedItems();
					var selItemsLen = selItems.length;
					for(var i = 0; i < selItemsLen; i++){
						var oContext = selItems[i].getBindingContext().getObject(); 
						if(oContext.GroupHeader !== undefined){
							aItemNav.push(this.fnItemNav(oContext));
						}
					}
				}				
			}
			if(aItemNav.length > 0){
				var path = "TransShipHdrSet";
				var data = {};
				this.fnAddVRNDetails(data);
				if(this.Site !== undefined){
					data.Site = this.Site;
					this.Site = undefined;
				}
				data.VRNEXECUTIONNAV = aItemNav;			
				this.postData(path, data, [ "/001" ] ,"S1", "AddVRN");
			}			
		},
		pDelDelvy : function(oEvent){			
			var aItemNav;
			aItemNav = [];
			var btnDel = oEvent.getSource();
			var currItem = btnDel.getParent();			
			if(currItem.getBindingContext().getObject().GroupHeader === undefined){
				var table = currItem.getParent();
				var items = table.getItems();
				var itemsLen = items.length;
				var currItemIndex = table.indexOfItem(currItem);
				for(var i = currItemIndex + 1; i < itemsLen && items[i].getBindingContext().getObject().GroupHeader !== undefined; i++){
					var oContext = items[i].getBindingContext().getObject();
					var oItemNav = this.fnItemNav(oContext);
					aItemNav.push(oItemNav);
				}
			}
			else{
				var oContext = currItem.getBindingContext().getObject();
				var oItemNav = this.fnItemNav(oContext);
				aItemNav.push(oItemNav);
			}			
			var path = "DeliveryRemoveSet";
			var data = {
					Dummy : "X",
					DELIVERYEXECUTIONNAV : aItemNav
			};			
			this.postData(path, data, [ "/001" ], "S1", "RemoveDelivery");
		},
		pTripDetailsClose : function(oEvent){
			this.dlgDeliveryDetails.close();
		},
		sTblGroupH : function(oEvent){
			var tableH = oEvent.getSource();
			var table = tableH.getParent().getContent()[1].getContent()[0];
			var items = table.getItems();
			var itemsLen = items.length;
			for(var i = 0; i < itemsLen; i++){
				var oContext = items[i].getBindingContext().getObject();
				if(oContext.GroupHeader === undefined){
					oContext = items[i + 1].getBindingContext().getObject();
				}
				//	if((oContext.ShipmntNum !== "" || (oContext.TripNum !== "" && oContext.VRNNum  === "")) && Formatter.getValidCreateTripShipTypes().indexOf(oContext.ShippingType) === -1){
				if(oContext.Route === ""){
					items[i].setSelected(false);
				}
				else{
					items[i].setSelected(tableH.getItems()[0].getSelected());
				}				
			}
		},
		sTblGroup : function(oEvent){
			//Method to set selected the Child Items of the Group when the Group is selected
			var tblGroup = oEvent.getSource();
			var selectedItem = oEvent.getParameter("listItem");
			var items = tblGroup.getItems();
			var currItemIndex = tblGroup.indexOfItem(selectedItem);			
			if(selectedItem.getBindingContext().getObject().GroupHeader === undefined){
				var oContext = items[currItemIndex + 1].getBindingContext().getObject();
				if((oContext.ShipmntNum !== "" || (oContext.TripNum !== "" && oContext.VRNNum  === "")) && Formatter.getValidCreateTripShipTypes().indexOf(oContext.ShippingType) === -1){
					selectedItem.setSelected(false);
				}
				else{					
					for(var i = currItemIndex + 1; i < items.length && items[i].getBindingContext().getObject().GroupHeader !== undefined; i++){
						items[i].setSelected(selectedItem.getSelected());					
					}
				}
			}
			else if(selectedItem.getBindingContext().getObject().GroupHeader !== "///"){//Keep selected the child items when group head item is selected
				selectedItem.setSelected(!selectedItem.getSelected());
			}
		},		
		sFSearch : function(oEvent){
			var aSearchVal;
			aSearchVal = [oEvent.getSource().getValue().toLowerCase()];
			var aProps;
			aProps = [
			          "ShipmntNum", "ShpmntStart","SLoc", "CustName", "CustomerNum",
			          "Server", "Route", "DeliveryNum", "CreatedOn", "SalesDocNum", "LRNum"
			          ];
			this.fnLocalSearch(aSearchVal, aProps);			
		},
		fnLocalSearch : function(srchVal, srchProp){
			var items;
			items = [];
			var iTBItems = this.iTBDelvy.getItems();
			for(var i = 0; i < iTBItems.length; i++){
				var content = iTBItems[i].getContent();
				for(var j = 0; j < content.length; j++){
					if(content[j] instanceof ScrollContainer){
						var table = content[j].getContent()[0];
						var tableItems = table.getItems();
						items = (items.length === 0) ? tableItems : items.concat(tableItems);
					}
				}
			}
			var itemsLen = items.length;
			var groupHeaderIndex = -1;
			var setWholeGrpVisible = false;
			for(var i = 0; i < itemsLen; i++){
				var context = items[i].getBindingContext().getObject();
				if(context.GroupHeader !== undefined){
					var setItemVisible = false;
					for(var prop in context){
						if(srchProp.indexOf(prop) > -1){
							var propVal = context[prop]; 
							if(prop === "CreatedOn"){
								propVal = Formatter.getDateFormatted(context[prop]);
							}
							propVal = propVal.toLowerCase();
							for(var j = 0; j < srchVal.length; j++){
								if(propVal.indexOf(srchVal[j]) > -1){
									setItemVisible = true;
									if(prop === "Server" && context["ShipmntNum"] !== ""){
										setWholeGrpVisible = true;
									}
								}
							}							
						}
					}
					items[i].setVisible(setItemVisible);

					if(groupHeaderIndex !== -1 && items[groupHeaderIndex + 1].getBindingContext().getObject().GroupHeader === "///"){//Hide the group header if it is ungrouped
						items[groupHeaderIndex].setVisible(false);
						items[groupHeaderIndex].getCells()[0].getItems()[0].setSrc("sap-icon://navigation-right-arrow");
					}
					else if(groupHeaderIndex !== -1 && items[groupHeaderIndex + 1].getBindingContext().getObject().GroupHeader !== "///" && setItemVisible){
						items[groupHeaderIndex].setVisible(true);
						items[groupHeaderIndex].getCells()[0].getItems()[0].setSrc("sap-icon://navigation-down-arrow");
						if(setWholeGrpVisible){
							for(var j = groupHeaderIndex + 1; (j < items.length && items[j].getBindingContext().getObject().GroupHeader !== undefined); j++){
								items[j].setVisible(true);
							}
						}
					}					
				}
				else{
					groupHeaderIndex = i;//Store the group header index so that when child item is visible then group header can be made visible
					items[i].setVisible(false);
				}
			}
		},		
		pSearch : function(oEvent){
			if(!this.pgExe.getShowSubHeader()){
				this.byId("S3sFLocSearch1").setValue();
			}
			this.pgExe.setShowSubHeader(!this.pgExe.getShowSubHeader());
		},
		pRefresh : function(){
			this.initTableModel();
		},
		fnRefreshData : function(wholeRefresh){
			if(this.dlgFilter2 && wholeRefresh){
				this.dRSDeliveryDate.setDateValue();
				this.dRSDeliveryDate.setSecondDateValue();
				this.dRSDeliveryDate.setValueState("None");
				this.mCmbShipType.clearSelection();
				this.btnSearch.setEnabled(false);
				this.btnClear.setEnabled(false);
				this.btnFilter.setType("Default");
			}
			this.initTableModel();
		},
		pFilter : function(oEvent){
			if(!this.dlgFilter2){
				this.dlgFilter2 = new sap.ui.xmlfragment("Transportation.fragment2.Filter2", new Filter());
				this.dRSDeliveryDate = this.oCore.byId("S3dRSDeliveryDate");
				this.mCmbShipType = this.oCore.byId("S3mCmbShipType");			
				this.btnSearch = this.oCore.byId("S3btnFilterSearch");
				this.btnClear = this.oCore.byId("S3btnFilterClear");
			}
			this.dlgFilter2.open();
			var fromDate = this.dRSDeliveryDate.getDateValue();
			var toDate = this.dRSDeliveryDate.getSecondDateValue();
			if(fromDate !== null && toDate !== null){
				this.btnClear.setEnabled(true);
			}
			else{
				this.btnClear.setEnabled(false);
				this.btnSearch.setEnabled(false);
			}
		},
		fnFilterCallBack : function(bDateChanged) {
			if(this.mCmbShipType){
				var items = this.mCmbShipType.getItems();
				this.Key=this.mCmbShipType.getSelectedKey();
				var shipTypeItems = this.mCmbShipType.getSelectedItem().getText();
				var shipTypeItemsLen = shipTypeItems.length;
				var aProps;
				aProps = [ "ShippingType" ];
				var aShipTypes;
				aShipTypes = [];
				if(bDateChanged === undefined || (bDateChanged !== undefined && bDateChanged === true && shipTypeItemsLen > 0)){
					if (shipTypeItemsLen > 0) {
						for (var i = 0; i < shipTypeItemsLen; i++) {
							aShipTypes.push(shipTypeItems[i].getKey().toLowerCase());
						}				
					} else {
						for (var i = 0; i < items.length; i++) {
							aShipTypes.push(items[i].getKey().toLowerCase());
						}				
					}				
					this.fnLocalSearch(aShipTypes,aProps);
				}				
			}			
		},
		addRemoveFilterClass : function(colIndex, bAdd){
			var items = this.iTBDelvy.getItems();
			for(var i = 0; i < items.length; i++){
				var content = items[i].getContent();
				for(var j = 0; j < content.length; j++){
					if(content[j] instanceof Table){
						var header = content[j].getColumns()[colIndex].getAggregation("header");
						if(bAdd){
							header.addStyleClass("ColumnFilter");
						}
						else{
							header.removeStyleClass("ColumnFilter");
						}
					}
				}
			}
		},

		//Define Value Help Function for SLloc.
		pCreateTrippost : function() {
			var oTable = this.getTable("open");
			if(oTable.getSelectedItems().length===0){
				sap.m.MessageToast.show("Please select the item before posting");
				return;
			}
			if (!this.trsptShpmtType2) {
				this.trsptShpmtType2=sap.ui.xmlfragment("Transportation.fragment2.Transport21", this);
			}
			this.trsptShpmtType2.open();
			sap.ui.getCore().byId("S3transportTypeid").setValue("");
			sap.ui.getCore().byId("S3transportNameid").setValue("").setVisible(false);
			sap.ui.getCore().byId("S3arrangeId").setSelectedKey("NT");
			sap.ui.getCore().byId("S3vehicletypeIdS1").setValue("").setVisible(false);
		},
		handleTransportClose:function(){
			this.trsptShpmtType2.close();
		},
		handleTransportShipmentType:function(){
			var that=this;
			var oTable = that.getTable("open"),selectedData;
			var path="/ShipmntModeListSet";
			var shipmeTypeFlag="NX";
			that.oModel.read(path, null, [], false, function(oData, response) {
				var data=oData.results;
				var data2=[];
				for(var i=0;i<oTable.getSelectedItems().length;i++){
					selectedData=oTable.getSelectedItems()[i].getBindingContext().getObject();
					if(oTable.getSelectedItems()[0].getBindingContext().getObject().CustomerNum!==selectedData.CustomerNum){
						shipmeTypeFlag="X";
					}
				}
				if(shipmeTypeFlag==="X"){
					for(var i=0;i<data.length;i++){
						if(data[i].ShipngType==="RD"||data[i].ShipngType==="HD"){
							data2.push(data[i]);
						}
					}
				}else{
					data2=data;
				}
				var json=new sap.ui.model.json.JSONModel();
				json.setData(data2);
				that._valueHelpDialog2 = new sap.m.SelectDialog({
					title : "Select Transporter",
					noDataText : "No Entries Found",
					items : {
						path : "/",
						template : new sap.m.StandardListItem({
							title : "{ShipngDesc}",
							description : "{ShipngType}",
							icon : "{path:'ShipngType',formatter:'Transportation.util.Formatter.getShipTypeIcon'}",
						})
					},
					liveChange : [ that.sShipType, that ],
					confirm : [ that.cnShipTypeconfirm, that ],
					cancel : [ that.cnShipTypeclose, that ]
				});
				that._valueHelpDialog2.setModel(json);
				that._valueHelpDialog2.open();
			}, function(oError) {
				var msgE = JSON.parse(oError.response.body).error.message.value;
				sap.m.MessageBox.show(msgE, {
					icon: sap.m.MessageBox.Icon.ERROR,
					title : "Error"
				});
				return;
			});
		},
		sShipType : function(evt) {
			var sValue = evt.getParameter("value").toLowerCase();
			var keys = evt.getSource().getBinding("items").aKeys;
			var smodel =  evt.getSource().getModel();
			for (var i = 0; i < this._valueHelpDialog2.getItems().length; i++){
				var val = smodel.getProperty("/" + keys[i]).ShipngType.toLowerCase();
				var val1 = smodel.getProperty("/" + keys[i]).ShipngDesc.toLowerCase();
				if (val.indexOf(sValue) > -1 || val1.indexOf(sValue) > -1){
					this._valueHelpDialog2.getItems()[i].setVisible(true);
				} else {
					this._valueHelpDialog2.getItems()[i].setVisible(false);
				}
			}
		},
		cnShipTypeconfirm : function(evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			sap.ui.getCore().byId("S3transportNameid").setValue("");
			if (oSelectedItem) {
				var i1 = sap.ui.getCore().byId("S3transportTypeid");
				i1.setValue(oSelectedItem.getTitle()+" - "+oSelectedItem.getDescription());
				this.ShippingType = oSelectedItem.getDescription();
			}
			if(this.ShippingType==="HD"){
				sap.ui.getCore().byId("S3arrangeId").setVisible(false).setSelectedKey("E"); //added on 23 March 2019 rgvd_richa
				sap.ui.getCore().byId("S3transportNameid").setVisible(false);
				sap.ui.getCore().byId("S3vehicletypeIdS1").setVisible(false);

			}if(this.ShippingType!=="HD"){
				sap.ui.getCore().byId("S3arrangeId").setVisible(true).setSelectedKey("E");
			}if(this.ShippingType==="CA"||this.ShippingType==="CR"){
				sap.ui.getCore().byId("S3arrangeId").setVisible(true).setSelectedKey("N").setEnabled(false);
				sap.ui.getCore().byId("S3transportNameid").setVisible(true);
				sap.ui.getCore().byId("S3vehicletypeIdS1").setVisible(false);
			}if(this.ShippingType==="RD"){
				sap.ui.getCore().byId("S3arrangeId").setVisible(true).setEnabled(true).setSelectedKey("E");
				sap.ui.getCore().byId("S3transportNameid").setVisible(false);
				sap.ui.getCore().byId("S3vehicletypeIdS1").setValue("").setVisible(false);
			}
		},
		handleTransporterName:function(){
			if (!this.trsptShpmtType22) {
				this.trsptShpmtType22=sap.ui.xmlfragment("Transportation.fragment2.Transport22", this);
			}
			this.oCore.byId("S3transportTypeid2").setValue("");
			this.trsptShpmtType22.open();
		},	
		handleTransportSelectionPost:function(){
//			if(sap.ui.getCore().byId("S3transportTypeid").getValue()===""){
//			sap.m.MessageToast.show("Select Transport Type");
//			return;
//			}else if(sap.ui.getCore().byId("S3arrangeId").getSelectedKey()==="" && this.ShippingType != "HD"){
//			sap.m.MessageToast.show("Select ArrangedBy");
//			return;
//			}else if(sap.ui.getCore().byId("S3transportNameid").getValue()===""&&((this.ShippingType==="CA"||this.ShippingType==="CR")&&sap.ui.getCore().byId("S3arrangeId").getSelectedKey()==="N")){
//			sap.m.MessageToast.show("Select Transporter");
//			return;
//			}else if(sap.ui.getCore().byId("S3transportNameid").getValue()===""&&(this.ShippingType==="RD"&&sap.ui.getCore().byId("S3arrangeId").getSelectedKey()==="F")){
//			sap.m.MessageToast.show("Select Transporter");
//			return;
//			}
			var vehNum=this.oCore.byId("S3transportTypeid2").getValue().toUpperCase().trim();
			var fcpl=this.oCore.byId("S3arrangeId").getSelectedKey();
			var that=this;
			//	var vehNum=this.oCore.byId("S3transportNameid").getValue().toUpperCase().trim();
			if(vehNum.length<2){
				sap.m.MessageToast.show("Trnsporter number below 2 digits not allowed.");
				return;
			}else{
				var path="";

				//Mode, FcplInd
				if (!isNaN(vehNum)){
					path="/VendorListSet?$filter=VendorNum eq '"+vehNum+"' and VendorName eq '' and Mode eq'"+that.ShippingType+"' and FcplInd eq'"+fcpl+"'";
				} else {
					path="/VendorListSet?$filter=VendorNum eq '' and VendorName eq '"+vehNum+"' and Mode eq'"+that.ShippingType+"' and FcplInd eq'"+fcpl+"'";
				}
				that.oModel.read(path,null,[],false,function(oData,oResponse){
					var jsonModel=new JSONModel(oData.results);
					that._valueHelpDialog3 = new sap.m.SelectDialog({
						title : "Select Transporter",
						noDataText : "No Entries Found",
						items : {
							path : "/",
							template : new sap.m.StandardListItem({
								title : "{VendorName}",
								description : "{VendorNum}",
							})
						},
						liveChange : [ that._handleVRNNOValueHelp2Search, that ],
						confirm : [ that._handleVRNValueHelp2Close, that ],
						cancel : [ that._handleVRNValueHelp2Close, that ]
					});
					that._valueHelpDialog3.setModel(jsonModel);
					that._valueHelpDialog3.open();
				},function(oError){
					sap.custom.MessageHandling.handleRequestFailure(oError, "", true);
					sap.ui.getCore().byId("S3transportTypeid2").setValue("");
					that.trsptShpmtType22.close();
				});
			}
		},
		_handleVRNValueHelp2Close : function(evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var i1 = sap.ui.getCore().byId("S3transportNameid");
				i1.setValue(oSelectedItem.getTitle()+" - "+oSelectedItem.getDescription());
				this.VRN = oSelectedItem.getDescription();
				this.trsptShpmtType22.close();
				//this.shipmentSubmit();
			}
		},
		_handleVRNValueHelp2Search : function(evt) {
			var sValue = evt.getParameter("value").toLowerCase();
			var keys = evt.getSource().getBinding("items").aKeys;
			var smodel =  evt.getSource().getModel();
			for (var i = 0; i < this._valueHelpDialog2.getItems().length; i++){
				var val = smodel.getProperty("/" + keys[i]).VendorName.toLowerCase();
				var val1 = smodel.getProperty("/" + keys[i]).VendorNum.toLowerCase();
				if (val.indexOf(sValue) > -1 || val1.indexOf(sValue) > -1){
					this._valueHelpDialog2.getItems()[i].setVisible(true);
				} else {
					this._valueHelpDialog2.getItems()[i].setVisible(false);
				}
			}
		},

		handleTransportSelectionClose:function(){
			sap.ui.getCore().byId("S3transportTypeid2").setValue("");
			this.trsptShpmtType22.close();
		},

		handeSelect:function(){
			sap.ui.getCore().byId("S3transportNameid").setValue("");
			var value=sap.ui.getCore().byId("S3arrangeId").getSelectedKey();
			if(value==="F"&&this.ShippingType==="RD"){
				sap.ui.getCore().byId("S3transportNameid").setVisible(true);
				sap.ui.getCore().byId("S3vehicletypeIdS1").setVisible(true);

			}else if((this.ShippingType==="CA"||this.ShippingType==="CR")&&value==="N"){
				sap.ui.getCore().byId("S3transportNameid").setVisible(true);
				sap.ui.getCore().byId("S3vehicletypeIdS1").setVisible(false);
			}
			else{
				sap.ui.getCore().byId("S3transportNameid").setVisible(false);
				sap.ui.getCore().byId("S3vehicletypeIdS1").setVisible(false);
			}
		},

		handleTransportPost:function(){
			var that=this;
			var oTable = this.getTable("open");
			var data={},table_data=[];
			var selectedData;
			if(sap.ui.getCore().byId("S3transportTypeid").getValue()===""){
				sap.m.MessageToast.show("Select Transport Type");
				return;
			}else if(sap.ui.getCore().byId("S3arrangeId").getSelectedKey()==="" && this.ShippingType != "HD"){
				sap.m.MessageToast.show("Select ArrangedBy");
				return;
			}else if(sap.ui.getCore().byId("S3transportNameid").getValue()===""&&((this.ShippingType==="CA"||this.ShippingType==="CR")&&sap.ui.getCore().byId("S3arrangeId").getSelectedKey()==="N")){
				sap.m.MessageToast.show("Select Transporter");
				return;
			}else if(sap.ui.getCore().byId("S3transportNameid").getValue()===""&&(this.ShippingType==="RD"&&sap.ui.getCore().byId("S3arrangeId").getSelectedKey()==="F")){
				sap.m.MessageToast.show("Select Transporter");
				return;
			}else if(this.ShippingType==="RD"&&sap.ui.getCore().byId("S3arrangeId").getSelectedKey()==="F"&&sap.ui.getCore().byId("S3vehicletypeIdS1").getValue()===""){
				sap.m.MessageToast.show("Select Vehicle Type");
				return;
			}
			that.trsptShpmtType2.close();
			data.ArrangeBy=sap.ui.getCore().byId("S3arrangeId").getSelectedKey();
			//changes on 23 March 2019 rgvd_richa
			data.ServiceAgent=that.VRN; 
			if(this.ShippingType === "HD"){
				data.ArrangeBy = "N";
				data.ServiceAgent="";
			}
			if(this.ShippingType==="RD"&&sap.ui.getCore().byId("S3arrangeId").getSelectedKey()==="N"){
				data.ServiceAgent="";
			}

			if((this.ShippingType==="CA"||this.ShippingType==="CR")&&sap.ui.getCore().byId("S3arrangeId").getSelectedKey()==="F"){
				data.ServiceAgent="";
			}
			data.Route="";
			data.ShippingType=this.ShippingType;
			data.ExTknum="";
			data.ContainerId="";
			if(this.ShippingType==="RD"&&sap.ui.getCore().byId("S3arrangeId").getSelectedKey()==="F"){
				data.Vehtyp=this.vehicleIdS1;
				//data.VechileType=this.vehicleIdS1;
			}else if(this.ShippingType!=="RD"||sap.ui.getCore().byId("S3arrangeId").getSelectedKey()!=="F"){
				data.Vehtyp="";
				//data.VechileType=this.vehicleIdS1;
			}
			//	data.ServiceAgent=that.VRN; 
			var distance=0;
			for(var i=0;i<oTable.getSelectedItems().length;i++){
				selectedData=oTable.getSelectedItems()[i].getBindingContext().getObject();
				for(var j=0;j<that.MainData.length;j++){
					if(selectedData.DeliveryNum===that.MainData[j].DeliveryNum){
						var oData=that.MainData[j];
						var tabdata1 ={
								CreatedOn:oData.CreatedOn,
								LRNum:oData.LRNum,
								LRDate:oData.LRDate,
								Site:oData.Site,
								InvoiceType:oData.InvoiceType,
								SLoc:oData.SLoc,
								InvoiceDate:oData.InvoiceDate,
								OrderType:oData.OrderType,
								DeliveryNum:oData.DeliveryNum,
								InvoiceAmount:oData.InvoiceAmount,
								DropSequence:oData.DropSequence,
								OrderDate:oData.OrderDate,
								ItemNum:oData.ItemNum,
								Port:oData.Port,
								BillingDocNum:oData.BillingDocNum,
								CompanyCode:oData.CompanyCode,
								OrdQty:oData.OrdQty,
								RemarkDesc:oData.RemarkDesc,
								UoM:oData.UoM,
								ArticleNum:oData.ArticleNum,
								RemarkInd:oData.RemarkInd,
								ArticleDesc:oData.ArticleDesc,
								DeliveryInd:oData.DeliveryInd,
								SalesDocNum:oData.SalesDocNum,
								BillingDate:oData.BillingDate,
								CustomerNum:oData.CustomerNum,
								CustName:oData.CustName,
								VendorNum:oData.VendorNum,
								VendorName:oData.VendorName,
								Country:oData.Country,
								ShippingType:oData.ShippingType,
								SalesRefDocNum:oData.SalesRefDocNum,
								DeliveryDate:oData.DeliveryDate,
								ShipmntNum:oData.ShipmntNum,
								Server:oData.Server,
								Route:oData.Route,
								TransptZone:oData.TransptZone,
								Distance:oData.Distance,
								IncoTerms:oData.IncoTerms,
								TransZonefC:oData.TransZonefC,
								TransZonedC:oData.TransZonedC,
								RouteC:oData.RouteC,
								ShpmntStart:oData.ShpmntStart,
								CurrentDate:oData.CurrentDate,
								Plant:oData.Plant,
								VRNNum:oData.VRNNum,
								StatusInd:oData.StatusInd
						};
						table_data.push(tabdata1);
						if(parseInt(oData.Distance)>parseInt(distance)){
							distance=oData.Distance;
							data.Route=oData.Route;
						}
					}
				}
			}
			data.TRANSHIPHDRITMNAV=table_data;
			Formatter.showLoader();
			that.oModel.create("/TransShipHdrSet", data, {async : true,
				success :function(value, oResponse) {
					Formatter.hideLoader();
					//	this.messageVal=value;
					var msgCode = [{
						code : "/000",
						gaParams : [ {
							param3 : "Posted",
							param4 : "HeaderSet",
							param5: "",
							path : "PhysicalInventory/Detail/Submit"
						} ]
					} ];
					sap.custom.MessageHandling.handleRequestSuccess(oResponse, msgCode, $.proxy(function(msg){that.initTableModel();}),that);
				},
				error:function(oError) {
					Formatter.hideLoader();
					var msgCode = [ {
						code : "",
						gaParams : [ {
							param3 : "Posted with Error",
							param4 : "HeaderSet",
							param5: "",
							path : "PhysicalInventory/Detail/Submit"
						} ]
					} ];
					sap.custom.MessageHandling.handleRequestFailure(oError,msgCode,false);
				}});

		},
		pCreateCN : function(oEvent){
			var that=this;
			var oTable=oEvent.getSource().getParent().getParent();
			var index=oTable.indexOfItem(oEvent.getSource().getParent());
			this.EntireShipmentNo=oTable.getItems()[index+1].getBindingContext().getObject().ShipmntNum;
			//var aData=oEvent.getSource().getBindingContext().getObject();
			MessageBox.show("Are you want to create CN",{
				title : "Confirmation",
				icon: MessageBox.Icon.QUESTION,
				actions : ['Yes', 'No'],
				onClose : function(oAction){
					if(oAction === "Yes"){
						var path="/CNCreateSet?$filter=ShipmentNum eq '"+that.EntireShipmentNo+"' and Mode eq '' and CNNum eq ''";
						//var path="/ShipmentDeleteSet(ShipmentNum='"+that.EntireShipmentNo+"')"; 
						that.oModel.read(path, {async : true,
							success :function(value, oResponse) {
								//	this.messageVal=value;
								var msgCode = [{
									code : "/000",
									gaParams : [ {
										param3 : "Posted",
										param4 : "HeaderSet",
										param5: "",
										path : "PhysicalInventory/Detail/Submit"
									} ]
								} ];
								sap.custom.MessageHandling.handleRequestSuccess(oResponse, msgCode, $.proxy(function(msg){that.initTableModel();}),that);
							},
							error:function(oError) {
								var msgCode = [ {
									code : "",
									gaParams : [ {
										param3 : "Posted with Error",
										param4 : "HeaderSet",
										param5: "",
										path : "PhysicalInventory/Detail/Submit"
									} ]
								} ];
								sap.custom.MessageHandling.handleRequestFailure(oError,msgCode,false);
							}});
					}
				}
			});
		},

		navBackHome:function(){
			var navigationService = sap.ushell.Container.getService("CrossApplicationNavigation");
			navigationService.toExternal({
				target : {
					semanticObject : "",
					action : ""
				},
			});
		},
		getRouter : function() {
			return UIComponent.getRouterFor(this);
		},
		//Define Value Help Function for SLloc.
		handleValueHelpVehicleS1 : function() {
			if(navigator.onLine){
				this._valueHelpDialog2 = new sap.m.SelectDialog({
					title : "Select Vehicle Type",
					noDataText : "No Entries Found",
					items : {
						path : "/VehicleTypeSet",
						template : new sap.m.StandardListItem({
							title : "{VehicleTypeDesc}",
							description : "{VehicleId}",
						})
					},
					liveChange : [ this._handleValueHelp2SearchS1, this ],
					confirm : [ this._handleValueHelp2CloseS1, this ],
					cancel : [ this._handleValueHelp2CloseS1, this ]
				});
				this._valueHelpDialog2.setModel(this.oModel);
				this._valueHelpDialog2.open();
			}
			else{
				sap.m.MessageToast.show("You are in offline mode");
			}
		},
		_handleValueHelp2CloseS1 : function(evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var i1 = sap.ui.getCore().byId("S3vehicletypeIdS1");
				i1.setValue(oSelectedItem.getDescription());
				this.vehicleIdS1 = oSelectedItem.getDescription();
			}
		},
		_handleValueHelp2SearchS1 : function(evt) {
			var sValue = evt.getParameter("value").toLowerCase();
			var keys = evt.getSource().getBinding("items").aKeys;
			var smodel =  evt.getSource().getModel();
			for (var i = 0; i < this._valueHelpDialog2.getItems().length; i++){
				var val = smodel.getProperty("/" + keys[i]).VehicleTypeDesc.toLowerCase();
				var val1 = smodel.getProperty("/" + keys[i]).VehicleId.toLowerCase();
				if (val.indexOf(sValue) > -1 || val1.indexOf(sValue) > -1){
					this._valueHelpDialog2.getItems()[i].setVisible(true);
				} else {
					this._valueHelpDialog2.getItems()[i].setVisible(false);
				}
			}
		},

		onExit : function(){
			if(this.dlgFilter2){
				this.dlgFilter2.destroy();				
			}
			if(this.dlgCNPrint2){
				this.dlgCNPrint2.destroy();				
			}
			if(this.dlgTripsList2){
				this.dlgTripsList2.destroy();				
			}
			if(this.dlgVehicles2){
				this.dlgVehicles2.destroy();
			}
			if(this.dlgSealInf2){
				this.dlgSealInf2.destroy();
			}
			if(this.dlgSite2){
				this.dlgSite2.destroy();
			}
			if(this.dlgShipType2){
				this.dlgShipType2.destroy();
			}
			if(this.oPopOver22){
				this.oPopOver22.destroy();
			}
			if(this.ShipTypeCreate2){
				this.ShipTypeCreate2.destroy();
			}
			if(this.trsptShpmtType2){
				this.trsptShpmtType2.destroy();
			}
			if(this.trsptShpmtType22){
				this.trsptShpmtType22.destroy();
			}
			if(this.RouteOperator2){
				this.RouteOperator2.destroy();
			}

		}
	});
});