jQuery.sap.declare("TransportExecution.Component");

sap.ui.define(['sap/ui/core/UIComponent', 'sap/m/routing/RouteMatchedHandler', 'sap/ui/model/odata/ODataModel', 'sap/ui/model/resource/ResourceModel', 'TransportExecution/util/Formatter'], 
		function(UIComponent, RouteMatchedHandler, ODataModel, ResourceModel, Formatter){
	"use strict";

	var proxy = Formatter.getProxy();
	
	jQuery.sap.registerModulePath('sap.custom', proxy + '/sap/bc/ui5_ui5/sap/zreuse_scmlib/sap/custom');
	
	return UIComponent.extend("TransportExecution.Component",{
		metadata : {
			includes : [ "css/style.css", "util/Formatter.js", ((proxy === "") ? "../.." : proxy + "/sap/bc/ui5_ui5/sap") + "/zreuse_scmlib/sap/custom/themes/sap_bluecrystal/library.css" ],
			dependencies : {
				libs : [ 'sap.m' ]
			},
			config : {
				resourceBundle : "i18n/messageBundle.properties",
				serviceConfig : {
					name : "",
					serviceUrl : Formatter.getServiceUrl(Formatter.ExeService)
				}
			},
			routing : {
				config : {
			        "viewType" : "XML",
			        "viewPath" : "TransportExecution.view",
			        "targetControl" : "fioriContent", 
			        "targetAggregation" : "pages", 
			        "clearTarget" : false
			    },
			    routes : [ {
					pattern : "",
					name : "S1",
					view : "S1"
			    },
			    {
					pattern : "S2/{tripNo}",
					name : "S2",
					view : "S2"
			    },
			    {
					pattern : "S3",
					name : "S3",
					view : "S3"
			    }]
			}
		},
		createContent : function() {
	        var oViewData = {
	            component : this
	        };

	        return sap.ui.view({
	            viewName : "TransportExecution.view.Main",
	            type : sap.ui.core.mvc.ViewType.XML,
	            viewData : oViewData
	        });
	    },
		init : function(){
			var mConfig = this.getMetadata().getConfig();
			var oServiceConfig = mConfig.serviceConfig;
			var sServiceUrl = oServiceConfig.serviceUrl;
			var oRootPath = jQuery.sap.getModulePath("TransportExecution");
			this._initODataModel(sServiceUrl);
			var i18nModel = new ResourceModel({
				bundleUrl : [ oRootPath, mConfig.resourceBundle ].join("/")
			});
			this.setModel(i18nModel, "i18n");
			UIComponent.prototype.init.apply(this, arguments);
			this._routeMatchedHandler = new RouteMatchedHandler(this.getRouter(), this._bRouterCloseDialogs);
			this.getRouter().initialize();
			//sap.ui.core.AppCacheBuster.register("sap/bc/ui5_ui5/sap/zjio_trn_exe");
			//sap.ui.core.AppCacheBuster.handleURL = function(sURL) { return sURL !== "../zjio_trn_exe"; }; 
		},
		_initODataModel : function(sServiceUrl){
			var oModel = new ODataModel(sServiceUrl, true);
			oModel.setDefaultCountMode(sap.ui.model.odata.CountMode.None);
			this.setModel(oModel);
		}
	});
});