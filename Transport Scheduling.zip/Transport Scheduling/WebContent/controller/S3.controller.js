sap.ui.define([ 'sap/ui/core/mvc/Controller', 'sap/ui/core/UIComponent'],
				function(Controller, UIComponent) {
	"use strict";
	
	return Controller.extend("TransportExecution.controller.S3", {
		onInit : function() {			
			this.getRouter().attachRoutePatternMatched(this.onRouteMatched, this);
		},
		onRouteMatched : function(oEvent){
			if(oEvent.getParameter("name") === "S3"){
				this.byId("pdfId").setDownload(true);
          		this.byId("pdfId").setContent(TransportExecution.that.pdfFile);
			}
		},		
		navBack : function(){
			this.getRouter().navTo("S1");
		},
		getRouter : function(){
			return UIComponent.getRouterFor(this);
		}
	});
});