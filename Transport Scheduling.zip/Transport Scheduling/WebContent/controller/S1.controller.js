sap.ui.define([ 'sap/ui/core/mvc/Controller', 'sap/ui/core/UIComponent', 'sap/ui/model/json/JSONModel',
                'sap/custom/MessageHandling', 'sap/m/MessageToast', 'sap/m/MessageBox', 'sap/m/GroupHeaderListItem',
                'sap/m/ColumnListItem', 'sap/m/Text', 'sap/m/Link', 'sap/ui/model/Sorter', 'sap/m/Button',
                'sap/m/StandardListItem', 'TransportExecution/util/Formatter', 'sap/m/Column', 'sap/ui/core/Icon',
                'sap/m/Label', 'sap/m/DisplayListItem', 'sap/m/ResponsivePopover', 'sap/m/List', 'sap/m/Input',
                'sap/m/FlexBox', 'TransportExecution/controller/Filter', 'TransportExecution/controller/PrintCN',
                'sap/m/ObjectStatus', 'sap/m/Table', 'sap/m/IconTabFilter', 'sap/m/ScrollContainer',
                'sap/m/ActionSheet', 'sap/m/ObjectListItem', 'sap/m/ObjectAttribute', 'sap/m/CheckBox'],
                function(Controller, UIComponent, JSONModel, 
                		MessageHandling, MessageToast, MessageBox, GroupHeaderListItem,
                		ColumnListItem, Text, Link, Sorter, Button,
                		StandardListItem, Formatter, Column, Icon, 
                		Label, DisplayListItem, ResponsivePopover, List, Input,
                		FlexBox, Filter, PrintCN, 
                		ObjectStatus, Table, IconTabFilter, ScrollContainer,
                		ActionSheet, ObjectListItem, ObjectAttribute, CheckBox) {
	"use strict";

	return Controller.extend("TransportExecution.controller.S1", {
		onInit : function() {
			TransportExecution.that = this;
			this.oCore = sap.ui.getCore();
			this.pgExe = this.byId("pgExe");
			this.iTBDelvy = this.byId("iTBDelvy");			
			this.btnAddToTrip = this.byId("btnAddToTrip");
			this.btnCreateTrip = this.byId("btnCreateTrip");
			this.btnVRNChange = this.byId("btnVRNChange");
			this.btnAddVRN = this.byId("btnAddVRN");
			this.mPError = this.byId("mPError");
			this.btnFilter = this.byId("btnFilter");
			var colsPath = ((Formatter.getProxy() === "") ? "/sap/bc/ui5_ui5/sap/ZJIO_TRN_EXE/" : "") + "model/Columns.json";
			this.oColumnsModel = new JSONModel();
			this.oColumnsModel.loadData(colsPath, null, false);
			this.oModel = this.getOwnerComponent().getModel();
			this.oi18nModel = this.getOwnerComponent().getModel("i18n");
			this.oCore.setModel(this.oModel);
			this.oCore.setModel(this.oi18nModel, "i18n");
			this.getRouter().attachRoutePatternMatched(this.onRouteMatched, this);			
			this.initTableModel();
			this.oModel.attachRequestFailed(function(oError){
				var error = JSON.parse(oError.getParameter("responseText")).error.message.value;
				MessageToast.show(error);
			});
			if (sap.ui.Device.system.phone){
				this.byId("sFLocSearch").setVisible(false);
				this.byId("btnSearch").setVisible(true);
			}
			this.iTBDelvy.addEventDelegate({
				onAfterRendering : function(){
					TransportExecution.that.setScrollHeight();
					TransportExecution.that.showMsgPage("", "", false);
					var bFilterDateSelected = (TransportExecution.that.dRSDeliveryDate !== undefined && TransportExecution.that.dRSDeliveryDate.getDateValue() !== null && TransportExecution.that.dRSDeliveryDate.getSecondDateValue() !== null);
					TransportExecution.that.addRemoveFilterClass(3, bFilterDateSelected);
					if(typeof TransportScheduling !== "undefined" && TransportScheduling.that && TransportScheduling.that.bSetGroupedTabSelected){
						TransportScheduling.that.bSetGroupedTabSelected = undefined;
						TransportExecution.that.iTBDelvy.setSelectedKey("grouped");
					}
				}
			});
		},
		onAfterRendering : function(){
			var that = this;
			$(window).resize(function(){
				that.setScrollHeight();
			});
		},
		onRouteMatched : function(oEvent){

		},
		setScrollHeight : function(){
			var documentHeight = $(document).height();
			var footer = this.pgExe.getAggregation("footer");
			var footerHeight = (footer !== null) ? ($("#" + footer.sId).height()) : 39;//Get footer height			
			var height = documentHeight - footerHeight - ((Formatter.getProxy() === "") ? 205 : 160);
			var iTBItems = this.iTBDelvy.getItems();
			for(var i = 0; i < iTBItems.length; i++){
				var iTFContent = iTBItems[i].getContent();
				for(var j = 0; j < iTFContent.length; j++){
					if(iTFContent[j] instanceof ScrollContainer){
						iTFContent[j].setHeight(height + "px");
					}
				}
			}
		},
		initTableModel : function(){
			var that = this;			
			var sPath = "ExecutionListSet?$filter=Mode eq '" + Formatter.getMode() + "'@DateFilter";
			var fromDate, toDate;
			if(this.dRSDeliveryDate !== undefined && this.dRSDeliveryDate.getDateValue() !== null && this.dRSDeliveryDate.getSecondDateValue() !== null){
				fromDate = Formatter.getDate(this.dRSDeliveryDate.getDateValue());
				toDate = Formatter.getDate(this.dRSDeliveryDate.getSecondDateValue());
				this.addRemoveFilterClass(3, true);
				sPath = sPath.replace("@DateFilter", " and FromDate eq '" + fromDate + "' and ToDate eq '" + toDate + "'");
			}
			else{
				this.addRemoveFilterClass(3, false);
				sPath = sPath.replace("@DateFilter", "");				
			}
			Formatter.showLoader();
			this.oModel.read(sPath, {
				async : true,
				success : function(oData){					
					if(oData.results.length > 0){						
						var aOpenDelvy, aGrouped, aTripWOVRN, aCN;
						aOpenDelvy = [];
						aGrouped = [];
						aTripWOVRN = [];
						aCN = [];
						for(var i = 0; i < oData.results.length; i++){
							var dataItem = oData.results[i];
							var RefrenceNum=dataItem.RefrenceNum;
							var groupId = dataItem.GroupId;
							var tripNo = dataItem.TripNum;
							var vrnNo = dataItem.VRNNum;
							var shipType = dataItem.ShippingType;
							var shipDesc = dataItem.ShippingDesc;
							dataItem.GroupHeader = groupId + "/" + tripNo +  "/" + vrnNo + "/" + ((groupId !== "" || tripNo !== "" || vrnNo !== "") ? shipType : "") + "/" + ((groupId !== "" || tripNo !== "" || vrnNo !== "") ? shipDesc : "");
							if(groupId === "" && tripNo === "" && vrnNo === ""){
								aOpenDelvy.push(dataItem);
							}
							else if(groupId !== "" && tripNo === "" && vrnNo === ""){
								aGrouped.push(dataItem);
							}
							else if(tripNo !== "" && vrnNo === ""){
								aTripWOVRN.push(dataItem);
							}
							else if(tripNo !== "" && vrnNo !== ""){
								aCN.push(dataItem);
							}
						}

						var oITBData;
						oITBData = [];

						if(aOpenDelvy.length > 0){
							var oITF = {
									key : "open",
									header : that.oi18nModel.getProperty("iTF1Text"),
									mode : "MultiSelect",
									count : that.oi18nModel.getProperty("delivery") + aOpenDelvy.length,
									icon : "email-read",
									tabColumns : that.oColumnsModel.oData,
									tabItems : aOpenDelvy 
							};
							oITBData.push(oITF);
						}

						if(aGrouped.length > 0){
							var groups = aGrouped.map(function(obj){
								return obj.GroupId;
							});
							var distinctGroups = groups.filter(function(v, i){
								return groups.indexOf(v) == i && v !== "";
							});							
							var oITF = {
									key : "grouped",
									header : that.oi18nModel.getProperty("iTF2Text"),
									mode : "MultiSelect",
									count : that.oi18nModel.getProperty("groupId") + distinctGroups.length + ", " + that.oi18nModel.getProperty("delivery") + aGrouped.length,
									icon : "group-2",
									tabColumns : that.oColumnsModel.oData,
									tabItems : aGrouped 
							};
							oITBData.push(oITF);
						}

						if(aTripWOVRN.length > 0){
							var trips = aTripWOVRN.map(function(obj){
								return obj.TripNum;
							});
							var distinctTrips = trips.filter(function(v, i){
								return trips.indexOf(v) == i  && v !== "";
							});							
							var oITF = {
									key : "trip",
									header : that.oi18nModel.getProperty("iTF3Text"),
									mode : "MultiSelect",
									count : that.oi18nModel.getProperty("tripNo") + distinctTrips.length + ", " + that.oi18nModel.getProperty("delivery") + aTripWOVRN.length,
									icon : "suitcase",
									tabColumns : that.oColumnsModel.oData,
									tabItems : aTripWOVRN 
							};
							oITBData.push(oITF);
						}
						if(aCN.length > 0){
							var VRNs = aCN.map(function(obj){
								return obj.VRNNum;
							});
							var distinctVRNs = VRNs.filter(function(v, i){
								return VRNs.indexOf(v) == i  && v !== "";
							});						
							var oITF = {
									key : "cn",
									header : that.oi18nModel.getProperty("iTF4Text"),
									mode : "None",
									count : that.oi18nModel.getProperty("vrnNo") + distinctVRNs.length + ", " + that.oi18nModel.getProperty("delivery") + aCN.length,
									icon : "notes",
									tabColumns : that.oColumnsModel.oData,
									tabItems : aCN 
							};
							oITBData.push(oITF);
						}
						that.iTBDelvy.setVisible(true);
						that.bindITB(oITBData);						
						TransportExecution.that.fnFilterCallBack(true);//true for not allowing local search for ship type when only date changed
					}
					else{
						Formatter.hideLoader();
						that.bindITB([]);
						that.showMsgPage(that.oi18nModel.getProperty("msgNoDataFound"), "", true);
					}
				},
				error : function(oError){
					Formatter.hideLoader();
					var msg = "";
					try{
						msg = JSON.parse(oError.response.body).error.message.value;
					}
					catch(err){
						msg = oError.response.body;
					}				
					that.showMsgPage(msg, "", true);
				}
			});			
		},
		bindITB : function(oITBData){
			var oTempModel = new JSONModel(oITBData);
			this.iTBDelvy.setModel(oTempModel);
			this.iTBDelvy.bindAggregation("items", {
				path : "/",
				template : new IconTabFilter({
					design : "Horizontal",
					key : "{key}",
					icon : "sap-icon://{icon}",
					count : "{header}",
					text : "{count}",
					content : this.getITFContent()
				})	
			});
		},
		showMsgPage : function(text, desc, bVisible){
			this.mPError.setText(text);
			this.mPError.setDescription(desc);
			this.mPError.setVisible(bVisible);
			if(this.iTBDelvy.getItems().length > 0){
				this.setButtonsVisibility(this.iTBDelvy.getSelectedKey());
			}
			else{
				this.btnAddToTrip.setVisible(!bVisible);
				this.btnCreateTrip.setVisible(!bVisible);
				this.btnAddVRN.setVisible(!bVisible);
				this.btnVRNChange.setVisible(!bVisible);				
				this.iTBDelvy.setVisible(!bVisible);
			}			
		},
		getITFContent : function(){
			var tblDelvyH = new Table({
				mode : "{mode}",
				selectionChange : this.sTblGroupH,
				columns : {
					path : "tabColumns",
					template : new Column({
						hAlign : "{hAlign}",
						vAlign : "{vAlign}",
						width : "{width}",
						demandPopin : "{demandPopin}",
						minScreenWidth : "{minScreenWidth}",
						header : new Label({
							text : "{ColumnName}",
							design : "Bold"
						})
					})
				},				
				items : [
				         new ColumnListItem({
				        	 visible : false				         		
				         })
				         ]
			});			

			var tblDelvy = new Table({
				mode : "{mode}",
				selectionChange : this.sTblGroup,
				growing : true,
				growingThreshold : 10000,
				growingScrollToLoad : false,
				columns : {
					path : "tabColumns",
					template : new Column({
						hAlign : "{hAlign}",
						vAlign : "{vAlign}",
						width : "{width}",
						demandPopin : "{demandPopin}",
						minScreenWidth : "{minScreenWidth}"
					})
				},
				items : {
					path : "tabItems",
					sorter : [ new Sorter({
						path : "GroupHeader",
						descending : false,
						group : true
					}), new Sorter({
						path : "ShippingType",
						descending : true,
						group : false
					}), new Sorter({
						path : "ShipToPartyId",
						descending : false,
						group : false
					}) ],
					groupHeaderFactory : function(oGroup){
						var group = oGroup.key.split('/');
						var groupId = group[0];
						var tripNo = group[1];
						var vrnNo = group[2];
						var shipType = group[3];
						var shipDesc = group[4];
						var dispGroupId = (groupId === "") ? "" : TransportExecution.that.oi18nModel.getProperty("groupId") + parseInt(groupId).toString();						
						var dispTripNo = (tripNo === "") ? "" : TransportExecution.that.oi18nModel.getProperty("tripNo") + parseInt(tripNo).toString();
						var dispVRNNo = (vrnNo === "") ? "" : TransportExecution.that.oi18nModel.getProperty("vrnNo") + parseInt(vrnNo).toString();
						var tabGroupHeadItem = new ColumnListItem({
							visible : (oGroup.key !== "////"),
							cells:[							       
							       new FlexBox({
							    	   alignItems : "Center",
							    	   justifyContent : "Start",
							    	   items : [													
							    	            new Icon({
							    	            	src : "sap-icon://navigation-right-arrow",
							    	            	press : TransportExecution.that.pGroupHeader,
							    	            	color : "#666666"	
							    	            }).addStyleClass("sapUiTinyMarginEnd"),
							    	            new Icon({
							    	            	src : Formatter.getShipTypeIcon(shipType),
							    	            	color : Formatter.getShipTypeIconColor(shipType),
							    	            	tooltip : shipDesc
							    	            }).addStyleClass("sapUiTinyMarginEnd"),
							    	            new Label({
							    	            	text : (dispGroupId + " " + dispTripNo).trim(),
							    	            	design : "Bold"
							    	            }).addStyleClass("sapUiSmallMarginEnd"),
							    	            new Label({
							    	            	text : dispVRNNo.trim(),
							    	            	design : "Bold"
							    	            })
							    	            ]
							       }),
							       new Text(),
							       new Text(),				       	
							       new Text(),
							       new Text(),
							       new Button({
							    	   type: (groupId !== "") ? "Accept" : (vrnNo !== "") ? "Accept" : (tripNo !== "") ? "Emphasized" : "Default",
							    			   icon: "sap-icon://" + ((groupId !== "") ? "suitcase" : (vrnNo !== "") ? "notes" : (tripNo !== "") ? "travel-itinerary" : "Default"),
							    			   tooltip: (groupId !== "") ? TransportExecution.that.oi18nModel.getProperty("createTripTT") : (vrnNo !== "") ? TransportExecution.that.oi18nModel.getProperty("createCNTT") : (tripNo !== "") ? TransportExecution.that.oi18nModel.getProperty("addVRNTT") : TransportExecution.that.oi18nModel.getProperty("addToTripTT"),
							    					   visible: (groupId !== "") || (vrnNo !== "" && Formatter.getValidCNShipTypes().indexOf(shipType) > -1) || (tripNo !== "" && vrnNo === ""),
							    					   press : [(groupId !== "") ? TransportExecution.that.pCreateTrip : (vrnNo !== "") ? TransportExecution.that.pCreateCN : (tripNo !== "") ? TransportExecution.that.pAddVRN : TransportExecution.that.pAddToTrip, TransportExecution.that]
							       }),							       	
							       new Icon({
							    	   src : "sap-icon://delete",
							    	   color : "red",
							    	   tooltip : TransportExecution.that.oi18nModel.getProperty("delTripTT"),
							    	   visible : (tripNo !== "" && vrnNo === ""),
							    	   press : [TransportExecution.that.pDelDelvy, TransportExecution.that]
							       })
							       ]
						}).addStyleClass("GroupHeader");

						tabGroupHeadItem.addEventDelegate({
							onAfterRendering : function(oEvent){
								var currItem = oEvent.srcControl;
								var oContext = currItem.getBindingContext().getObject();
								if(oContext.GroupHeader === undefined){
									var table = currItem.getParent();
									var items = table.getItems();
									var currItemIndex = table.indexOfItem(currItem);
									oContext = items[currItemIndex + 1].getBindingContext().getObject();
									if((oContext.GroupId !== "" || (oContext.TripNum !== "" && oContext.VRNNum  === "")) && Formatter.getValidCreateTripShipTypes().indexOf(oContext.ShippingType) === -1){
										currItem.$().find(".sapMCb").removeClass("sapMPointer");
										currItem.$().find(".sapMCbBg ").css("display", "none");
									}
								}								
							}
						});

						return tabGroupHeadItem;
					},
					factory : function(sId, oContext){
						var tabItem = new ColumnListItem({
							visible : "{path: 'GroupHeader', formatter: 'TransportExecution.util.Formatter.getColumnVisible'}",//Hide Group's Child Items Initially
							cells:[								
							       new FlexBox({
							    	   alignItems : "Center",
							    	   justifyContent : "Start",
							    	   items : [												
							    	            new Text({
							    	            	visible :"{path: 'GroupHeader', formatter: 'TransportExecution.util.Formatter.getShipTypeVisibility'}"
							    	            }).addStyleClass("sapUiLargeMarginEnd"),
							    	            new Icon({
							    	            	src : "{path:'ShippingType', formatter:'TransportExecution.util.Formatter.getShipTypeIcon'}",
							    	            	tooltip : "{ShippingDesc}",
							    	            	color : "{path:'ShippingType', formatter:'TransportExecution.util.Formatter.getShipTypeIconColor'}",
							    	            	visible :"{path: 'GroupHeader', formatter: 'TransportExecution.util.Formatter.getColumnVisible'}"
							    	            }).addStyleClass("sapUiSmallMarginEnd"),
							    	            new Icon({
							    	            	src : "{path:'Status', formatter:'TransportExecution.util.Formatter.getStatusIcon'}",
							    	            	color : "{path:'Status', formatter:'TransportExecution.util.Formatter.getStatusColor'}",							
							    	            	tooltip :"{path:'Status', formatter:'TransportExecution.util.Formatter.getStatusTooltip'}",
							    	            	size : "0.9rem",
							    	            	press : TransportExecution.that.pRemarks
							    	            }).addStyleClass("sapUiTinyMarginEnd"),
							    	            new ObjectStatus({
							    	            	text : "{ShipToPartyName} ({ShipToPartyId})",
							    	            	state : "{path:'Status', formatter:'TransportExecution.util.Formatter.getObjectStatus'}"
							    	            })
							    	            ]
							       }),					
							       new ObjectStatus({
							    	   text : "{SystemId}",
							    	   state : "{path:'Status', formatter:'TransportExecution.util.Formatter.getObjectStatus'}"
							       }),					
							       new ObjectStatus({
							    	   text : "{DeliveryNum}",
							    	   state : "{path:'Status', formatter:'TransportExecution.util.Formatter.getObjectStatus'}"
							       }),
							       new ObjectStatus({
							    	   text:"{path: 'ConfirmDate', formatter: 'TransportExecution.util.Formatter.getDateFormatted'}",
							    	   state : "{path:'Status', formatter:'TransportExecution.util.Formatter.getObjectStatus'}"
							       }),
							       new ObjectStatus({
							    	   text : "{InvoiceNum}",
							    	   state : "{path:'Status', formatter:'TransportExecution.util.Formatter.getObjectStatus'}"
							       }),
							       new Button({
							    	   type : "Accept",
							    	   icon : "sap-icon://suitcase",
							    	   tooltip : TransportExecution.that.oi18nModel.getProperty("createTripTT"),
							    	   visible : "{parts : [{path:'GroupId'}, {path:'TripNum'}, {path:'VRNNum'}], formatter:'TransportExecution.util.Formatter.getCreateTripVisibility'}",
							    	   press : [TransportExecution.that.pCreateTrip, TransportExecution.that]
							       }),								
							       new Icon({
							    	   src : "sap-icon://sys-cancel",
							    	   color : "red",
							    	   tooltip : TransportExecution.that.oi18nModel.getProperty("remDelTT"),
							    	   visible : "{path:'TripNum', formatter:'TransportExecution.util.Formatter.getTripAssigned'}",
							    	   press : [TransportExecution.that.pDelDelvy, TransportExecution.that]
							       })
							       ]
						});
						tabItem.addEventDelegate({
							onAfterRendering : function(oEvent){
								var currItem = oEvent.srcControl;
								var oContext = currItem.getBindingContext().getObject();
								if(oContext.GroupId !== "" || (oContext.TripNum !== "" && oContext.VRNNum  === "")){
									currItem.$().find(".sapMCb").removeClass("sapMPointer");
									currItem.$().find(".sapMCbBg ").css("display", "none");
								}
							}
						});
						return tabItem;
					}					
				}
			});

			tblDelvy.addEventDelegate({
				onAfterRendering : function(){
					Formatter.hideLoader();
				}
			});

			var scrlContDelvy = new ScrollContainer({
				height : "100%",
				width : "100%",
				vertical : true,
				content : [ tblDelvy ]
			});

			return [ tblDelvyH, scrlContDelvy ];
		},
		pGroupHeader : function(oEvent){
			var icon = oEvent.getSource();			
			var currItem = icon.getParent().getParent();
			var table = currItem.getParent();
			var items = table.getItems();
			var currItemIndex = table.indexOfItem(currItem);
			var colVisible;
			if(icon.getSrc().indexOf("right") > -1){
				icon.setSrc("sap-icon://navigation-down-arrow");
				colVisible = true;
			}
			else{
				icon.setSrc("sap-icon://navigation-right-arrow");
				colVisible = false;
			}
			for(var i = currItemIndex + 1; i < items.length && items[i].getBindingContext().getObject().GroupHeader !== undefined; i++){				
				items[i].setVisible(colVisible);
			}
		},		
		sDelvy : function(oEvent){
			var key = oEvent.getParameter("selectedKey");
			this.setButtonsVisibility(key);
		},
		setButtonsVisibility : function(key){
			this.btnAddToTrip.setVisible(key === "open");
			this.btnCreateTrip.setVisible(key === "open"|| key === "grouped");
			this.btnAddVRN.setVisible(key === "trip");			
		},
		pRemarks : function(oEvent){
			var icon = oEvent.getSource();
			var currItem = icon.getParent();
			var remarks = currItem.getBindingContext().getProperty("StatusDesc");			
			var rPRemarks = new ResponsivePopover({
				showHeader : false,
				placement : "Right",				
				content : [
				           new Text({
				        	   text : remarks
				           }).addStyleClass("sapUiSmallMarginBeginEnd sapUiSmallMarginTopBottom")
				           ]
			});
			rPRemarks.openBy(icon);
		},
		getTable : function(key){
			var table = "";
			var iTBItems = this.iTBDelvy.getItems();
			for(var i = 0; i < iTBItems.length; i++){
				if(iTBItems[i].getKey() === key){
					var content = iTBItems[i].getContent();
					for(var j = 0; j < content.length; j++){
						if(content[j] instanceof ScrollContainer){
							table = content[j].getContent()[0];						
						}
					}
				}				
			}
			return table;
		},
		pAddToTrip : function(oEvent){
			var table = this.getTable("open");
			if(table !== ""){				
				var selItems = table.getSelectedItems();
				var selItemsLen = selItems.length;				
				if(selItemsLen > 0){
					var shipType = "";
					var shipDesc = "";
					var shipToParty = "";
					var systemId = "";
					var bShipTypeSame = true;
					var bShipToPartySame = true;
					var bSystemIdSame = true;
					var aShipTypes = Formatter.getValidSameSTPShipTypes();
					for(var i = 0; i < selItemsLen; i++){
						var oContext = selItems[i].getBindingContext().getObject(); 
						if(oContext.GroupHeader !== undefined){
							if(shipType === ""){
								shipType = oContext.ShippingType;
								shipDesc = oContext.ShippingDesc;
							}
							else if(oContext.ShippingType !== shipType){
								bShipTypeSame = false;
							}							
							if(aShipTypes.indexOf(shipType) > -1){
								if(shipToParty === ""){
									shipToParty = oContext.ShipToPartyId;
								}
								else if(oContext.ShipToPartyId !== shipToParty){
									bShipToPartySame = false;
								}
								if(systemId === ""){
									systemId = oContext.SystemId;
								}
								else if(oContext.SystemId !== systemId){
									bSystemIdSame = false;
								}
							}							
						}
					}
					if(bShipTypeSame && bShipToPartySame && bSystemIdSame){
						if(!this.dlgTripsList){
							this.dlgTripsList = sap.ui.xmlfragment("TransportExecution.fragment.TripsList", this);
						}

						var oModel = this.iTBDelvy.getModel();
						var aITBData;
						aITBData = [];
						for(var i = 0; i < oModel.oData.length; i++){
							if(oModel.oData[i].key === "trip" || oModel.oData[i].key === "cn"){
								aITBData.push(oModel.oData[i]);
							}
						}
						var colsPath = ((Formatter.getProxy() === "") ? "/sap/bc/ui5_ui5/sap/ZJIO_TRN_EXE/" : "") + "model/PopupColumns.json";
						var oColumnsModel = new JSONModel();
						oColumnsModel.loadData(colsPath, null, false);
						for(var i = 0; i < aITBData.length; i++){
							var aTripsData;
							aTripsData = [];
							for(var j = 0; j < aITBData[i].tabItems.length; j++){
								if(aITBData[i].tabItems[j].ShippingType === shipType){
									if(aShipTypes.indexOf(shipType) === -1 || (aShipTypes.indexOf(shipType) > -1 && 
											aITBData[i].tabItems[j].ShipToPartyId === shipToParty &&
											aITBData[i].tabItems[j].SystemId === systemId)){
										aTripsData.push(aITBData[i].tabItems[j]);
									}
								}
							}							
							var trips = aTripsData.map(function(obj){
								return obj.TripNum;
							});
							var distinctTrips = trips.filter(function(v, i){
								return trips.indexOf(v) == i  && v !== "";
							});
							aITBData[i].mode = "MultiSelect";
							aITBData[i].count = this.oi18nModel.getProperty("tripNo") + distinctTrips.length + ", " + this.oi18nModel.getProperty("delivery") + aTripsData.length;
							aITBData[i].listItems = aTripsData;
							aITBData[i].listColumns = oColumnsModel.oData;
						}
						this.oCore.byId("iconTripsShipType").setSrc(Formatter.getShipTypeIcon(shipType));
						this.oCore.byId("iconTripsShipType").setColor(Formatter.getShipTypeIconColor(shipType));
						this.oCore.byId("titTrips").setText(shipDesc + " Trips");
						var oTripsModel = new JSONModel(aITBData);
						this.oCore.byId("iTBTrips").setModel(oTripsModel);

						this.oCore.byId("iTBTrips").bindAggregation("items", {
							path : "/",
							template : new IconTabFilter({
								design : "Horizontal",
								key : "{key}",
								icon : "sap-icon://{icon}",
								count : "{header}",
								text : "{count}",
								content : [ this.getPopupITFContent() ]
							})
						});
						var iTBItems = this.oCore.byId("iTBTrips").getItems();
						for(var i = 0; i < iTBItems.length; i++){
							var iTFContent = iTBItems[i].getContent();
							for(var j = 0; j < iTFContent.length; j++){
								if(iTFContent[j] instanceof ScrollContainer){
									iTFContent[j].setHeight("330px");
								}
							}
						}
						this.dlgTripsList.open();
					}
					else if(!bShipTypeSame){
						MessageToast.show(this.oi18nModel.getProperty("msgSameShipType"));
					}
					else if(!bShipToPartySame){
						MessageToast.show(this.oi18nModel.getProperty("msgSameSTP"));
					}
					else if(!bSystemIdSame){
						MessageToast.show(this.oi18nModel.getProperty("msgSameSysID"));
					}
				}
				else{
					MessageToast.show(this.oi18nModel.getProperty("msgAddToTrip"));
				}
			}
			else{
				MessageToast.show(this.oi18nModel.getProperty("msgNoItems"));
			}
		},
		getPopupITFContent : function(){			
			var tblDelvyH = new Table({
				mode : "{mode}",
				selectionChange : this.sTblGroupH,
				columns : {
					path : "listColumns",
					template : new Column({
						hAlign : "{hAlign}",
						vAlign : "{vAlign}",
						width : "{width}",
						demandPopin : "{demandPopin}",
						minScreenWidth : "{minScreenWidth}",
						header : new Label({
							text : "{ColumnName}",
							design : "Bold"
						})
					})
				},
				items : [
				         new ColumnListItem({
				        	 visible : false				         		
				         })
				         ]
			});			

			var tblDelvy = new Table({
				mode : "{mode}",
				selectionChange : this.sTblGroup,
				growing : true,
				growingThreshold : 10000,
				growingScrollToLoad : false,
				columns : {
					path : "listColumns",
					template : new Column({
						hAlign : "{hAlign}",
						vAlign : "{vAlign}",
						width : "{width}",
						demandPopin : "{demandPopin}",
						minScreenWidth : "{minScreenWidth}"
					})
				},								
				items : {
					path : "listItems",
					sorter : new Sorter({
						path : "GroupHeader",
						descending : false,
						group : true
					}),
					groupHeaderFactory : function(oGroup){
						var group = oGroup.key.split('/');
						var groupId = group[0];
						var tripNo = group[1];
						var vrnNo = group[2];
						var dispGroupId = (groupId === "") ? "" : TransportExecution.that.oi18nModel.getProperty("groupId") + parseInt(groupId).toString();						
						var dispTripNo = (tripNo === "") ? "" : TransportExecution.that.oi18nModel.getProperty("tripNo") + parseInt(tripNo).toString();
						var dispVRNNo = (vrnNo === "") ? "" : TransportExecution.that.oi18nModel.getProperty("vrnNo") + parseInt(vrnNo).toString();
						var tabGroupHeadItem = new ColumnListItem({
							visible : (oGroup.key !== "//"),
							cells:[									
							       new FlexBox({
							    	   alignItems : "Center",
							    	   justifyContent : "Start",
							    	   items : [
							    	            new Label({
							    	            	text : (dispGroupId + " " + dispTripNo).trim(),
							    	            	design : "Bold"
							    	            }).addStyleClass("sapUiSmallMarginEnd"),
							    	            new Label({
							    	            	text : dispVRNNo.trim(),
							    	            	design : "Bold"
							    	            })
							    	            ]
							       }),
							       new Text(),
							       new Text(),				       	
							       new Text(),
							       new Text()							       	
							       ]
						}).addStyleClass("GroupHeader");

						return tabGroupHeadItem;
					},
					factory : function(sId, oContext){
						var tabItem = new ColumnListItem({
							cells:[							    
							       new FlexBox({
							    	   alignItems : "Center",
							    	   justifyContent : "Start",
							    	   items : [												
							    	            new Icon({
							    	            	src : "{path:'Status', formatter:'TransportExecution.util.Formatter.getStatusIcon'}",
							    	            	color : "{path:'Status', formatter:'TransportExecution.util.Formatter.getStatusColor'}",							
							    	            	tooltip :"{path:'Status', formatter:'TransportExecution.util.Formatter.getStatusTooltip'}",
							    	            	size : "0.9rem",
							    	            	press : TransportExecution.that.pRemarks
							    	            }).addStyleClass("sapUiTinyMarginEnd"),
							    	            new ObjectStatus({
							    	            	text : "{ShipToPartyName} ({ShipToPartyId})",
							    	            	state : "{path:'Status', formatter:'TransportExecution.util.Formatter.getObjectStatus'}"
							    	            })
							    	            ]
							       }),					
							       new ObjectStatus({
							    	   text : "{SystemId}",
							    	   state : "{path:'Status', formatter:'TransportExecution.util.Formatter.getObjectStatus'}"
							       }),					
							       new ObjectStatus({
							    	   text : "{DeliveryNum}",
							    	   state : "{path:'Status', formatter:'TransportExecution.util.Formatter.getObjectStatus'}"
							       }),								
							       new ObjectStatus({
							    	   text : "{InvoiceNum}",
							    	   state : "{path:'Status', formatter:'TransportExecution.util.Formatter.getObjectStatus'}"
							       })
							       ]
						});
						tabItem.addEventDelegate({
							onAfterRendering : function(oEvent){
								var currItem = oEvent.srcControl;
								currItem.$().find(".sapMCbBg").css("display", "none");
							}
						});
						return tabItem;
					}
				}
			});			

			var scrlContDelvy = new ScrollContainer({
				height : "100%",
				width : "100%",
				vertical : true,
				content : [ tblDelvy ]
			});
			return [ tblDelvyH, scrlContDelvy ];
		},		
		pTripsListCancel : function(oEvent){
			var dialog = oEvent.getSource().getParent();
			dialog.close();
		},
		pTripsListSubmit : function(){
			var tripNo = "",
			bSameTrip = true,
			iTBItems = this.oCore.byId("iTBTrips").getItems();
			for(var i = 0; i < iTBItems.length; i++){
				var iTFContent = iTBItems[i].getContent();
				for(var j = 0; j < iTFContent.length; j++){
					if(iTFContent[j] instanceof ScrollContainer){
						var table = iTFContent[j].getContent()[0],
						selItems = table.getSelectedItems(),
						selItemsLen = selItems.length;
						for(var k = 0; k < selItemsLen; k++){
							var oContext = selItems[k].getBindingContext().getObject();
							if(oContext.GroupHeader !== undefined){
								if(tripNo === ""){
									tripNo = oContext.TripNum;
								}
								else if(tripNo !== oContext.TripNum){
									bSameTrip = false;
								}
							}							
						}
					}
				}
			}
			if(bSameTrip && tripNo !== ""){
				this.getRouter().navTo("S2", {
					tripNo : tripNo
				});
			}
			else if(tripNo === ""){
				MessageToast.show("Select some trip");
			}
			else{
				MessageToast.show("Select only one Trip");
			}	
		},
		fnShowVehicles : function(that, shipType, shipDesc){
			if(!that.dlgVehicles){
				that.dlgVehicles = sap.ui.xmlfragment("TransportExecution.fragment.Vehicles", that);
			}
			var objListItem = new ObjectListItem({
				title : "{path:'Vehiclenum', formatter:'TransportExecution.util.Formatter.getVehicleNum'}",
				type : "{path:'Status', formatter:'TransportExecution.util.Formatter.getListType'}",					
				number : "{VRNNum}",
				numberUnit : "{FleetType}",
				numberState : "{path:'Status', formatter:'TransportExecution.util.Formatter.getInfoState'}",
				attributes : [
				              new ObjectAttribute({
				            	  text : "{parts:[{path: 'TransportName'},{path: 'Vendor'}],formatter:'TransportExecution.util.Formatter.getVendorName'}"
				              })
				              ],
				              press : [ that.cnVehicles, that ]
			});
			objListItem.addEventDelegate({
				onAfterRendering : function(oEvent){
					var item = oEvent.srcControl;
					var status = item.getBindingContext().getProperty("Status");
					item.$().find(".sapMObjLTitle").css("color", Formatter.getStatusColor(status));
					item.$().find(".sapMObjLAttrDiv").css("color", Formatter.getStatusColor(status));
					item.$().find(".sapMObjLNumber").css("font-size", "1.125rem");
				}
			});
			if(shipType !== "" && shipDesc !== ""){
				that.oCore.byId("iconShipType").setSrc(Formatter.getShipTypeIcon(shipType));
				that.oCore.byId("iconShipType").setColor(Formatter.getShipTypeIconColor(shipType));
				that.oCore.byId("titShipType").setText(shipDesc);
			}			

			var path = "VRNListSet";
			Formatter.showLoader();
			that.oModel.read(path,{
				async : true,
				success : function(oData){
					Formatter.hideLoader();
					var oVehModel = new JSONModel(oData.results);
					TransportExecution.that.dlgVehicles.setModel(oVehModel);
					TransportExecution.that.oCore.byId("lstVehicles").bindAggregation("items",{
						path : "/",
						template : objListItem,
						filters : [ new sap.ui.model.Filter("VehicleTyp", sap.ui.model.FilterOperator.EQ, shipType) ]							
					});
					TransportExecution.that.dlgVehicles.open();
				},
				error : function(oError){
					Formatter.hideLoader();
					var msg = JSON.parse(oError.response.body).error.message.value;
					MessageToast.show(msg);
				}
			});
		},
		pAddVRN : function(oEvent){
			this.bCreateTrip = false;
			var shipType = "";
			var shipDesc = "";
			this.btnVRN = oEvent.getSource();
			var currItem = this.btnVRN.getParent();
			if(currItem instanceof ColumnListItem){
				var oContext = currItem.getBindingContext().getObject();
				if(oContext.GroupHeader === undefined){
					var table = currItem.getParent();
					var items = table.getItems();
					var currItemIndex = table.indexOfItem(currItem);
					oContext = items[currItemIndex + 1].getBindingContext().getObject();
					shipType = oContext.ShippingType;
					shipDesc = oContext.ShippingDesc;
					this.Site = oContext.Site1;
					this.fnShowVehicles(this, shipType, shipDesc);
				}
			}
			else{
				var bSameShipType = true;
				var count = 0;
				var table = this.getTable("trip");
				if(table !== ""){
					var selItems = table.getSelectedItems();
					var selItemsLen = selItems.length;
					for(var i = 0; i < selItemsLen; i++){
						var oContext = selItems[i].getBindingContext().getObject();					
						if(oContext.GroupHeader === undefined){
							count++;
							var currShipType = selItems[i + 1].getBindingContext().getObject().ShippingType;
							var currShipDesc = selItems[i + 1].getBindingContext().getObject().ShippingDesc;
							var currSite = selItems[i + 1].getBindingContext().getObject().Site1;
							if(shipType === ""){
								shipType = currShipType;
								shipDesc = currShipDesc;
								this.Site = currSite;
							}
							else if(shipType !== currShipType){
								bSameShipType = false;
							}
						}
					}				
					if(count > 0){
						if(bSameShipType){
							if(Formatter.getValidSameSTPShipTypes().indexOf(shipType) > -1 || count === 1){
								this.fnShowVehicles(this, shipType, shipDesc);
							}
							else{
								MessageToast.show(this.oi18nModel.getProperty("msgAddVRNToTrip"));
							}
						}
						else{
							MessageToast.show(this.oi18nModel.getProperty("msgTripsSameShipType"));
						}
					}
					else{
						MessageToast.show(this.oi18nModel.getProperty("msgSelectTrip"));					
					}
				}
				else{
					MessageToast.show(this.oi18nModel.getProperty("msgNoItems"));					
				}
			}				
		},
		lCVehicles : function(oEvent){
			var searchVal = oEvent.getSource().getValue().toLowerCase();
			var items = this.oCore.byId("lstVehicles").getItems();
			var itemsLen = items.length;
			for(var i = 0; i < itemsLen; i++){
				var title = items[i].getTitle().toLowerCase();
				var num = items[i].getNumber().toLowerCase();
				var attr = items[i].getAttributes()[0].getText().toLowerCase();
				if(title.indexOf(searchVal) > -1 || num.indexOf(searchVal) > -1 || attr.indexOf(searchVal) > -1){
					items[i].setVisible(true);
				}
				else{
					items[i].setVisible(false);
				}
			}
		},
		cnVehicles : function(oEvent){
			var that = this;
			this.oContextVehicle = oEvent.getSource().getBindingContext().getObject();			
			if(this.oContextVehicle.Status === "2" || this.oContextVehicle.Status === "3"){
				MessageBox.show(this.oi18nModel.getProperty("msgAddVRN"),{
					title : "Confirmation",
					icon: MessageBox.Icon.QUESTION,
					actions : ['Yes', 'No'],
					onClose : function(oAction){
						if(oAction === "Yes"){
							if(that.bCreateTrip){
								that.pCreateTripWOVRN();
							}
							else{
								if(that.oContextVehicle.FleetType.toLowerCase() === "dedicated vehicle"){
									if(!that.dlgSite){
										that.dlgSite = sap.ui.xmlfragment("TransportExecution.fragment.Site", that);
										that.inpSite = that.oCore.byId("inpLastLoc");										
									}
									that.inpSite.setValue(that.Site);
									that.dlgSite.open();
								}
								else{
									that.fnAddVRNToTrip();
								}

							}
							that.dlgVehicles.close();
						}
					}
				});				
			}
			else{				
				MessageBox.show(this.oi18nModel.getProperty("msgGoToVRNChange"),{
					title : "Confirmation",
					icon: MessageBox.Icon.QUESTION,
					actions : ['Yes', 'No'],
					onClose : function(oAction){
						if(oAction === "Yes"){
							that.VRNChange_VRNNum = that.oContextVehicle.VRNNum;
							that.pVRNChange();
						}
					}
				});
			}
		},
		vHRLocs : function(oEvent){
			var path = "/SiteF4Set?$filter=Site eq '" + this.inpSite.getValue().toUpperCase() + "'";
			if(!this.dlgSites){
				this.dlgSites = sap.ui.xmlfragment("TransportExecution.fragment.Sites", this);				
			};
			this.dlgSites.bindAggregation("items", path, new StandardListItem({
				title : "{FirstName}",
				description : "{LastName}",
				type : "Active",
				info : "{Site}"
			}));
			this.dlgSites.open();
		},
		lCLastLoc : function(oEvent){
			var inpNo = oEvent.getSource();
			inpNo.setValue(inpNo.getValue().toUpperCase());
		},
		sSite : function(oEvent){
			var searchVal = oEvent.getParameter("value").toLowerCase();
			var items = this.dlgSites.getItems();
			var itemsLen = items.length;
			for(var i = 0; i < itemsLen; i++){
				var title = items[i].getTitle().toLowerCase();
				var desc = items[i].getDescription().toLowerCase();
				var info = items[i].getInfo().toLowerCase();
				if(title.indexOf(searchVal) > -1 || desc.indexOf(searchVal) > -1 || info.indexOf(searchVal) > -1){
					items[i].setVisible(true);
				}
				else{
					items[i].setVisible(false);
				}
			}
		},		
		cSite : function(oEvent){
			this.Site = oEvent.getParameter("selectedItem").getBindingContext().getObject().Site;
			this.inpSite.setValue(this.Site);			
		},
		pSiteCancel : function(){
			this.dlgSite.close();
		},
		pSiteSubmit : function(){
			if(this.Site !== undefined){
				var that = this;
				var sSiteVal = this.inpSite.getValue().toUpperCase();
				var sPath = "/SiteF4Set?$filter=Site eq '" + sSiteVal + "'";
				Formatter.showLoader();
				this.oModel.read(sPath, {
					async : true,
					success : function(oData, oResponse){
						Formatter.hideLoader();
						var aSite = oData.results.filter(function(ele){
							return (ele.Site === sSiteVal);
						});
						if(aSite.length > 0){
							that.inpSite.setValueState("None");
							that.inpSite.setValueStateText("");
							that.Site = sSiteVal;
							that.fnAddVRNToTrip();
							that.dlgSite.close();
						}
						else{
							that.inpSite.setValueState("Error");
							that.inpSite.setValueStateText(that.oi18nModel.getProperty("msgSiteInvalid"));
							MessageToast.show(that.oi18nModel.getProperty("msgSiteInvalid"));
						}
					},
					error : function(oError){
						Formatter.hideLoader();
						that.inpSite.setValueState("Error");
						that.inpSite.setValueStateText(that.oi18nModel.getProperty("msgSiteInvalid"));
						MessageToast.show(that.oi18nModel.getProperty("msgSiteInvalid"));
					}
				});
			}			
		},
		pCancel : function(oEvent){
			this.dlgVehicles.close();
		},
		fnItemNav : function(oContext){
			var oItemNav = {
					Status : oContext.Status,							
					TripNum : oContext.TripNum,							
					VRNNum : oContext.VRNNum,
					CNNum : oContext.CNNum,
					OrderNum : oContext.OrderNum,
					OrdItemNum : oContext.OrdItemNum,
					DeliveryNum : oContext.DeliveryNum,
					DelItemNum : oContext.DelItemNum,
					ItemCatgry : oContext.ItemCatgry,
					OrderQty : oContext.OrderQty,
					ShippingType : oContext.ShippingType,
					DeliveryDate : Formatter.getDate1(oContext.DeliveryDate),
					ConfirmDate : Formatter.getDate1(oContext.ConfirmDate),
					Destination : oContext.Destination,
					VendorNum : oContext.VendorNum,
					SystemId : oContext.SystemId,
					UoM : oContext.UoM,
					Type : oContext.Type,
					GroupId : oContext.GroupId,
					TimeStamp : oContext.TimeStamp,
					ArticleDesc : oContext.ArticleDesc,
					StageSeq : oContext.StageSeq,
					Site : oContext.Site,
					ShippingPoint : oContext.ShippingPoint,
					ShipToPartyId : oContext.ShipToPartyId,
					Site1 : oContext.Site1,
					Route : oContext.Route,
					ReferenceNum:oContext.ReferenceNum,
					TotalWeight : oContext.TotalWeight,
					Netweight : oContext.Netweight,
					WeightUnit : oContext.WeightUnit,
					ShipToPartyName : oContext.ShipToPartyName,
					Volume : oContext.Volume,
					VolumeUnit : oContext.VolumeUnit,
					ShippingDesc : oContext.ShippingDesc,
					LoadSeq : oContext.LoadSeq,
					DropSeq : oContext.DropSeq,
					Sloc : oContext.Sloc,
					IssueSloc : oContext.IssueSloc,
					InvoiceNum : oContext.InvoiceNum,
					ArtiFreigtGRP : oContext.ArtiFreigtGRP,
					Number : oContext.Number,
					Detail : oContext.Detail,
					InCoterms : oContext.InCoterms,
					DestinationTeri : oContext.DestinationTeri,
					Distance : oContext.Distance,
					StatusDesc : oContext.StatusDesc,
					InvoiceDate : Formatter.getDate1(oContext.InvoiceDate),
					InvoiceTime : oContext.InvoiceTime,
					BillDate : Formatter.getDate1(oContext.BillDate),
					BillTime : oContext.BillTime,
					BillQty : oContext.BillQty,
					SaleUnit : oContext.SaleUnit,
					StIcon : oContext.StIcon,
			};
			return oItemNav;
		},
		fnAddVRNDetails : function(oData){
			oData.Status = this.oContextVehicle.Status;
			oData.VRNNum = this.oContextVehicle.VRNNum;
			oData.Vehiclenum = this.oContextVehicle.Vehiclenum;
			oData.TransportName = this.oContextVehicle.TransportName;
			oData.Capacity = this.oContextVehicle.Capacity;
			oData.CapacityUnit = this.oContextVehicle.CapacityUnit;
			oData.VehSecDate = this.oContextVehicle.VehSecDate;
			oData.VehSecTime = this.oContextVehicle.VehSecTime;
			oData.Purpose = this.oContextVehicle.Purpose;
			oData.Vendor = this.oContextVehicle.Vendor;
			oData.VehicleTyp = this.oContextVehicle.VehicleTyp;
			oData.ShippingDesc = this.oContextVehicle.ShippingDesc;
			oData.VehicleId = this.oContextVehicle.VehicleId;
			oData.VehicleIdDesc = this.oContextVehicle.VehicleIdDesc;
			oData.VendorName = this.oContextVehicle.VendorName;
			oData.FleetType = this.oContextVehicle.FleetType;
			oData.FromDate = Formatter.getDate1(this.oContextVehicle.FromDate);
			oData.Todate = Formatter.getDate1(this.oContextVehicle.Todate);
			oData.DriverName = this.oContextVehicle.DriverName;
			oData.LicenceNum = this.oContextVehicle.LicenceNum;
			oData.StIcon = this.oContextVehicle.StIcon;			
		},
		fnGetItemNav : function(){
			var aItemNav;
			aItemNav = [];
			var currItem = this.btnCreTrip.getParent();
			if(currItem instanceof ColumnListItem){
				var oContext = currItem.getBindingContext().getObject();
				if(oContext.GroupHeader === undefined){
					var table = currItem.getParent();
					var items = table.getItems();
					var currItemIndex = table.indexOfItem(currItem);
					for(var i = currItemIndex + 1; i < items.length && items[i].getBindingContext().getObject().GroupHeader !== undefined; i++){
						oContext = items[i].getBindingContext().getObject();							
						aItemNav.push(this.fnItemNav(oContext));
					}
				}
				else{
					aItemNav.push(this.fnItemNav(oContext));
				}
			}
			else{
				var oTable = this.getTable("open");
				var gTable = this.getTable("grouped");
				var selItems; 
				selItems = [];
				if(oTable !== ""){
					selItems = oTable.getSelectedItems();
				}
				if(gTable !== ""){
					var gItems = gTable.getSelectedItems();
					selItems = selItems.concat(gItems);						
				}
				var selItemsLen = selItems.length;
				for(var i = 0; i < selItemsLen; i++){
					var oContext = selItems[i].getBindingContext().getObject();
					if(oContext.GroupHeader !== undefined){
						aItemNav.push(this.fnItemNav(oContext));
					}
				}
			}
			return aItemNav;
		},
		fnAddVRNToTrip : function(){
			var aItemNav;
			aItemNav = [];
			var currItem = this.btnVRN.getParent();
			if(currItem instanceof ColumnListItem){
				var table = currItem.getParent();
				var items = table.getItems();
				var itemsLen = items.length;
				var currItemIndex = table.indexOfItem(currItem);
				for(var i = currItemIndex + 1; i < itemsLen && items[i].getBindingContext().getObject().GroupHeader !== undefined; i++){
					var oContext = items[i].getBindingContext().getObject();
					aItemNav.push(this.fnItemNav(oContext));
				}
			}
			else{
				var table = this.getTable("trip");
				if(table !== ""){
					var selItems = table.getSelectedItems();
					var selItemsLen = selItems.length;
					for(var i = 0; i < selItemsLen; i++){
						var oContext = selItems[i].getBindingContext().getObject(); 
						if(oContext.GroupHeader !== undefined){
							aItemNav.push(this.fnItemNav(oContext));
						}
					}
				}				
			}
			if(aItemNav.length > 0){
				var path = "VRNListSet";
				var data = {};
				this.fnAddVRNDetails(data);
				if(this.Site !== undefined){
					data.Site = this.Site;
					this.Site = undefined;
				}
				data.VRNEXECUTIONNAV = aItemNav;			
				this.postData(path, data, [ "/001" ] ,"S1", "AddVRN");
			}			
		},
		pDelDelvy : function(oEvent){			
			var aItemNav;
			aItemNav = [];
			var btnDel = oEvent.getSource();
			var currItem = btnDel.getParent();			
			if(currItem.getBindingContext().getObject().GroupHeader === undefined){
				var table = currItem.getParent();
				var items = table.getItems();
				var itemsLen = items.length;
				var currItemIndex = table.indexOfItem(currItem);
				for(var i = currItemIndex + 1; i < itemsLen && items[i].getBindingContext().getObject().GroupHeader !== undefined; i++){
					var oContext = items[i].getBindingContext().getObject();
					var oItemNav = this.fnItemNav(oContext);
					aItemNav.push(oItemNav);
				}
			}
			else{
				var oContext = currItem.getBindingContext().getObject();
				var oItemNav = this.fnItemNav(oContext);
				aItemNav.push(oItemNav);
			}			

			var path = "DeliveryRemoveSet";
			var data = {
					Dummy : "X",
					DELIVERYEXECUTIONNAV : aItemNav
			};			
			this.postData(path, data, [ "/001" ], "S1", "RemoveDelivery");
		},
		pTripDetailsClose : function(oEvent){
			this.dlgDeliveryDetails.close();
		},
		sTblGroupH : function(oEvent){
			var tableH = oEvent.getSource();
			var table = tableH.getParent().getContent()[1].getContent()[0];
			var items = table.getItems();
			var itemsLen = items.length;
			for(var i = 0; i < itemsLen; i++){
				var oContext = items[i].getBindingContext().getObject();
				if(oContext.GroupHeader === undefined){
					oContext = items[i + 1].getBindingContext().getObject();
				}
				if((oContext.GroupId !== "" || (oContext.TripNum !== "" && oContext.VRNNum  === "")) && Formatter.getValidCreateTripShipTypes().indexOf(oContext.ShippingType) === -1 && table.getId().indexOf("iTBTrips") === -1){
					items[i].setSelected(false);
				}
				else{
					items[i].setSelected(tableH.getItems()[0].getSelected());
				}				
			}
		},
		sTblGroup : function(oEvent){
			//Method to set selected the Child Items of the Group when the Group is selected
			var tblGroup = oEvent.getSource();
			var selectedItem = oEvent.getParameter("listItem");
			var items = tblGroup.getItems();
			var currItemIndex = tblGroup.indexOfItem(selectedItem);			
			if(selectedItem.getBindingContext().getObject().GroupHeader === undefined){
				var oContext = items[currItemIndex + 1].getBindingContext().getObject();
				if((oContext.GroupId !== "" || (oContext.TripNum !== "" && oContext.VRNNum  === "")) && Formatter.getValidCreateTripShipTypes().indexOf(oContext.ShippingType) === -1 && tblGroup.getId().indexOf("iTBTrips") === -1){
					selectedItem.setSelected(false);
				}
				else{					
					for(var i = currItemIndex + 1; i < items.length && items[i].getBindingContext().getObject().GroupHeader !== undefined; i++){
						items[i].setSelected(selectedItem.getSelected());					
					}
				}
			}
			else if(selectedItem.getBindingContext().getObject().GroupHeader !== "////"){//Keep selected the child items when group head item is selected
				selectedItem.setSelected(!selectedItem.getSelected());
			}
		},		
		sFSearch : function(oEvent){
			var aSearchVal;
			aSearchVal = [oEvent.getSource().getValue().toLowerCase()];
			var aProps;
			aProps = [
			          "SystemId", "ShipToPartyName", "ShipToPartyId", "DeliveryNum",
			          "ConfirmDate", "InvoiceNum", "ShippingType", "ShippingDesc", "GroupId", "TripNum", "VRNNum"
			          ];
			this.fnLocalSearch(aSearchVal, aProps);			
		},
		fnLocalSearch : function(srchVal, srchProp){
			var items;
			items = [];
			var iTBItems = this.iTBDelvy.getItems();
			for(var i = 0; i < iTBItems.length; i++){
				var content = iTBItems[i].getContent();
				for(var j = 0; j < content.length; j++){
					if(content[j] instanceof ScrollContainer){
						var table = content[j].getContent()[0];
						var tableItems = table.getItems();
						items = (items.length === 0) ? tableItems : items.concat(tableItems);
					}
				}
			}
			var itemsLen = items.length;
			var groupHeaderIndex = -1;
			var setWholeGrpVisible = false;
			for(var i = 0; i < itemsLen; i++){
				var context = items[i].getBindingContext().getObject();
				if(context.GroupHeader !== undefined){
					var setItemVisible = false;
					for(var prop in context){
						if(srchProp.indexOf(prop) > -1){
							var propVal = context[prop]; 
							if(prop === "ConfirmDate"){
								propVal = Formatter.getDateFormatted(context[prop]);
							}
							propVal = propVal.toLowerCase();
							for(var j = 0; j < srchVal.length; j++){
								if(propVal.indexOf(srchVal[j]) > -1){
									setItemVisible = true;
									if(prop === "SystemId" && context["GroupId"] !== ""){
										setWholeGrpVisible = true;
									}
								}
							}							
						}
					}
					items[i].setVisible(setItemVisible);

					if(groupHeaderIndex !== -1 && items[groupHeaderIndex + 1].getBindingContext().getObject().GroupHeader === "////"){//Hide the group header if it is ungrouped
						items[groupHeaderIndex].setVisible(false);
						items[groupHeaderIndex].getCells()[0].getItems()[0].setSrc("sap-icon://navigation-right-arrow");
					}
					else if(groupHeaderIndex !== -1 && items[groupHeaderIndex + 1].getBindingContext().getObject().GroupHeader !== "////" && setItemVisible){
						items[groupHeaderIndex].setVisible(true);
						items[groupHeaderIndex].getCells()[0].getItems()[0].setSrc("sap-icon://navigation-down-arrow");
						if(setWholeGrpVisible){
							for(var j = groupHeaderIndex + 1; (j < items.length && items[j].getBindingContext().getObject().GroupHeader !== undefined); j++){
								items[j].setVisible(true);
							}
						}
					}					
				}
				else{
					groupHeaderIndex = i;//Store the group header index so that when child item is visible then group header can be made visible
					items[i].setVisible(false);
				}
			}
		},		
		pSearch : function(oEvent){
			if(!this.pgExe.getShowSubHeader()){
				this.byId("sFLocSearch1").setValue();
			}
			this.pgExe.setShowSubHeader(!this.pgExe.getShowSubHeader());
		},
		pRefresh : function(){
			this.fnRefreshData(true);
		},
		fnRefreshData : function(wholeRefresh){
			if(this.dlgFilter && wholeRefresh){
				this.dRSDeliveryDate.setDateValue();
				this.dRSDeliveryDate.setSecondDateValue();
				this.dRSDeliveryDate.setValueState("None");
				this.mCmbShipType.clearSelection();
				this.btnSearch.setEnabled(false);
				this.btnClear.setEnabled(false);
				this.btnFilter.setType("Default");
			}
			this.initTableModel();
		},
		pFilter : function(oEvent){
			if(!this.dlgFilter){
				this.dlgFilter = new sap.ui.xmlfragment("TransportExecution.fragment.Filter", new Filter());
				this.dRSDeliveryDate = this.oCore.byId("dRSDeliveryDate");
				this.mCmbShipType = this.oCore.byId("mCmbShipType");			
				this.btnSearch = this.oCore.byId("btnFilterSearch");
				this.btnClear = this.oCore.byId("btnFilterClear");
				var path = "/ShippingF4Set";
				this.mCmbShipType.setModel(this.oModel);
				this.mCmbShipType.bindAggregation("items", path, new sap.ui.core.Item({
					key : "{ShippingType}",
					text : "{ShippingDesc}"
				}));
			}
			this.dlgFilter.open();
			var fromDate = this.dRSDeliveryDate.getDateValue();
			var toDate = this.dRSDeliveryDate.getSecondDateValue();
			if(fromDate !== null && toDate !== null){
				this.btnClear.setEnabled(true);//Only enable when already some dates are selected when opening fragment
			}
			else{
				this.btnClear.setEnabled(false);//Disable when dates are cleared
				this.btnSearch.setEnabled(false);
			}
		},
		fnFilterCallBack : function(bDateChanged) {
			if(this.mCmbShipType){
				var items = this.mCmbShipType.getItems();
				var shipTypeItems = this.mCmbShipType.getSelectedItems();
				var shipTypeItemsLen = shipTypeItems.length;
				var aProps;
				aProps = [ "ShippingType" ];
				var aShipTypes;
				aShipTypes = [];
				if(bDateChanged === undefined || (bDateChanged !== undefined && bDateChanged === true && shipTypeItemsLen > 0)){
					if (shipTypeItemsLen > 0) {
						for (var i = 0; i < shipTypeItemsLen; i++) {
							aShipTypes.push(shipTypeItems[i].getKey().toLowerCase());
						}				
					} else {
						for (var i = 0; i < items.length; i++) {
							aShipTypes.push(items[i].getKey().toLowerCase());
						}				
					}				
					this.fnLocalSearch(aShipTypes,aProps);
				}				
			}			
		},
		addRemoveFilterClass : function(colIndex, bAdd){
			var items = this.iTBDelvy.getItems();
			for(var i = 0; i < items.length; i++){
				var content = items[i].getContent();
				for(var j = 0; j < content.length; j++){
					if(content[j] instanceof Table){
						var header = content[j].getColumns()[colIndex].getAggregation("header");
						if(bAdd){
							header.addStyleClass("ColumnFilter");
						}
						else{
							header.removeStyleClass("ColumnFilter");
						}
					}
				}
			}
		},
		pCreateTrip : function(oEvent){
			var fnShowActionSheet = function(that, placement){
				var aSCreateTrip = new ActionSheet({
					showHeader : false,
					placement : placement,				
					buttons : [
					           new Button({
					        	   text : that.oi18nModel.getProperty("withVRN"),
					        	   press : [ that.pCreateTripWVRN, that] 
					           }),
					           new Button({
					        	   text : that.oi18nModel.getProperty("woVRN"),
					        	   press : [ that.pCreateTripWOVRN, that]
					           })
					           ]
				});
				aSCreateTrip.openBy(that.btnCreTrip);
			};
			var bSameShipType = true;
			this.btnCreTrip = oEvent.getSource();
			this.oContextVehicle = undefined;//Set selected VRN details to undefined so that new VRN can be selected
			var currItem = this.btnCreTrip.getParent();
			if(currItem instanceof ColumnListItem){
				fnShowActionSheet(this, "Left");				
			}			
			else{
				var oTable = this.getTable("open");
				var gTable = this.getTable("grouped");
				var selItems;
				selItems = [];
				if(oTable !== ""){
					selItems = oTable.getSelectedItems();
				}
				if(gTable !== ""){
					var gItems = gTable.getSelectedItems();
					selItems = selItems.concat(gItems);
				}
				var selItemsLen = selItems.length;
				if(selItemsLen > 0){
					this.uGShipType = "";
					this.uGShipDesc = "";
					for(var i = 0; i < selItemsLen; i++){
						var oContext = selItems[i].getBindingContext().getObject();
						if(oContext.GroupHeader !== undefined){
							if(this.uGShipType === ""){
								this.uGShipType = oContext.ShippingType;
								this.uGShipDesc = oContext.ShippingDesc;
							}
							else if(this.uGShipType !== oContext.ShippingType){
								bSameShipType = false;
							}
						}
					}
					if(bSameShipType){
						if(Formatter.getValidCreateTripShipTypes().indexOf(this.uGShipType) > -1 || selItemsLen === 1){
							fnShowActionSheet(this, "Top");
						}
						else{
							MessageToast.show(this.oi18nModel.getProperty("msgGrpDelvy"));
						}
					}
					else{
						MessageToast.show(this.oi18nModel.getProperty("msgSameShipType"));
					}
				}
				else{
					MessageToast.show(this.oi18nModel.getProperty("msgSelectDelvy"));
				}
			}
		},
		pCreateTripWVRN : function(oEvent){
			this.bCreateTrip = true;
			var shipType = "";
			var shipDesc = "";
			var currItem = this.btnCreTrip.getParent();
			if(currItem instanceof ColumnListItem){
				var oContext = currItem.getBindingContext().getObject();
				if(oContext.GroupHeader === undefined){
					var table = currItem.getParent();
					var items = table.getItems();
					var currItemIndex = table.indexOfItem(currItem);
					oContext = items[currItemIndex + 1].getBindingContext().getObject();
					shipType = oContext.ShippingType;
					shipDesc = oContext.ShippingDesc;					
				}
				else{
					shipType = oContext.ShippingType;
					shipDesc = oContext.ShippingDesc;
				}
			}
			else{
				shipType = this.uGShipType;
				shipDesc = this.uGShipDesc;
			}
			this.fnShowVehicles(this, shipType, shipDesc);
		},
		pCreateTripWOVRN : function(){			
			var data  = {};
			if(TransportExecution.that.oContextVehicle){
				TransportExecution.that.fnAddVRNDetails(data);
			}

			data.Mode = Formatter.getMode();

			if(TransportExecution.that.dRSDeliveryDate && TransportExecution.that.dRSDeliveryDate.getDateValue() !== null && TransportExecution.that.dRSDeliveryDate.getSecondDateValue() !== null){
				data.RangeFromDate = Formatter.getDate(TransportExecution.that.dRSDeliveryDate.getDateValue());
				data.RangeToDate = Formatter.getDate(TransportExecution.that.dRSDeliveryDate.getSecondDateValue());
			}

			data.TRVALEXECUTNAV = TransportExecution.that.fnGetItemNav();
			data.TRVALTRPOPNAV = [];
			data.TRVALTRVALHDRNAV = [];
			data.TRVALTRVALITMNAV = [];
			data.TRVALSELINFNAV = [];

			var that = this;
			var path = "TripValidationSet";
			var fnCallBack = function(oData, oResponse){
				if(oData.FleetType.toLowerCase() === "dedicated vehicle"){
					that.Site = oData.TRVALTRVALHDRNAV.results[0].Site;
				}
				else{
					that.Site = undefined;
				}
				that.headerData = oData.TRVALEXECUTNAV.results;
				that.oPopUpData = oData.TRVALTRVALITMNAV.results;
				that.oSealInfo = (oData.TRVALSELINFNAV === null) ? null :  (oData.TRVALSELINFNAV.results);
				that.getRouter().navTo("S2", {
					tripNo : "0"
				});
			};
			TransportExecution.that.postData(path, data, [ "/001" ], "S1", "TripValidation", false, fnCallBack);
		},		
		pCreateCN : function(oEvent){
			var currItem = oEvent.getSource().getParent();			
			var table = currItem.getParent();
			var items = table.getItems();
			var itemsLen = items.length;
			var currItemIndex = table.indexOfItem(currItem);
			var aItemNav;
			aItemNav = [];			
			var isTruck = true;
			for(var i = currItemIndex + 1; i < itemsLen && items[i].getBindingContext().getObject().GroupHeader !== undefined; i++){
				var oContext = items[i].getBindingContext().getObject();					
				if(oContext.GroupHeader !== undefined){
					var shipTypes =  Formatter.getValidCNShipTypes();
					if(shipTypes.indexOf(oContext.ShippingType) === -1){
						isTruck = false;
					}
					var oItemNav = {
							DeliveryNum : oContext.DeliveryNum	
					};
					aItemNav.push(oItemNav);
				}
			}					
			if(!isTruck){
				MessageToast.show(this.oi18nModel.getProperty("msgCNGenerate"));
			}
			else{
				var path = "CNCreateHdrSet";
				var data = {
						VRNNum : items[currItemIndex + 1].getBindingContext().getObject().VRNNum,
						TripNum : items[currItemIndex + 1].getBindingContext().getObject().TripNum,
						CNCREHDRITEMNAV : aItemNav
				};
				this.postData(path, data, [ "ZMOB/275", "ZMOB/276" ], "S1", "CreateCN");
			}				
		},
		postData : function(path, data, codes, page, btnClicked, bShowMessagePopover, fnCallBack, fnErrorCallBack){
			var succMsgCode;
			succMsgCode = [];
			for(var i = 0; i < codes.length; i++){
				var oCode = {
						code : codes[i],
						gaParams : [ {
							param3 : "Posted",
							param4 : path,
							param5: "",
							path : "TransportExecution/" + page + "/" + btnClicked
						} ]
				};
				succMsgCode.push(oCode);
			}
			var errMsgCode;
			errMsgCode = [ {
				code :"",
				gaParams : [ {
					param3 : "Posted With Error",
					param4 : path,
					param5: "",
					path : "TransportExecution/" + page + "/" + btnClicked
				} ]
			} ];
			Formatter.showLoader();
			this.oModel.create(path, data, {
				async : true,
				success : function(oData, oResponse) {
					Formatter.hideLoader();
					if(bShowMessagePopover === false){
						if(fnCallBack){
							fnCallBack(oData);
						}
						else{							
							TransportExecution.that.fnRefreshData();							
						}
					}
					else{
						if(fnCallBack){
							MessageHandling.handleRequestSuccess(oResponse, succMsgCode, $.proxy(function(msg){
								fnCallBack(oData, oResponse);
							},TransportExecution.that));

						}
						else{
							MessageHandling.handleRequestSuccess(oResponse, succMsgCode, $.proxy(function(msg){
								TransportExecution.that.fnRefreshData();
							},TransportExecution.that));
						}
					}					
				},
				error : function(oError) {
					Formatter.hideLoader();
					if(fnErrorCallBack){
						fnErrorCallBack();
					}
					MessageHandling.handleRequestFailure(oError, errMsgCode, true);					
				}
			});
		},
		pPrintCN : function(){
			if(!this.dlgCNPrint){
				this.dlgCNPrint = sap.ui.xmlfragment("TransportExecution.fragment.PrintCN", new PrintCN());				
			}
			this.nCPrintCN = this.oCore.byId("nCPrintCN");
			this.pgPrinting = this.oCore.byId("pgPrinting");
			this.pgCNTrip = this.oCore.byId("pgCNTrip");
			this.pgList = this.oCore.byId("pgList");
			this.pgListFilter = this.oCore.byId("pgListFilter");
			this.inpTripNo = this.oCore.byId("inpTripNo");
			this.inpCNNo = this.oCore.byId("inpCNNo");
			this.lstPrint = this.oCore.byId("lstPrint");
			this.lstCNTrip = this.oCore.byId("lstCNTrip");
			this.dRSCNDate = this.oCore.byId("dRSCNDate");
			this.btnCNCancel = this.oCore.byId("btnCNCancel");
			this.btnCNPrint = this.oCore.byId("btnCNPrint");
			this.btnCNClear = this.oCore.byId("btnCNClear");
			this.btnCNSearch = this.oCore.byId("btnCNSearch");
			this.nCPrintCN.to(this.pgPrinting);
			this.lstPrint.removeSelections();
			this.btnCNPrint.setVisible(false);
			this.btnCNCancel.setVisible(true);
			this.btnCNClear.setVisible(false);
			this.btnCNSearch.setVisible(false);
			this.dRSCNDate.setDateValue();
			this.dRSCNDate.setSecondDateValue();
			this.dlgCNPrint.open();
		},		
		pVRNChange : function(){
			this.fnNavBack("ZMM_SCM2", "VRNchangelight");
		},
		fnNavBack : function(semanticObj, action){
			if(sap !== undefined && sap.ushell !== undefined && sap.ushell.Container !== undefined){
				var navService = sap.ushell.Container.getService("CrossApplicationNavigation");
				navService.toExternal({
					target : {
						semanticObject : semanticObj,
						action : action
					}
				});
			}
		},
		navBackHome : function(){
			if(typeof TransportScheduling !== "undefined" && TransportScheduling.that && TransportScheduling.that.bNavToExecution){
				TransportScheduling.that.bNavToExecution = undefined;
				this.fnNavBack("ZMM_SCM2", "transSch");
			}
			else{
				this.fnNavBack("", "");
			}
		},
		navBackScheduling : function(){
			this.bNavToScheduling = true;
			this.fnNavBack("ZMM_SCM2", "transSch");
		},
		getRouter : function() {
			return UIComponent.getRouterFor(this);
		},
		onExit : function(){
			if(this.dlgFilter){
				this.dlgFilter.destroy();				
			}
			if(this.dlgCNPrint){
				this.dlgCNPrint.destroy();				
			}
			if(this.dlgTripsList){
				this.dlgTripsList.destroy();				
			}
			if(this.dlgVehicles){
				this.dlgVehicles.destroy();
			}
			if(this.dlgSealInf){
				this.dlgSealInf.destroy();
			}
			if(this.dlgSite){
				this.dlgSite.destroy();
			}
		}
	});
});