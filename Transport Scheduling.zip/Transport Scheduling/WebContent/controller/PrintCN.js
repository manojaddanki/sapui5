sap.ui.define([ 'sap/ui/core/mvc/Controller', 'TransportExecution/util/Formatter','sap/m/MessageToast',
                'sap/m/ColumnListItem', 'sap/m/Label', 'sap/m/Text', 'sap/m/ScreenSize', 'sap/ui/core/Icon', 'sap/m/Input', 'sap/custom/Utilities'],
                function(Controller, Formatter, MessageToast,
                	ColumnListItem, Label, Text, ScreenSize, Icon, Input, Utilities) {
		
	"use strict";
		
	return Controller.extend("TransportExecution.controller.PrintCN",{
		lCNo : function(oEvent){
			this.transMode = undefined;
			this.tripNo = undefined;
			var inpNo = oEvent.getSource();
			var regex = /^[0-9]+$/;
			this.fnValidate(inpNo, regex, "", TransportExecution.that.oi18nModel.getProperty("valNums"));
		},
		lCDepSeal1 : function(oEvent){
			var inpNo = oEvent.getSource();			
			var regex = /^[A-Za-z0-9]+$/;
			this.fnValidate(inpNo, regex, "DepSeal1", TransportExecution.that.oi18nModel.getProperty("msgDepSeal"));
		},
		lCDepSeal2 : function(oEvent){
			var inpNo = oEvent.getSource();			
			var regex = /^[A-Za-z0-9]+$/;
			this.fnValidate(inpNo, regex, "DepSeal2", TransportExecution.that.oi18nModel.getProperty("msgDepSeal"));
		},
		fnValidate : function(inpNo, regex, property, msg){
			var inpNoVal = inpNo.getValue();
			if(regex.test(inpNoVal)){
				if(inpNo.getParent() instanceof ColumnListItem){
					var oContext = inpNo.getParent().getBindingContext().getObject();
					for(var prop in oContext){
						if(prop === property){							
							oContext[prop] = inpNoVal;
							break;
						}
					}
				}
				inpNo.setValueState("None");
				inpNo.setValueStateText();
			}
			else{
				inpNo.setValue();
				inpNo.setValueState("Error");
				inpNo.setValueStateText(msg);
				MessageToast.show(msg);
			}
		},
		bindCNList : function(){
			var selItem = TransportExecution.that.lstPrint.getSelectedItem();
			var selItemIndex = TransportExecution.that.lstPrint.indexOfItem(selItem);
			var sPath = "";
			if(selItemIndex === 0){
				sPath = "/CNListSet@DateFilter";
				TransportExecution.that.lstCNTrip.getColumns()[0].getHeader().setVisible(true);
				TransportExecution.that.lstCNTrip.getColumns()[2].setDemandPopin(true);
				TransportExecution.that.lstCNTrip.getColumns()[2].setMinScreenWidth(ScreenSize.Tablet);
			}
			else{
				sPath = "/TripListSet@DateFilter and TripNum eq ''";
				TransportExecution.that.lstCNTrip.getColumns()[0].getHeader().setVisible(false);
				TransportExecution.that.lstCNTrip.getColumns()[2].setDemandPopin(false);
				TransportExecution.that.lstCNTrip.getColumns()[2].setMinScreenWidth(ScreenSize.Phone);
			}
			var fromDate, toDate;
			if(TransportExecution.that.dRSCNDate !== undefined && TransportExecution.that.dRSCNDate.getDateValue() !== null && TransportExecution.that.dRSCNDate.getSecondDateValue() !== null){
				fromDate = Formatter.getDate1(TransportExecution.that.dRSCNDate.getDateValue());
				toDate = Formatter.getDate1(TransportExecution.that.dRSCNDate.getSecondDateValue());				
			}
			else{
				var currDate = new Date();
				fromDate = Formatter.getDate1(currDate);
				toDate = Formatter.getDate1(currDate);
			}
			sPath = sPath.replace("@DateFilter", "?$filter=FromDate eq datetime'" + fromDate + "' and ToDate eq datetime'" + toDate + "'");
			
			var fnFactory = function(sId, oContext){
				if(oContext.getProperty("TransportMode")){
					return new Icon({
						src : Formatter.getShipTypeIcon(oContext.getProperty("TransportMode")),
						color : Formatter.getShipTypeIconColor(oContext.getProperty("TransportMode")),
						tooltip : oContext.TransportMode
					});
				}
				else{
					return new Label({
		         		text : "{CNNum}",
		         		design : "Bold"
		         	});
				}
			};		
			
			TransportExecution.that.lstCNTrip.bindAggregation("items", {
				path : sPath,
				factory : function(sId, oContext){
					return new ColumnListItem({
						tooltip : "{path: 'CreationDate', formatter: 'TransportExecution.util.Formatter.getDateFormatted'}",
						cells : [
						         	fnFactory(sId, oContext),
						         	new Text({
						         		text : "{TripNum}"
						         	}),
						         	new Text({
						         		text : "{VehicleNum}"
						         	})				         	
						        ]
					}); 
				}
			});
		},
		cCNDateRange : function(oEvent){
			var fromDate = TransportExecution.that.dRSCNDate.getDateValue();
			var toDate = TransportExecution.that.dRSCNDate.getSecondDateValue();
			var currDate = new Date();
			this.isDateValid = true;
			var errorMsg = "";
			if(fromDate === null && toDate === null){
				TransportExecution.that.dRSCNDate.setValueState("None");
			}
			else if(fromDate > currDate || toDate > currDate){
				this.isDateValid = false;
				errorMsg = TransportExecution.that.oi18nModel.getProperty("msgDateSelection");
			}
			else{
				var isValid = Formatter.validateDateRange(fromDate, toDate);
				if(!isValid){
					this.isDateValid = false;
					errorMsg = TransportExecution.that.oi18nModel.getProperty("msgDateRange");					
				}
			}
			if(this.isDateValid){
				TransportExecution.that.dRSCNDate.setValueState("None");
				TransportExecution.that.dRSCNDate.setValueStateText();
				TransportExecution.that.btnCNSearch.setEnabled(true);
			}
			else{
				MessageToast.show(errorMsg);
				TransportExecution.that.dRSCNDate.setValueState("Error");
				TransportExecution.that.dRSCNDate.setValueStateText(errorMsg);
				TransportExecution.that.btnCNSearch.setEnabled(false);
			}
		},		
		sCPrinting : function(oEvent){
			TransportExecution.that.nCPrintCN.to(TransportExecution.that.pgCNTrip);
			var list = oEvent.getSource();
			var selItem = oEvent.getParameter("listItem");
			var selItemIndex = list.indexOfItem(selItem);
			if(selItemIndex === 0){
				TransportExecution.that.inpCNNo.setVisible(true);
			}
			else{
				TransportExecution.that.inpCNNo.setVisible(false);
			}
			TransportExecution.that.inpTripNo.setValue();
			TransportExecution.that.inpTripNo.setValueState("None");
			TransportExecution.that.inpTripNo.setValueStateText();
			TransportExecution.that.inpCNNo.setValue();
			TransportExecution.that.inpCNNo.setValueState("None");
			TransportExecution.that.inpCNNo.setValueStateText();
			TransportExecution.that.btnCNPrint.setVisible(true);
		},
		lcCNTripNo : function(oEvent){
			var searchVal = oEvent.getSource().getValue().toLowerCase();
			var items = TransportExecution.that.lstCNTrip.getItems();
			var itemsLen = items.length;
			for(var i = 0; i < itemsLen; i++){
				var context = items[i].getBindingContext();
				var cNNo = context.getProperty("CNNum");
				var tripNo = context.getProperty("TripNum");
				var vehNo = context.getProperty("VehicleNum");
				if((cNNo !== undefined && cNNo.indexOf(searchVal) > -1) || tripNo.indexOf(searchVal) > -1 || vehNo.indexOf(searchVal) > -1){
					items[i].setVisible(true);
				}
				else{
					items[i].setVisible(false);
				}
			}
		},
		sCCNTrip : function(oEvent){
			var selItem = oEvent.getParameter("listItem");
			var cNNo = selItem.getBindingContext().getProperty("CNNum");
			this.tripNo = selItem.getBindingContext().getProperty("TripNum");
			this.transMode = selItem.getBindingContext().getProperty("TransportMode");
			if(this.inpCNTrip !== undefined){
				this.inpCNTrip.setValueState("None");
				if(this.inpCNTrip.getId() === "inpTripNo"){					
					this.inpCNTrip.setValue(this.tripNo);
				}
				else{
					this.inpCNTrip.setValue(cNNo);
				}
			}
			TransportExecution.that.nCPrintCN.back();
			TransportExecution.that.btnCNPrint.setVisible(true);
		},		
		vHRCNTrip : function(oEvent){
			this.inpCNTrip = oEvent.getSource();
			TransportExecution.that.nCPrintCN.to(TransportExecution.that.pgList);
			TransportExecution.that.btnCNCancel.setVisible(true);
			TransportExecution.that.btnCNPrint.setVisible(false);
			TransportExecution.that.btnCNClear.setVisible(false);
			TransportExecution.that.btnCNSearch.setVisible(false);
			this.bindCNList();
		},
		nBPPGPrinting : function(){
			TransportExecution.that.lstPrint.removeSelections();
			TransportExecution.that.nCPrintCN.back();
			TransportExecution.that.btnCNCancel.setVisible(true);
			TransportExecution.that.btnCNPrint.setVisible(false);
			TransportExecution.that.btnCNClear.setVisible(false);
			TransportExecution.that.btnCNSearch.setVisible(false);
		},
		nBPPGCNTrip : function(){			
			TransportExecution.that.btnCNCancel.setVisible(true);
			TransportExecution.that.btnCNPrint.setVisible(true);
			TransportExecution.that.btnCNClear.setVisible(false);
			TransportExecution.that.btnCNSearch.setVisible(false);
			TransportExecution.that.nCPrintCN.back();
		},
		nBPPGList : function(){
			TransportExecution.that.nCPrintCN.back();
			TransportExecution.that.btnCNCancel.setVisible(true);
			TransportExecution.that.btnCNPrint.setVisible(false);
			TransportExecution.that.btnCNClear.setVisible(false);
			TransportExecution.that.btnCNSearch.setVisible(false);
		},
		pRefCNList : function(){
			this.bindCNList();
		},
		pFltrCNList : function(){
			TransportExecution.that.nCPrintCN.to(TransportExecution.that.pgListFilter);
			TransportExecution.that.btnCNCancel.setVisible(false);
			TransportExecution.that.btnCNPrint.setVisible(false);
			TransportExecution.that.btnCNClear.setVisible(true);
			TransportExecution.that.btnCNSearch.setVisible(true);
			var fromDate = TransportExecution.that.dRSCNDate.getDateValue();
			var toDate = TransportExecution.that.dRSCNDate.getSecondDateValue();
			if(fromDate !== null && toDate !== null){
				TransportExecution.that.btnCNClear.setEnabled(true);//Only enable when already some dates are selected
			}
			else{
				TransportExecution.that.btnCNClear.setEnabled(false);//Disable when dates are cleared
				TransportExecution.that.btnCNSearch.setEnabled(false);
			}
		},
		pCNClear : function(){
			TransportExecution.that.dRSCNDate.setDateValue();
			TransportExecution.that.dRSCNDate.setSecondDateValue();
			TransportExecution.that.dRSCNDate.setValueState("None");
			TransportExecution.that.btnCNCancel.setVisible(true);
			TransportExecution.that.btnCNPrint.setVisible(false);
			TransportExecution.that.btnCNClear.setVisible(false);			
			this.bindCNList();
			TransportExecution.that.nCPrintCN.back();
			TransportExecution.that.btnCNSearch.setVisible(false);
		},
		pCNSearch : function(){
			if(this.isDateValid !== undefined && this.isDateValid === true) {
				this.isDateValid = undefined;
				this.bindCNList();
			}		
			TransportExecution.that.btnCNCancel.setVisible(true);
			TransportExecution.that.btnCNPrint.setVisible(false);
			TransportExecution.that.btnCNClear.setVisible(false);
			TransportExecution.that.btnCNSearch.setVisible(false);
			TransportExecution.that.nCPrintCN.back();
		},
		pCNCancel : function(){
			TransportExecution.that.dlgCNPrint.close();
		},
		fnGetTransMode : function(tripNo){
			var that = this;
			var sPath = "/TripListSet?$@DateFilter TripNum eq '" + tripNo + "'";
			var fromDate, toDate;
			if(TransportExecution.that.dRSCNDate !== undefined && TransportExecution.that.dRSCNDate.getDateValue() !== null && TransportExecution.that.dRSCNDate.getSecondDateValue() !== null){
				fromDate = Formatter.getDate1(TransportExecution.that.dRSCNDate.getDateValue());
				toDate = Formatter.getDate1(TransportExecution.that.dRSCNDate.getSecondDateValue());				
			}
			else{
				var currDate = new Date();
				fromDate = Formatter.getDate1(currDate);
				toDate = Formatter.getDate1(currDate);
			}
			sPath = sPath.replace("@DateFilter", "filter=FromDate eq datetime'" + fromDate + "' and ToDate eq datetime'" + toDate + "' and ");
			Formatter.showLoader();
			TransportExecution.that.oModel.read(sPath, {
				async : true,
				success : function(oData, oResponse){
					Formatter.hideLoader();
					if(oData.results[0].TransportMode === "RD"){
						that.fnSealInfo(tripNo);
					}
					else{
						that.downloadPDF(tripNo);
					}
				},
				error : function(oError){
					Formatter.hideLoader();
					var msg = "";
					try{
						msg = JSON.parse(oError.response.body).error.message.value;
					}
					catch(err){
						msg = oError.response.body;
					}
					MessageToast.show(msg);
				}
			});
		},
		fnSealInfo : function(tripNo){
			if(!TransportExecution.that.dlgSealInf){
				TransportExecution.that.dlgSealInf = sap.ui.xmlfragment("TransportExecution.fragment.SealInfo", this);
			}
			var path = "/SealInfoSet?$filter=TripNum eq '" + tripNo + "'";
			sap.ui.getCore().byId("tblSealInfo1").bindItems(path, new ColumnListItem({
				cells : [
				         	new Text({
				         		text : "{LocationCode}"
				         	}),
				         	new Text({
				         		text : "{path:'StageSeq', formatter:'TransportExecution.util.Formatter.getStageSeq'}"
				         	}),
				         	new Input({
				         		value : "{DepSeal1}",
				         		maxLength : 15,
				         		placeholder : TransportExecution.that.oi18nModel.getProperty("phDepSeal1"),
				         		liveChange : [ this.lCDepSeal1, this ]
				         	}),
				         	new Input({
				         		value : "{DepSeal2}",
				         		maxLength : 15,
				         		placeholder : TransportExecution.that.oi18nModel.getProperty("phDepSeal2"),
				         		liveChange : [ this.lCDepSeal2, this ]
				         	})
				        ]
			}));
			TransportExecution.that.dlgSealInf.open();
		},
		pCNPrint : function(){
			var selItem = TransportExecution.that.lstPrint.getSelectedItem();
			var selItemIndex = TransportExecution.that.lstPrint.indexOfItem(selItem);
			var tripNo = TransportExecution.that.inpTripNo.getValue();
			var cNNo = TransportExecution.that.inpCNNo.getValue();
			if(tripNo === ""){
				TransportExecution.that.inpTripNo.setValueState("Error");
				TransportExecution.that.inpTripNo.setValueStateText("Enter Trip Number");
				MessageToast.show("Enter Trip Number");
			}
			else if(selItemIndex === 0){				
				this.downloadPDF(tripNo, cNNo);
			}
			else if(this.transMode !== undefined){
				if(this.transMode === "RD"){
					this.fnSealInfo(tripNo);
				}
				else{
					this.downloadPDF(tripNo);
				}
			}
			else{
				this.fnGetTransMode(tripNo);
			}
		},
		pSealSubmit : function(){
			var tripNo = TransportExecution.that.inpTripNo.getValue();
			var sealItems = sap.ui.getCore().byId("tblSealInfo1").getItems();
			var sealItemsLen = sealItems.length;			
			var aSealInfNav;
			aSealInfNav = [];
			for(var i = 0; i < sealItemsLen; i++){
				var oContext = sealItems[i].getBindingContext().getObject();
				var oSealInf = {
					LocationCode : oContext.LocationCode,
					StageSeq : oContext.StageSeq,
					DepSeal1 : oContext.DepSeal1,
					DepSeal2 : oContext.DepSeal2
				};
				aSealInfNav.push(oSealInf);
			}
			var path = "TripPrintSet";
			var data = {
				TripNum : tripNo,
				TRPRSELINFNAV : aSealInfNav
			};
			var fnCallBack = function(oData, oResponse){
				var res = JSON.parse(oResponse.body);
				if(typeof(res.d) === "undefined" || typeof(res.d.Content) === "undefined" || typeof(res.d.MimeType) === "undefined" || 
						res.d.Content === "" || res.d.MimeType === ""){
					MessageToast.show("PDF can't be generated");
				}
				else{
					TransportExecution.that.pdfFile = JSON.parse(oResponse.body).d.Content;
					TransportExecution.that.getRouter().navTo("S3");
				}
				/*var  ctnt=oResponse.data.Content;
				if (!window.btoa) {
					var tableStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
					var table = tableStr.split("");
					window.btoa = function (bin) {
						for (var i = 0, j = 0, len = bin.length / 3, base64 = []; i < len; ++i) {
							var a = bin.charCodeAt(j++), b = bin.charCodeAt(j++), c = bin.charCodeAt(j++);
							if ((a | b | c) > 255) throw new Error("String contains an invalid character");
							base64[base64.length] = table[a >> 2] + table[((a << 4) & 63) | (b >> 4)] +
							(isNaN(b) ? "=" : table[((b << 2) & 63) | (c >> 6)]) +
							(isNaN(b + c) ? "=" : table[c & 63]);
						}
						return base64.join("");
					};
				}*/ 
				//script block
				// try this way  to open you pdf file like this in javascript hope it will help you.
				/*function hexToBase64(str){
					return btoa(String.fromCharCode.apply(null,str.replace(/\r|\n/g, "").replace(/([\da-fA-F]{2}) ?/g, "0x$1 ").replace(/ +$/, "").split(" ")));
				}*/
				//var data=hexToBase64(ctnt);// here pass the big hex string
				// it will be open in the web browser like this
				//   document.location.href = 'data:application/pdf ; base64,' +data;
				//to open up in the new window**
				//window.open('data:application/pdf;base64,' + data);
				TransportExecution.that.dlgSealInf.close();
			};
			
			TransportExecution.that.postData(path, data, [ "/001" ], "S1", "TripPrint", true, fnCallBack);
		},
		pSealCancel : function(){
			TransportExecution.that.dlgSealInf.close();
		},		
		downloadPDF : function(tripNo, cNNo){			
			var sPath = "CNPrintPDFSet(TripNum='" + tripNo + "',CNNum='" + cNNo + "')/$value";
			if(cNNo === undefined){
				sPath = "PrintPDFSet(TripNum='" + tripNo + "')/$value";
			}
			Formatter.showLoader();
			TransportExecution.that.oModel.read(sPath, {
				async : true,
				success : function(oData, oResponse){
					Formatter.hideLoader();
					Utilities.redirectURL();
					window.open(oResponse.requestUri);
				},
				error : function(oError){
					Formatter.hideLoader();
					var msg = "";
					try{
						msg = JSON.parse(oError.response.body).error.message.value;
					}
					catch(err){
						msg = oError.response.body;
					}
					MessageToast.show(msg);
				}
			});
		}
	});
});