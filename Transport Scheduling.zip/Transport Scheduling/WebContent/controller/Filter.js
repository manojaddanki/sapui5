sap.ui.define([ 'sap/ui/core/mvc/Controller', 'TransportExecution/util/Formatter', 'sap/m/MessageToast'], 
		function(Controller, Formatter, MessageToast) {
		
	"use strict";
		
	return Controller.extend("TransportExecution.controller.Filter",{
		
		cDelvyDateRange : function(oEvent) {
			var fromDate = TransportExecution.that.dRSDeliveryDate.getDateValue();
			var toDate = TransportExecution.that.dRSDeliveryDate.getSecondDateValue();
			var currDate = new Date();
			this.isDateValid = true;
			var errorMsg = "";
			if (fromDate === null && toDate === null) {
				TransportExecution.that.dRSDeliveryDate.setValueState("None");
			} else if (fromDate > currDate || toDate > currDate) {
				this.isDateValid = false;
				errorMsg = "Select Date Range within Today";
			} else {
				var isValid = Formatter.validateDateRange(fromDate, toDate);
				if (!isValid) {
					this.isDateValid = false;
					errorMsg = "Select Dates within 15 Days Range";
				}
			}
			if (this.isDateValid) {
				TransportExecution.that.dRSDeliveryDate.setValueState("None");
				TransportExecution.that.dRSDeliveryDate.setValueStateText();
				TransportExecution.that.btnSearch.setEnabled(true);
			} else {
				MessageToast.show(errorMsg);
				TransportExecution.that.dRSDeliveryDate.setValueState("Error");
				TransportExecution.that.dRSDeliveryDate.setValueStateText(errorMsg);
				TransportExecution.that.btnSearch.setEnabled(false);
			}
		},
		sCShipType : function(oEvent) {
			TransportExecution.that.btnSearch.setEnabled(true);
		},
		pFilterClose : function() {
			TransportExecution.that.dlgFilter.close();
		},
		pFilterClear : function() {
			// Display default data without any filters
			TransportExecution.that.pRefresh();
			TransportExecution.that.dlgFilter.close();
		},
		pFilterSearch : function() {
			if (this.isDateValid) {
				this.isDateValid = undefined;
				TransportExecution.that.initTableModel();
			} else {
				TransportExecution.that.fnFilterCallBack();
			}
			var fromDate = TransportExecution.that.dRSDeliveryDate.getDateValue();
			var toDate = TransportExecution.that.dRSDeliveryDate.getSecondDateValue();
			var shipTypeItemsLen = TransportExecution.that.mCmbShipType.getSelectedItems().length;
			if(fromDate === null && toDate === null && shipTypeItemsLen === 0){
				TransportExecution.that.btnFilter.setType("Default");
			}
			else{
				TransportExecution.that.btnFilter.setType("Emphasized");
			}
			TransportExecution.that.dlgFilter.close();
		},
	});
});