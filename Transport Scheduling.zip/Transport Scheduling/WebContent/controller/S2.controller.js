sap.ui.define([ 'sap/ui/core/mvc/Controller', 'sap/ui/core/UIComponent', 'sap/ui/model/json/JSONModel',
                'sap/custom/MessageHandling', 'sap/m/MessageToast', 'sap/m/MessageBox', 'sap/m/GroupHeaderListItem',
                'sap/m/ColumnListItem', 'sap/m/Text', 'sap/m/Link', 'sap/ui/model/Sorter', 'sap/m/Button',
                'sap/m/StandardListItem', 'TransportExecution/util/Formatter', 'sap/m/Column', 'sap/ui/core/Icon',
                'sap/m/Label', 'sap/m/DisplayListItem', 'sap/m/ResponsivePopover', 'sap/m/List', 'sap/m/Input',
                'sap/m/FlexBox', 'TransportExecution/controller/Filter', 'TransportExecution/controller/PrintCN',
                'sap/m/ObjectStatus', 'sap/m/ScrollContainer', 'sap/m/DatePicker'],
                function(Controller, UIComponent, JSONModel, 
                		MessageHandling, MessageToast, MessageBox, GroupHeaderListItem,
                		ColumnListItem, Text, Link, Sorter, Button,
                		StandardListItem, Formatter, Column, Icon, 
                		Label, DisplayListItem, ResponsivePopover, List, Input,
                		FlexBox, Filter, PrintCN, 
                		ObjectStatus, ScrollContainer, DatePicker) {
	"use strict";

	return Controller.extend("TransportExecution.controller.S2", {
		onInit : function() {
			this.oModel = this.getOwnerComponent().getModel();
			this.getView().setModel(this.oModel);
			this.tblTripDetails = this.byId("tblTripDetails");
			this.pnlSealInfo = this.byId("pnlSealInfo");
			this.tblSealInfo = this.byId("tblSealInfo");
			this.inpSite = this.byId("inpLastLoc");
			this.oi18nModel = this.getOwnerComponent().getModel("i18n");
			this.getRouter().attachRoutePatternMatched(this.onRouteMatched, this);
		},
		onRouteMatched : function(oEvent){
			if(oEvent.getParameter("name") === "S2"){
				if(TransportExecution.that){
					TransportExecution.that.oAfterRender = {
							onAfterRendering : function(oEvent){
								var control = oEvent.srcControl;
								if(TransportExecution.that.tabIndex === undefined){
									TransportExecution.that.tabIndex = 0;
								}
								control.$().find("input").attr("tabIndex", TransportExecution.that.tabIndex++);
							}
					};
					this.tripNo = oEvent.getParameter("arguments").tripNo;
					if(this.tripNo !== "0"){
						this.getDeliveryDetails();
						this.pnlSealInfo.setVisible(false);
						this.byId("lblLastLoc").setVisible(false);
						this.byId("inpLastLoc").setVisible(false);
					}
					else{						
						var oModel = new JSONModel(TransportExecution.that.oPopUpData);
						this.bindTable(oModel);
						if(TransportExecution.that.Site !== undefined){
							this.byId("lblLastLoc").setVisible(true);
							this.byId("inpLastLoc").setVisible(true);
							this.byId("inpLastLoc").setValue(TransportExecution.that.Site);
						}
						else{
							this.byId("lblLastLoc").setVisible(false);
							this.byId("inpLastLoc").setVisible(false);
						}
						if(TransportExecution.that.oPopUpData[0].ShippingType === "RD"){
							this.pnlSealInfo.setVisible(true);
						}
						else{
							this.pnlSealInfo.setVisible(false);
						}
						var oSealModel = new JSONModel(TransportExecution.that.oSealInfo);
						this.tblSealInfo.setModel(oSealModel);

						this.tblSealInfo.bindAggregation("items", {
							path : "/",
							template : new ColumnListItem({
								cells : [
								         new Text({
								        	 text : "{LocationCode}"
								         }),
								         new Text({
								        	 text : "{StageSeq}"
								         }),
								         new Input({
								        	 value : "{DepSeal1}",
								        	 placeholder : this.oi18nModel.getProperty("phDepSeal1"),
								        	 maxLength : 15,
								        	 liveChange : [ this.lCDepSeal1, this ]
								         }).addEventDelegate(TransportExecution.that.oAfterRender),
								         new Input({
								        	 value : "{DepSeal2}",
								        	 placeholder : this.oi18nModel.getProperty("phDepSeal2"),
								        	 maxLength : 15,
								        	 liveChange : [ this.lCDepSeal2, this ]
								         }).addEventDelegate(TransportExecution.that.oAfterRender)
								         ]
							}) 
						});
					}
				}
				else{
					this.navBack();
				}
			}
		},
		lCLastLoc : function(oEvent){
			var inpNo = oEvent.getSource();
			inpNo.setValue(inpNo.getValue().toUpperCase());
		},
		lCDepSeal1 : function(oEvent){
			var inpNo = oEvent.getSource();
			this.fnValidate(inpNo, /^[A-Za-z0-9]+$/, "DepSeal1", this.oi18nModel.getProperty("msgDepSeal"), false);
		},
		lCDepSeal2 : function(oEvent){
			var inpNo = oEvent.getSource();
			this.fnValidate(inpNo, /^[A-Za-z0-9]+$/, "DepSeal2", this.oi18nModel.getProperty("msgDepSeal"), false);
		},
		fnPopupData : function(oContext, bCreateTrip, bDisplay){
			var oData = {					
					DeliveryNum : oContext.DeliveryNum,					
					Edd : Formatter.getDate1((oContext.Edd === undefined) ? oContext.DeliveryDate : oContext.Edd),
					NumPackages : (oContext.NumPackages === "" || oContext.NumPackages === undefined) ? 0 : parseInt(oContext.NumPackages),
							PackageUnit : Formatter.getPackageUnit(oContext.PackageUnit),
							Weight : oContext.Weight,
							WeightUnit : Formatter.getWeightUnit(oContext.WeightUnit),
							Volume : oContext.Volume,
							VolumeUnit : Formatter.getVolumeUnit(oContext.VolumeUnit)					
			};
			if(bCreateTrip){
				oData.DocketNum = oContext.LRNum;
				oData.DocketDate = (oContext.LRDate !== null) ? Formatter.getDate1(oContext.LRDate) : Formatter.getDate1(oContext.CurrentDate);
			}
			if(bDisplay){
				oData.ShipToPartyName =  oContext.ShipToPartyName;
				oData.ShipToPartyId = oContext.ShipToPartyId;
				oData.ShippingType = oContext.ShippingType;
				oData.ShippingDesc = oContext.ShippingDesc;
				oData.SystemId = oContext.SystemId;
				oData.LRNum = oContext.LRNum;
				oData.LRDate = oContext.LRDate;
			}
			return oData;
		},
		getDeliveryDetails : function(){
			var that = this, aItemNav, selItems, table = TransportExecution.that.getTable("open");
			aItemNav = [];
			selItems = [];
			if(table !== ""){
				selItems = table.getSelectedItems();
			}			
			var selItemsLen = selItems.length;
			for(var i = 0; i < selItemsLen; i++){
				var context = selItems[i].getBindingContext().getObject();
				if(context.GroupHeader !== undefined){
					this.shipType = context.ShippingType;
					var oItemNav = {
							DeliveryNum : context.DeliveryNum,
							ItemNum : context.DelItemNum
					};
					aItemNav.push(oItemNav);
				}
			}			
			var data = {
					Mode : Formatter.getMode(),
					TripNum : this.tripNo,
					TRHDRTRDTHDRNAV : aItemNav,
					TRHDRTRDTITMNAV : [] 
			};
			if(TransportExecution.that.dRSDeliveryDate && TransportExecution.that.dRSDeliveryDate.getDateValue() !== null && TransportExecution.that.dRSDeliveryDate.getSecondDateValue() !== null){
				data.FromDate = Formatter.getDate(TransportExecution.that.dRSDeliveryDate.getDateValue());
				data.ToDate = Formatter.getDate(TransportExecution.that.dRSDeliveryDate.getSecondDateValue());
			}

			var path = "TripHeaderSet",
			jsonModel = new JSONModel(),
			fnCallBack = function(oData){
				jsonModel.setData(oData.TRHDRTRDTITMNAV.results);
				that.bindTable(jsonModel);
			},
			fnErrorCallBack = function(){
				jsonModel.setData([]);
				that.bindTable(jsonModel);
			};
			TransportExecution.that.postData(path, data, [], "S2", "TripDetailsPopUp", false, fnCallBack, fnErrorCallBack);
		},
		bindTable : function(oModel){
			if(oModel.oData.length > 0){
				this.byId("btnCreateTripSubmit").setVisible(true);//Hide Submit button when no data displayed
				this.shipType = oModel.oData[0].ShippingType;
			}
			else{
				this.byId("btnCreateTripSubmit").setVisible(false);
			}
			var columns = this.tblTripDetails.getColumns();
			switch(this.shipType){
			case "RD" : 
				columns[3].setVisible(false);
				columns[4].setVisible(false);
				break;
			case "RB" : 
				columns[3].setVisible(false);
				columns[4].setVisible(true);
				break;
			default : 
				columns[3].setVisible(true);
			columns[4].setVisible(true);
			}
			columns[6].getHeader().setText(this.oi18nModel.getProperty("colPkgs") + " (" + Formatter.getPackageUnit() + ")");
			columns[7].getHeader().setText(this.oi18nModel.getProperty("colWei") + " (" + Formatter.getWeightUnit() + ")");
			columns[8].getHeader().setText(this.oi18nModel.getProperty("colVol") + " (" + Formatter.getVolumeUnit() + ")");
			this.tblTripDetails.setModel(oModel);

			this.tblTripDetails.bindAggregation("items", {
				path : "/",
				sorter : new Sorter({
					path : "ShipToPartyId",
					descending : false,
					group : false
				}),
				template : new ColumnListItem({
					cells : [
					         new FlexBox({
					        	 items : [
					        	          new Icon({
					        	        	  src : "{path:'ShippingType', formatter:'TransportExecution.util.Formatter.getShipTypeIcon'}",
					        	        	  tooltip : "{ShippingDesc}",
					        	        	  color : "{path:'ShippingType', formatter:'TransportExecution.util.Formatter.getShipTypeIconColor'}"
					        	          }).addStyleClass("sapUiSmallMarginEnd"),									         	
					        	          new Text({
					        	        	  text : "{ShipToPartyName} ({ShipToPartyId})"
					        	          })
					        	          ]
					         }),
					         new Text({
					        	 text : "{SystemId}"
					         }),
					         new Text({
					        	 text : "{DeliveryNum}"
					         }),	 			            	
					         new Input({
					        	 value : "{LRNum}",
					        	 placeholder : this.oi18nModel.getProperty("phDocNo"),
					        	 maxLength : 15,
					        	 liveChange : [ this.lCDocNo, this ]
					         }).addEventDelegate(TransportExecution.that.oAfterRender),
					         new DatePicker({
					        	 dateValue : "{LRDate}",
					        	 placeholder : this.oi18nModel.getProperty("phDocDate"),
					        	 displayFormat : Formatter.getDateDisplayFormat(),
					        	 valueFormat : Formatter.getDateDisplayFormat(),
					        	 enabled : false,
					        	 change : [ this.cDD, this ]
					         }).addEventDelegate(TransportExecution.that.oAfterRender),
					         new DatePicker({	 			            		
					        	 dateValue : "{Edd}",
					        	 placeholder : this.oi18nModel.getProperty("phEdd"),
					        	 displayFormat : Formatter.getDateDisplayFormat(),
					        	 valueFormat : Formatter.getDateDisplayFormat(),
					        	 change : [ this.cEDD, this ]
					         }).addEventDelegate(TransportExecution.that.oAfterRender),
					         new Input({
					        	 value : "{NumPackages}",
					        	 placeholder : this.oi18nModel.getProperty("phNoPkgs"),
					        	 maxLength : 9,
					        	 liveChange : [ this.lCNumPacks, this]
					         }).addEventDelegate(TransportExecution.that.oAfterRender),
					         new Input({
					        	 value : "{Weight}",
					        	 placeholder : this.oi18nModel.getProperty("phWei"),
					        	 maxLength : 10,
					        	 change : [ this.cWeight, this ]
					         }).addEventDelegate(TransportExecution.that.oAfterRender),
					         new Input({
					        	 value : "{Volume}",
					        	 placeholder : this.oi18nModel.getProperty("phVol"),
					        	 maxLength : 10,
					        	 change : [ this.cVolume, this ]
					         }).addEventDelegate(TransportExecution.that.oAfterRender)
					         ]
				})
			});
			var aSTP, items = this.tblTripDetails.getItems(), itemsLen = items.length;
			aSTP = [];
			//this.aSTP2=""
			/*
			var  itemsData=this.getView().byId("tblTripDetails").getModel().getData();
			var a = [], // uniques get placed into here
			b = 0; // counter to test if value is already in array 'a'
			for (var i = 0; i < itemsLen; i++ ) {
				var current =  itemsData[i]; // get a value from the original array
				for (var j = 0; j < a.length; j++ ) { // loop and check if value is in new array 
					if ( current.ShipToPartyId != a[j].ShipToPartyId ) {
						b++; // if its not in the new array increase counter
					}
				}
				if ( b == a.length ) { // if the counter increased on all values 
					// then its not in the new array yet
					a.push( current ); // put it in
				}
				b = 0; // reset counter
			}
			var c=0;
			for(var j=0;j<a.length;j++){
				for(var i=0;i<items.length;i++){
					if(a[j].ShipToPartyId===items[i].getBindingContext().getObject().ShipToPartyId&&a[j].SystemId!==items[i].getBindingContext().getObject().SystemId){
						c++;
					}					
				}
				a[j].Count=c;
			}
			for(var i=0;i<a.length;i++){
				for(var j=0;j<itemsLen;j++){
					if(itemsData[j].ShipToPartyId===a[i].ShipToPartyId){
						itemsData[j].count=	a[i].Count;
					}
				}
			}*/
			for(var i = 0; i < itemsLen; i++){
				var oContext = items[i].getBindingContext().getObject();
				if(aSTP[oContext.ShipToPartyId]){
					if(this.aSTP2[oContext.SystemId]){
						if(aSTP[oContext.ShipToPartyId].LRNum === ""){
							aSTP[oContext.ShipToPartyId].LRNum = oContext.LRNum;
						}
						if(aSTP[oContext.ShipToPartyId].LRDate === null){
							aSTP[oContext.ShipToPartyId].LRDate = oContext.LRDate;
						}
						if(aSTP[oContext.ShipToPartyId].Edd === null){
							aSTP[oContext.ShipToPartyId].Edd = oContext.Edd;
						}
						if(aSTP[oContext.ShipToPartyId].NumPackages === 0){
							aSTP[oContext.ShipToPartyId].NumPackages = oContext.NumPackages;
						}
						if(parseInt(aSTP[oContext.ShipToPartyId].Weight) === 0){
							aSTP[oContext.ShipToPartyId] = oContext.Weight;
						}
						if(parseInt(aSTP[oContext.ShipToPartyId].Volume) === 0){
							aSTP[oContext.ShipToPartyId].Volume = oContext.Volume;
						}
						for(var j = 3; j <= 8; j++){
							items[i].getCells()[j].setVisible(false);						
						}
					}else{
						aSTP[oContext.ShipToPartyId] = oContext;
						this.aSTP2[oContext.SystemId] = oContext;
						for(var j = 3; j <= 8; j++){
							items[i].getCells()[j].setVisible(true);
						}
					}
				}
				else{
					this.aSTP2=[];
					aSTP[oContext.ShipToPartyId] = oContext;
					this.aSTP2[oContext.SystemId] = oContext;
					for(var j = 3; j <= 8; j++){
						items[i].getCells()[j].setVisible(true);
					}
				}			
			}			
			for(var i = 0; i < itemsLen; i++){
				var oContext = items[i].getBindingContext().getObject();				
				oContext.LRNum = aSTP[oContext.ShipToPartyId].LRNum;
				oContext.LRDate = aSTP[oContext.ShipToPartyId].LRDate;
				oContext.Edd = aSTP[oContext.ShipToPartyId].Edd;
				items[i].getCells()[3].setValue(oContext.LRNum);
				items[i].getCells()[4].setDateValue(oContext.LRDate);
				items[i].getCells()[5].setDateValue(oContext.Edd);
				if(items[i].getCells()[6].getVisible()){
					items[i].getCells()[6].setValue(aSTP[oContext.ShipToPartyId].NumPackages);
					oContext.NumPackages = aSTP[oContext.ShipToPartyId].NumPackages;
				}
				else{
					items[i].getCells()[6].setValue();
					oContext.NumPackages = 0;
				}
				if(items[i].getCells()[7].getVisible()){
					items[i].getCells()[7].setValue(aSTP[oContext.ShipToPartyId].Weight);
				}
				else{
					items[i].getCells()[7].setValue();
					oContext.Weight = "0";
				}
				if(items[i].getCells()[8].getVisible()){
					items[i].getCells()[8].setValue(aSTP[oContext.ShipToPartyId].Volume);
				}
				else{
					items[i].getCells()[8].setValue();
					oContext.Volume = "0";
				}
			}
		},
		fnValidate : function(inpNo, regex, property, errMsg, bSetAllItems){			
			var inpNoVal = inpNo.getValue();
			if(regex.test(inpNoVal)){
				var currItem = inpNo.getParent(),
				currItemContext = currItem.getBindingContext().getObject();
				if(property === "Edd"){
					var currDate = new Date();
					currDate.setHours(0,0,0,0);
					if(inpNo.getDateValue() < currDate){
						inpNo.setValue();
						inpNo.setValueState("Error");
						inpNo.setValueStateText(this.oi18nModel.getProperty("msgPastDate"));
						MessageToast.show(this.oi18nModel.getProperty("msgPastDate"));
						return;
					}
				}
				/*if(property === "LRDate"){
					var currDate = new Date(), inpDate = inpNo.getDateValue();
					currDate.setHours(0,0,0,0);
					//var invoiceDate = new Date(Formatter.getDateFormatted(TransportExecution.that.headerData[0].BillDate));
					if(inpDate.getDate() !== currDate.getDate() ||
						inpDate.getMonth() !== currDate.getMonth() || 
						inpDate.getFullYear() !== currDate.getFullYear()){
						inpNo.setValue();
						inpNo.setValueState("Error");
						inpNo.setValueStateText(this.oi18nModel.getProperty("msgDateSelection"));
						MessageToast.show(this.oi18nModel.getProperty("msgDateSelection"));
						return;
					}					
				}*/
				if(property === "NumPackages"){
					if(!(parseInt(inpNoVal) > 0)){
						inpNo.setValue();
						inpNo.setValueState("Error");
						inpNo.setValueStateText(this.oi18nModel.getProperty("valNumsNotZero"));
						MessageToast.show(this.oi18nModel.getProperty("valNumsNotZero"));
						return;
					}
				}
				if(property === "Weight"){
					if(!(parseFloat(inpNoVal) > 0)){
						inpNo.setValue();
						inpNo.setValueState("Error");
						inpNo.setValueStateText(this.oi18nModel.getProperty("valNumsNotZero"));
						MessageToast.show(this.oi18nModel.getProperty("valNumsNotZero"));
						return;
					}
				}

				inpNo.setValueState("None");
				inpNo.setValueStateText();

				for(var prop in currItemContext){
					if(prop === property){
						if(inpNo instanceof DatePicker){
							currItemContext[prop] = new Date(inpNoVal);
						}
						else{
							currItemContext[prop] = inpNoVal;
						}
						break;
					}
				}
				if(bSetAllItems){
					var currItemSTP = currItem.getBindingContext().getObject().ShipToPartyId,
					currsysId = currItem.getBindingContext().getObject().SystemId,
					table = currItem.getParent(),
					items = table.getItems(),
					itemsLen = items.length,
					currItemIndex = table.indexOfItem(currItem);
					for(var i = 0; i < itemsLen; i++){
						var oContext = items[i].getBindingContext().getObject(),
						shipToParty = oContext.ShipToPartyId,
						sysId=oContext.SystemId;
						/*if(currItemSTP === shipToParty &&currsysId!==sysId){
							return;
						}else{*/
						if(currItemSTP === shipToParty && currsysId ===sysId && currItemIndex !== i){
							for(var prop in oContext){
								if(prop === property){
									if(inpNo instanceof DatePicker){
										oContext[prop] = new Date(inpNoVal);
									}
									else{
										if(prop === "NumPackages" || prop === "Weight" || prop === "Volume"){
											if(currsysId===sysId){
												oContext[prop] = "0";
												currItemContext[prop] = inpNoVal;
											}else{
												currItemContext[prop] = inpNoVal;
												return;

											}
										}
										else{
											oContext[prop] = inpNoVal;
										}
									}
									break;
								}
							}
						}
						/*}*/
					}
				}				
			}
			else{
				inpNo.setValue();
				inpNo.setValueState("Error");
				inpNo.setValueStateText(errMsg);
				MessageToast.show(errMsg);
			}
		},
		lCDocNo : function(oEvent){
			var inpNo = oEvent.getSource();
			this.fnValidate(inpNo, /^[A-Za-z0-9]+$/, "LRNum", this.oi18nModel.getProperty("valAlphaNum"), true);
		},
		cDD : function(oEvent){
			var inpNo = oEvent.getSource();
			this.fnValidate(inpNo, /^\d{1,2} [A-Za-z]{3} \d{4}$/, "LRDate", this.oi18nModel.getProperty("valDate"), true);
		},
		cEDD : function(oEvent){
			var inpNo = oEvent.getSource();
			this.fnValidate(inpNo, /^\d{1,2} [A-Za-z]{3} \d{4}$/, "Edd", this.oi18nModel.getProperty("valDate"), true);
		},
		lCNumPacks : function(oEvent){			
			var inpNo = oEvent.getSource();
			this.fnValidate(inpNo, /^[0-9]+$/, "NumPackages", this.oi18nModel.getProperty("valNums"), true);
		},
		cWeight : function(oEvent){			
			var inpNo = oEvent.getSource();
			this.fnValidate(inpNo, /^\d+(\.\d{1,4})?$/, "Weight", this.oi18nModel.getProperty("valNums"), true);			
		},
		cVolume : function(oEvent){
			var inpNo = oEvent.getSource();
			this.fnValidate(inpNo, /^\d+(\.\d{1,4})?$/, "Volume", this.oi18nModel.getProperty("valNums"), true);			
		},		
		pCreationTripSubmit : function(oEvent){
			var items = this.tblTripDetails.getItems(),
			itemsLen = items.length;
			for(var i = 0; i < itemsLen; i++){
				if(this.tblTripDetails.getColumns()[3].getVisible()){
					if(items[i].getCells()[3].getVisible() === true && items[i].getCells()[3].getValue() === ""){
						MessageToast.show(this.oi18nModel.getProperty("phDocNo"));
						return;
					}
				}
				/*if(this.tblTripDetails.getColumns()[4].getVisible()){
					if(items[i].getCells()[4].getValue() === ""){
						MessageToast.show(this.oi18nModel.getProperty("phDocDate"));
						return;
					}
				}*/
				if(items[i].getCells()[5].getVisible() === true && items[i].getCells()[5].getValue() === ""){
					MessageToast.show(this.oi18nModel.getProperty("phEdd"));
					return;
				}
				if(items[i].getCells()[6].getVisible() === true && items[i].getCells()[6].getValue() === ""){
					MessageToast.show(this.oi18nModel.getProperty("phNoPkgs"));
					return;
				}
				if(items[i].getCells()[6].getVisible() === true && (!(parseInt(items[i].getCells()[6].getValue()) > 0))){
					MessageToast.show(this.oi18nModel.getProperty("valPkgsNotZero"));
					return;
				}
				if(items[i].getCells()[7].getVisible() === true && items[i].getCells()[7].getValue() === ""){
					MessageToast.show(this.oi18nModel.getProperty("phWei"));
					return;
				}
				if(items[i].getCells()[7].getVisible() === true && (!(parseFloat(items[i].getCells()[7].getValue()) > 0))){
					MessageToast.show(this.oi18nModel.getProperty("valWeightNotZero"));
					return;
				}
				if(items[i].getCells()[8].getVisible() === true && items[i].getCells()[8].getValue() === ""){
					MessageToast.show(this.oi18nModel.getProperty("phVol"));
					return;
				}				
			}
			if(TransportExecution.that.Site !== undefined){
				var that = this,
				sSiteVal = this.inpSite.getValue().toUpperCase(),
				sPath = "/SiteF4Set?$filter=Site eq '" + sSiteVal + "'";
				Formatter.showLoader();
				TransportExecution.that.oModel.read(sPath, {
					async : true,
					success : function(oData, oResponse){
						Formatter.hideLoader();
						var aSite = oData.results.filter(function(ele){
							return (ele.Site === sSiteVal);
						});
						if(aSite.length > 0){
							that.inpSite.setValueState("None");
							that.inpSite.setValueStateText("");
							if(that.tripNo === "0"){
								that.fnCreateTrip();
							}
						}
						else{
							that.inpSite.setValueState("Error");
							that.inpSite.setValueStateText(that.oi18nModel.getProperty("msgSiteInvalid"));
							MessageToast.show(that.oi18nModel.getProperty("msgSiteInvalid"));
						}
					},
					error : function(oError){
						Formatter.hideLoader();
						that.inpSite.setValueState("Error");
						that.inpSite.setValueStateText(that.oi18nModel.getProperty("msgSiteInvalid"));
						MessageToast.show(that.oi18nModel.getProperty("msgSiteInvalid"));
					}
				});
			}
			else{
				if(this.tripNo === "0"){
					this.fnCreateTrip();
				}
				else{
					this.fnAddDeliveryToTrip();
				}
			}			
		},
		fnCreateTrip : function(){
			var items = this.tblTripDetails.getItems(),
			itemsLen = items.length,
			aHeadNav;
			aHeadNav = [];
			for(var i = 0; i < itemsLen; i++){
				var oContext = items[i].getBindingContext().getObject();				
				aHeadNav.push(this.fnPopupData(oContext, true));
			}
			var sealItems = this.tblSealInfo.getItems(),
			sealItemsLen = sealItems.length,
			aSealInfNav;
			aSealInfNav = [];
			for(var i = 0; i < sealItemsLen; i++){
				var oContext = sealItems[i].getBindingContext().getObject(),
				oSealInf = {
					LocationCode : oContext.LocationCode,
					StageSeq : oContext.StageSeq,
					DepSeal1 : oContext.DepSeal1,
					DepSeal2 : oContext.DepSeal2,
					Indicator : oContext.Indicator
				};
				aSealInfNav.push(oSealInf);
			}
			var data  = {};
			if(TransportExecution.that.oContextVehicle){
				TransportExecution.that.fnAddVRNDetails(data);
			}

			if(TransportExecution.that.Site !== undefined){				
				data.Site = this.inpSite.getValue().toUpperCase();
				TransportExecution.that.Site = undefined;
			}

			data.TRCRHDRTRPOPNAV = aHeadNav;
			data.TRCRHDREXECUTNAV = TransportExecution.that.fnGetItemNav();
			data.TRCRHDRSELINFNAV = aSealInfNav;

			var that = this,
			path = "TripCreHeaderSet",
			fnCallBack = function(oData, oResponse){
				var tripNo = "",
				bSuccess = true;
				if (oResponse.headers instanceof Array) {
					var sapmsg = oResponse.headers['sap-message'];
					if (sapmsg == undefined) {
						console.log("no sap-message is defined");
						bSuccess = false;
					}
					else {
						var svl = oResponse.headers['sap-message'].toString(),
						regex = /[0-9]+/g,
						msg = JSON.parse(svl);
						tripNo  = msg.message.match(regex)[0];
					}
				} else {
					bSuccess = false;
				}
				var shipTypes =  Formatter.getValidCNShipTypes();
				if(shipTypes.indexOf(that.shipType) > -1 && TransportExecution.that.oContextVehicle !== undefined && bSuccess){
					MessageBox.show(that.oi18nModel.getProperty("msgCreateCN"), {
						title : "Confirmation",
						icon : MessageBox.Icon.QUESTION,
						actions : [ 'Yes', 'No' ],
						onClose : function(oAction) {
							if(oAction === "Yes"){
								that.fnCreateCN(tripNo, data.TRCRHDREXECUTNAV);
							}
							else{
								TransportExecution.that.fnRefreshData();
								that.navBack();
							}
						}
					});
				}
				else if(bSuccess){
					TransportExecution.that.fnRefreshData();
					that.navBack();
					//that.fnPrint(tripNo, [ that.oi18nModel.getProperty("cancel"), that.oi18nModel.getProperty("printTrip")]);
				}

				/*if(TransportExecution.that.oContextVehicle !== undefined){//When VRN attached ask for entering Start Kms when RD, RB
					var kMShipTypes = Formatter.getValidStartKMShipTypes();
					if(kMShipTypes.indexOf(that.shipType) > -1 && bSuccess){
						if(!that.dlgStartKMS){
							that.dlgStartKMS = sap.ui.xmlfragment("TransportExecution.fragment.StartKMS", that);
							that.txtTripNo = that.oCore.byId("txtTripNo");
							that.inpStartKMS = that.oCore.byId("inpStartKMS");
						}
						that.txtTripNo.setText(tripNo);
						that.dlgStartKMS.open();
					}
				}*/
			};
			TransportExecution.that.postData(path, data, [ "/001" ], "S2", "TripCreation", true, fnCallBack);
		},
		lCStartKMS : function(oEvent){
			var control = oEvent.getSource(), val = control.getValue();
			if(!/^[0-9]+$/.test(val)){
				MessageToast.show(this.oi18nModel.getProperty("valNums"));
				control.setValue();
			}
		},
		pStartKMSCancel : function(){
			this.dlgStartKMS.close();
			this.fnCreateCNPopUp();
		},
		pStartKMSSubmit : function(){
			if(this.inpStartKMS !== ""){
				var aItem;
				aItem = [];
				for(var i = 0; i < aItemNav.length; i++){
					var oItem = {
							DeliveryNum : aItemNav[i].DeliveryNum	
					};
					aItem.push(oItem);
				}
				var that = this,
				path = "",
				data = {
						TripNum : tripNo,
						CNCREHDRITEMNAV : aItem
				},
				fnCallBack = function(oData, oResponse){
					that.fnCreateCNPopUp();
				};
				TransportExecution.that.postData(path, data, [ "ZMOB/275" ], "S2", "StartKMS", true, fnCallBack);
			}
			else{
				MessageToast.show(this.oi18nModel.getProperty("msgStartKms"));
			}
		},
		fnCreateCNPopUp : function(data){
			var that = this;
			var cNShipTypes = Formatter.getValidCNShipTypes();
			if(cNShipTypes.indexOf(this.shipType) > -1){
				MessageBox.show(this.oi18nModel.getProperty("msgCreateCN"), {
					title : "Confirmation",
					icon : MessageBox.Icon.QUESTION,
					actions : [ 'Yes', 'No' ],
					onClose : function(oAction) {
						if(oAction === "Yes"){
							that.fnCreateCN(that.tripNo, data.TRCRHDREXECUTNAV);
						}
						else{
							TransportExecution.that.fnRefreshData();
							that.navBack();
						}
					}
				});
			}
		},
		fnPrint : function(tripNo, actions){
			var that = this;
			MessageBox.show(that.oi18nModel.getProperty("msgPrinting"), {
				title : "Information",
				icon : MessageBox.Icon.INFORMATION,
				actions : actions,
				onClose : function(oAction) {
					var printCN = new PrintCN();
					if(oAction === that.oi18nModel.getProperty("printTrip")){										
						printCN.downloadPDF(tripNo);
					}
					else if(oAction === that.oi18nModel.getProperty("printCN")){
						printCN.downloadPDF(tripNo, "");
					}
					TransportExecution.that.fnRefreshData();
					that.navBack();
				}
			});
		},		
		fnCreateCN : function(tripNo, aItemNav){
			var aItem;
			aItem = [];
			for(var i = 0; i < aItemNav.length; i++){
				var oItem = {
						DeliveryNum : aItemNav[i].DeliveryNum	
				};
				aItem.push(oItem);
			}
			var that = this,
			path = "CNCreateHdrSet",
			data = {
					VRNNum : TransportExecution.that.oContextVehicle.VRNNum,
					TripNum : tripNo,
					CNCREHDRITEMNAV : aItem
			},
			fnCallBack = function(oData, oResponse){
				//that.fnPrint(tripNo, [ that.oi18nModel.getProperty("cancel"), that.oi18nModel.getProperty("printCN") ]);
				TransportExecution.that.fnRefreshData();
				that.navBack();
			};
			TransportExecution.that.postData(path, data, [ "ZMOB/275", "ZMOB/276" ], "S2", "CreateCN", true, fnCallBack);
		},
		fnAddDeliveryToTrip : function(){
			var items = this.tblTripDetails.getItems(), itemsLen = items.length, aItemNav, aHeadNav;
			aItemNav = [];			
			aHeadNav = [];
			for(var i = 0; i < itemsLen; i++){
				var oContext = items[i].getBindingContext().getObject(),
				oItemNav = {
					TripNum : oContext.TripNum,
					VRNNum : oContext.VRNNum,
					GroupId : oContext.GroupId,
					InvoiceNum : oContext.InvoiceNum,
					DeliveryNum : oContext.DeliveryNum,
					InWardPermit : oContext.InWardPermit,
					OutWardPermit : oContext.OutWardPermit,
					LRNum : oContext.LRNum,
					LRDate: Formatter.getDate1(oContext.LRDate),
					Edd: Formatter.getDate1(oContext.Edd),
					Weight : oContext.Weight,
					WeightUnit: oContext.WeightUnit,
					Volume : oContext.Volume,
					VolumeUnit : oContext.VolumeUnit,
					NumPackages : parseInt(oContext.NumPackages),
					PackageUnit : oContext.PackageUnit,
					ShippingType : oContext.ShippingType,
					ShippingDesc : oContext.ShippingDesc,
					Site : oContext.Site,
					Site1 : oContext.Site1,
					DropSeq : oContext.DropSeq,
					LoadSeq : oContext.LoadSeq,
					ShipToPartyId : oContext.ShipToPartyId,
					ShipToPartyName : oContext.ShipToPartyName,
					Destination : oContext.Destination,
					SystemId : oContext.SystemId,
					Type : oContext.Type,
					DeliveryType : oContext.DeliveryType
				};
				aHeadNav.push(this.fnPopupData(oContext));
				aItemNav.push(oItemNav);
			}
			var data  = {
					Dummy : "",					
					ADDELTRDTHDRNAV : aHeadNav,
					ADDELTRDTITMNAV : aItemNav
			};
			var path = "AddDeliverySet";			
			TransportExecution.that.postData(path, data, [ "/001" ], "S2", "AddDelivery");
			this.navBack();
		},
		navBack : function(){
			this.getRouter().navTo("S1");
		},
		getRouter : function(){
			return UIComponent.getRouterFor(this);
		},
		vHRLocs : function(oEvent){
			var path = "/SiteF4Set?$filter=Site eq '" + this.inpSite.getValue().toUpperCase() + "'";
			if(!this.dlgSites){
				this.dlgSites = sap.ui.xmlfragment("TransportExecution.fragment.Sites", this);				
			};
			this.dlgSites.bindAggregation("items", path, new StandardListItem({
				title : "{FirstName}",
				description : "{LastName}",
				type : "Active",
				info : "{Site}"
			}));
			this.dlgSites.open();
		},
		sSite : function(oEvent){
			var searchVal = oEvent.getParameter("value").toLowerCase(),
			items = this.dlgSites.getItems(),
			itemsLen = items.length;
			for(var i = 0; i < itemsLen; i++){
				var title = items[i].getTitle().toLowerCase(),
				desc = items[i].getDescription().toLowerCase(),
				info = items[i].getInfo().toLowerCase();
				items[i].setVisible((title.indexOf(searchVal) > -1 || desc.indexOf(searchVal) > -1 || info.indexOf(searchVal) > -1));
			}
		},
		cSite : function(oEvent){			
			this.inpSite.setValue(site);
			var site = oEvent.getParameter("selectedItem").getBindingContext().getObject().Site,
			selInfItems = this.tblSealInfo.getItems(),
			selInfItemsLen = selInfItems.length;
			selInfItems[selInfItemsLen - 1].getBindingContext().getObject().LocationCode = site;
			selInfItems[selInfItemsLen - 1].getCells()[0].setText(site);
		}
	});
});